"""V2.7 regression tests. Synthetic fixtures test code, not story/image quality."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import assemble
import script_integrity
import gates
import recommend
from test_value_support import annotate_project, reviewed_analysis, reviewed_build_final
import style_integrity as integrity

HERE = Path(__file__).parent
loader = importlib.util.spec_from_file_location('analyzer_v27', HERE/'대본분석_화풍추천.py')
analyzer = importlib.util.module_from_spec(loader); loader.loader.exec_module(analyzer)
STYLES = recommend.load_json(HERE/'STYLE_BANK.json')['styles']
TYPES = recommend.load_json(HERE/'IMAGE_TYPE_BANK.json')['types']
ROMANCE = next(s for s in STYLES if s['id'] == 'joseon_romance_bright')
SELECTION = {'status':'SELECTED','choice':'recommended',
             'recommended':{'style_id':'joseon_romance_bright'}}


def fixture(root, mode='basic', selection=None):
    """Create a fully machine-valid 40-cut dataset, with no claim of semantic realism."""
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    selection=copy.deepcopy(selection or SELECTION)
    body=[f'검사용 장면 {i}에서 보배와 한도원이 마당에 있었습니다.' for i in range(1,41)]
    state={'TITLE':'화풍 원문 보존 검사용 40컷','expected_count':40,
      'STYLE_TAIL':'flat 2D', 'processing_mode':mode, 'n_action':10,
      'aspect_16_9':True,'sets':[{'id':'yard','anchor':'a packed earth courtyard'}],
      'ingredients':[
       {'id':'bobae','name':'보배','age':24,'role':"peddler's daughter",
        'text':'a Korean woman, oval face, almond eyes, neat brows, small nose, defined lips, indigo jeogori, pinned hair',
        'valence':'중립','valence_quote':body[0], 'upload_view':'three-quarter left'},
       {'id':'hando','name':'한도원','age':27,'role':'young nobleman',
        'text':'a Korean man, tapered face, level eyes, straight brows, narrow nose, calm mouth, grey dopo, topknot',
        'valence':'중립','valence_quote':body[0], 'upload_view':'three-quarter right'}],
      'subanchors':[],'chapters':[],'shots':[]}
    rows=[]
    verbs=['standing','walking','watching','waiting','listening','holding','examining',
           'carrying','folding','counting','lifting','lowering','pointing','resting']
    for i in range(1,41):
        motion='A' if i<=10 else 'S' if i<=18 else 'N'
        state['chapters'].append({'start_idx':i-1,'end_idx':i,'motion':motion,
          'intensity':('L','M','H')[(i-1)%3], 'time':'day','set_id':'yard',
          'person_count':2,'minor_present':False})
        state['shots'].append({'shot':'medium_shot'})
        verb=verbs[(i-1)%len(verbs)]
        text=f'Medium shot of @bobae {verb} beside @hando, in {{SET}}, two figures, no duplicate or cloned figures'
        if motion in ('A','S'): text+=', both feet planted on the ground'
        if motion=='A': text+=', elbows driven forward'
        if motion=='S': text+=', eyes fixed on the gate, mouth pressed into a calm line'
        text+=', a low wall behind them, a wooden post near the gate'
        low,high=gates.BUDGET[motion]
        while len(gates.words(text))<low:
            text+=', the plain courtyard wall nearby'
        assert len(gates.words(text))<=high,(motion,len(gates.words(text)))
        rows.append({'n':i,'tags':['bobae','hando'],'subanchors':[],'main_verb':verb,'body':text})
    gates.save_json(root/'state.json',state); gates.save_json(root/'body.json',body)
    gates.save_json(root/'STYLE_SELECTION.json',selection)
    (root/'bodies').mkdir(exist_ok=True)
    for start in range(0,40,8): gates.save_json(root/'bodies'/f'chunk{start//8+1}.json',rows[start:start+8])
    gates.bind_selected_style(root,state)
    (root/'fixture_source.txt').write_text('\n'.join(body),encoding='utf-8')
    script_integrity.bind_source(root,root/'fixture_source.txt')
    annotate_project(state,body,rows)
    gates.save_json(root/'state.json',state)
    return state,body,rows


def cli(root,*args):
    return subprocess.run([sys.executable,str(HERE/'gates.py'),'--root',str(root),*args],
                          text=True,capture_output=True,encoding='utf-8',timeout=20)


class StyleOriginalTests(unittest.TestCase):
    def setUp(self):
        self.lock=integrity.make_lock(ROMANCE,SELECTION,'검사')
    def test_all_nine_bank_styles_are_verbatim(self):
        self.assertEqual(len(STYLES),9)
        for s in STYLES:
            with self.subTest(style=s['id']): self.assertEqual(integrity.full_text(s),s['style_tail'])
    def test_line_face_expression_shading_palette_all_present(self):
        for s in STYLES:
            for key in integrity.SPEC_KEYS: self.assertIn(s['visual_spec'][key],integrity.full_text(s))
    def test_reference_02_is_exact_saved_bright_romance(self):
        sel={'status':'SELECTED','choice':'reference','reference':{'reference_file':'REFERENCE_02'}}
        s=recommend.resolve_selection(sel,STYLES,None)
        self.assertEqual(s['id'],'joseon_romance_bright')
        self.assertEqual(integrity.full_text(s),ROMANCE['style_tail'])
    def test_unknown_reference_no_generic_fallback(self):
        with self.assertRaises(ValueError):
            recommend.resolve_selection({'status':'SELECTED','choice':'reference','reference':{'reference_file':'unknown.png'}},STYLES,None)
    def test_reference_requires_identified_file(self):
        with self.assertRaises(ValueError):
            recommend.resolve_selection({'status':'SELECTED','choice':'reference','reference':{'profile':ROMANCE}},STYLES,None)
    def test_external_profile_preserved_no_bank_substitution(self):
        ref=copy.deepcopy(ROMANCE); ref['name']='원문 레퍼런스'; ref['style_tail']=ref['style_tail'].replace('bright elegant','luminous elegant')
        sel={'status':'SELECTED','choice':'reference','reference':{'reference_file':'external.png','profile':ref}}
        s=recommend.resolve_selection(sel,STYLES,None)
        self.assertEqual(s['visual_spec'],ref['visual_spec'])
        self.assertTrue(integrity.full_text(s).startswith(ref['style_tail']))
    def test_short_profile_tail_gets_all_supplied_original_components(self):
        s=copy.deepcopy(ROMANCE); s['style_tail']='reference-led romance webtoon'
        result=integrity.full_text(s)
        self.assertTrue(result.startswith(s['style_tail']))
        for key in integrity.SPEC_KEYS: self.assertIn(s['visual_spec'][key],result)
    def test_missing_face_detail_rejected_not_invented(self):
        s=copy.deepcopy(ROMANCE); del s['visual_spec']['face_design']
        with self.assertRaises(ValueError): integrity.full_text(s)
    def test_manual_short_style_without_spec_rejected(self):
        with self.assertRaises(ValueError):
            recommend.resolve_selection({'status':'SELECTED','choice':'manual','manual':{'style_tail':'2D'}},STYLES,None)
    def test_manual_detailed_style_preserved(self):
        sel={'status':'SELECTED','choice':'manual','manual':copy.deepcopy(ROMANCE)}
        self.assertEqual(integrity.full_text(recommend.resolve_selection(sel,STYLES,None)),ROMANCE['style_tail'])
    def test_no_selection_no_lock(self):
        with self.assertRaises(ValueError): integrity.make_lock(ROMANCE,{'status':'WAITING_STYLE_SELECTION'},'검사')
    def test_unknown_recommended_id_rejected(self):
        sel=copy.deepcopy(SELECTION); sel['recommended']['style_id']='missing'
        with self.assertRaises(ValueError): recommend.resolve_selection(sel,STYLES,None)
    def test_changed_lock_tail_rejected(self):
        lock=copy.deepcopy(self.lock); lock['STYLE_TAIL_FULL']='flat 2D'
        self.assertTrue(integrity.lock_errors(lock))
    def test_changed_lock_face_rejected(self):
        lock=copy.deepcopy(self.lock); lock['style']['visual_spec']['face_design']='generic face'
        self.assertTrue(integrity.lock_errors(lock))
    def test_changed_selection_invalidates_cache(self):
        sel=copy.deepcopy(SELECTION); sel['recommended']['style_id']='joseon_clean_cel'
        self.assertTrue(integrity.lock_errors(self.lock,sel))
    def test_other_title_rejected(self):
        self.assertTrue(integrity.lock_errors(self.lock,title='다른작품'))
    def test_changed_punctuation_rejected(self):
        prompt='Scene. '+self.lock['STYLE_TAIL_FULL'].replace('bright elegant','bright, elegant',1)
        self.assertTrue(integrity.prompt_errors(prompt,self.lock))
    def test_duplicate_tail_rejected(self):
        t=self.lock['STYLE_TAIL_FULL']
        self.assertTrue(integrity.prompt_errors(t+', '+t,self.lock))
    def test_extra_style_after_suffix_rejected(self):
        self.assertTrue(integrity.prompt_errors('Scene. '+self.lock['STYLE_TAIL_FULL']+', generic 2D',self.lock))
    def test_no_added_labels(self):
        t=recommend.full_style_prompt(ROMANCE)
        self.assertFalse(any(x in t for x in integrity.LABELS))


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.state,self.body,self.rows=fixture(self.root)
    def tearDown(self): self.temp.cleanup()
    def test_plan_cast_chunks_pass(self):
        self.assertEqual(gates.plan_errors(self.state,self.body),[])
        self.assertEqual(gates.cast_errors(self.state,self.body),[])
        for n in range(1,6):
            rows=gates.read_rows(self.root,40,n)
            self.assertEqual(gates.row_errors(self.state,rows)[0],[])
    def test_all_nine_styles_pass_real_final_gates_unchanged(self):
        for style in STYLES:
            with self.subTest(style=style['id']):
                selection=copy.deepcopy(SELECTION)
                selection['recommended']['style_id']=style['id']
                gates.save_json(self.root/'STYLE_SELECTION.json',selection)
                gates.bind_selected_style(self.root,self.state)
                annotate_project(self.state,self.body,self.rows)
                gates.save_json(self.root/'state.json',self.state)
                run=cli(self.root,'--final')
                self.assertEqual(run.returncode,0,run.stdout+run.stderr)
                text=(self.root/'output'/gates.flow_output_name(self.state['TITLE'])).read_text(encoding='utf-8-sig')
                self.assertEqual(text.count(style['style_tail']),42)
    def test_negative_angry_style_instructions_are_preserved(self):
        style=next(s for s in STYLES if s['id']=='joseon_tension_cel')
        self.assertIn('avoid generic angry face',style['style_tail'])
        self.assertEqual(gates.style_banned(style['style_tail']),[])
        self.assertIn('angry',gates.style_banned('angry face'))

    def test_long_full_style_not_counted_in_170_word_budget(self):
        line=assemble.render(self.state,self.rows[0])
        self.assertGreater(len(gates.words(line)),170)
        self.assertEqual(gates.row_errors(self.state,self.rows)[0],[])
    def test_40_scene_flow_format_and_every_original_suffix(self):
        run=cli(self.root,'--final'); self.assertEqual(run.returncode,0,run.stdout+run.stderr)
        text=(self.root/'output'/gates.flow_output_name(self.state['TITLE'])).read_text(encoding='utf-8-sig')
        errors,counts=integrity.validate_flow(text,self.state['style_lock'],40)
        self.assertEqual(errors,[]); self.assertEqual(counts['scenes'],40); self.assertEqual(counts['uploads'],2)
        self.assertEqual(text.count(self.state['STYLE_TAIL']),42)
        self.assertNotIn('Character 1',text); self.assertNotIn('[캐릭터 이미지 프롬프트]',text)
    def test_portrait_is_one_upload_not_two_images(self):
        run=cli(self.root,'--characters'); self.assertEqual(run.returncode,0,run.stdout)
        chars=gates.read_json(self.root/'output'/'characters.json')
        self.assertEqual(len(chars),2)
        self.assertTrue(all(c['upload'].startswith('Single figure portrait of ') for c in chars))
        self.assertTrue(all(c['upload'].endswith(self.state['STYLE_TAIL']) for c in chars))
    def test_state_shortened_rejected(self):
        self.state['STYLE_TAIL']='flat 2D'; gates.save_json(self.root/'state.json',self.state)
        run=cli(self.root,'--final'); self.assertNotEqual(run.returncode,0)
        self.assertFalse((self.root/'output').exists())
        self.assertEqual(gates.read_json(self.root/'validation-last-run.json')['status'],'FAIL')
    def test_rebind_restores_original_without_editing_story(self):
        self.state['STYLE_TAIL']='flat 2D'; gates.save_json(self.root/'state.json',self.state)
        run=cli(self.root,'--bind-style'); self.assertEqual(run.returncode,0,run.stdout)
        s=gates.read_json(self.root/'state.json')
        self.assertEqual(s['STYLE_TAIL'],ROMANCE['style_tail'])
        self.assertEqual(s['chapters'],self.state['chapters']); self.assertEqual(s['ingredients'],self.state['ingredients'])
    def test_shortened_one_scene_fails_whole_file(self):
        _,_,lines=gates.row_errors(self.state,self.rows)
        lines[27]=lines[27].replace(self.state['STYLE_TAIL'],'flat 2D')
        (self.root/'output').mkdir(exist_ok=True)
        with self.assertRaises(ValueError): gates.write_bundle(self.root,self.state,self.body,lines)
        self.assertFalse(list((self.root/'output').glob('*_flow.txt')))
    def test_shortened_one_upload_detected(self):
        _,_,lines=gates.row_errors(self.state,self.rows); (self.root/'output').mkdir()
        path=gates.write_bundle(self.root,self.state,self.body,lines)
        text=path.read_text(encoding='utf-8-sig').replace(self.state['STYLE_TAIL'],'generic 2D',1)
        errors,_=integrity.validate_flow(text,self.state['style_lock'],40)
        self.assertTrue(any('UPLOAD bobae' in e for e in errors))
    def test_missing_or_extra_scene_detected(self):
        _,_,lines=gates.row_errors(self.state,self.rows); (self.root/'output').mkdir()
        path=gates.write_bundle(self.root,self.state,self.body,lines)
        text=path.read_text(encoding='utf-8-sig')
        text=text[:text.rfind('\n40. ')]
        self.assertTrue(integrity.validate_flow(text,self.state['style_lock'],40)[0])
    def test_unregistered_character_detected(self):
        rows=copy.deepcopy(self.rows); rows[0]['body']=rows[0]['body'].replace('@bobae','@ghost')
        self.assertTrue(gates.row_errors(self.state,rows)[0])
    def test_possessive_reference_regression(self):
        for suffix in ("'s",'’s'):
            rows=copy.deepcopy(self.rows); rows[27]['body']=rows[27]['body'].replace('@bobae','@bobae'+suffix,1)
            self.assertTrue(any('FLOWREF' in e for e in gates.row_errors(self.state,rows)[0]))
    def test_style_selection_changed_blocks_previous_lock(self):
        selection=copy.deepcopy(SELECTION); selection['recommended']['style_id']='joseon_mystery_cel'
        gates.save_json(self.root/'STYLE_SELECTION.json',selection)
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
    def test_missing_external_lock_blocks_final(self):
        (self.root/'STYLE_LOCK.json').unlink()
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
    def test_script_starts_preserved_verbatim(self):
        self.body[0]='"그럼 지금부터…"'; self.state['ingredients'][0]['valence_quote']=self.body[0]
        self.state['ingredients'][1]['valence_quote']=self.body[0]
        gates.save_json(self.root/'body.json',self.body)
        (self.root/'fixture_source.txt').write_text('\n'.join(self.body),encoding='utf-8')
        script_integrity.bind_source(self.root,self.root/'fixture_source.txt')
        annotate_project(self.state,self.body,self.rows)
        gates.save_json(self.root/'state.json',self.state)
        _,_,lines=gates.row_errors(self.state,self.rows); (self.root/'output').mkdir()
        path=gates.write_bundle(self.root,self.state,self.body,lines)
        self.assertIn('1. "그럼 지금부터…"',path.read_text(encoding='utf-8-sig'))
    def test_preflight_cli_checks_actual_flow(self):
        self.assertEqual(cli(self.root,'--final').returncode,0)
        run=subprocess.run([sys.executable,str(HERE/'style_integrity.py'),
            '--flow',str(self.root/'output'/gates.flow_output_name(self.state['TITLE'])),
            '--lock',str(self.root/'STYLE_LOCK.json'),'--selection',str(self.root/'STYLE_SELECTION.json')],
            text=True,capture_output=True,encoding='utf-8',timeout=20)
        self.assertEqual(run.returncode,0,run.stdout+run.stderr)
    def test_preflight_missing_scene_header_rejected(self):
        self.assertTrue(integrity.validate_flow('STEP 1\n',self.state['style_lock'])[0])


class ModeTests(unittest.TestCase):
    def setUp(self):
        self.a=analyzer.auto_analyze_script(HERE/'샘플대본_로맨스_V25.txt',6)
    def test_basic_economy_same_full_style_and_every_scene(self):
        a=reviewed_build_final(self.a,STYLES,TYPES,SELECTION,'basic')
        b=reviewed_build_final(self.a,STYLES,TYPES,SELECTION,'economy')
        self.assertEqual(a['style_lock']['sha256'],b['style_lock']['sha256'])
        self.assertEqual([s['final_prompt'] for s in a['scenes']],[s['final_prompt'] for s in b['scenes']])
    def test_economy_cache_contains_unabridged_source(self):
        result=reviewed_build_final(self.a,STYLES,TYPES,SELECTION,'economy')
        cache=analyzer.build_work_cache(self.a,result,SELECTION)
        self.assertEqual(cache['STYLE_TAIL_FULL'],ROMANCE['style_tail'])
        self.assertEqual(integrity.lock_errors(cache['style_lock'],SELECTION),[])
    def test_analyze_stage_does_not_create_lock_or_final(self):
        with tempfile.TemporaryDirectory() as d:
            run=subprocess.run([sys.executable,str(HERE/'대본분석_화풍추천.py'),
                '--script',str(HERE/'샘플대본_로맨스_V25.txt'),'--stage','analyze','--mode','economy','--out',d],
                text=True,capture_output=True,encoding='utf-8',timeout=20)
            self.assertEqual(run.returncode,0,run.stdout+run.stderr)
            self.assertFalse((Path(d)/'STYLE_LOCK.json').exists())
            self.assertFalse((Path(d)/'recommendations.txt').exists())
    def test_analysis_build_saves_raw_style_and_cache(self):
        for mode in ('basic','economy'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as d:
                d=Path(d); recommend.save_json(d/'input.json',reviewed_analysis(self.a,STYLES,TYPES,SELECTION))
                recommend.save_json(d/'selection.json',SELECTION)
                run=subprocess.run([sys.executable,str(HERE/'대본분석_화풍추천.py'),
                    '--analysis',str(d/'input.json'),'--stage','build','--mode',mode,
                    '--selection',str(d/'selection.json'),'--out',str(d/'out')],
                    text=True,capture_output=True,encoding='utf-8',timeout=20)
                self.assertEqual(run.returncode,0,run.stdout+run.stderr)
                self.assertEqual((d/'out'/'선택화풍_STYLE_TAIL.txt').read_text(encoding='utf-8-sig').rstrip('\n'),ROMANCE['style_tail'])
                self.assertEqual((d/'out'/'작품캐시.json').exists(),mode=='economy')
    def test_nine_styles_both_modes_all_scene_suffixes_exact(self):
        for style in STYLES:
            for mode in ('basic','economy'):
                sel=copy.deepcopy(SELECTION); sel['recommended']['style_id']=style['id']
                result=reviewed_build_final(self.a,STYLES,TYPES,sel,mode)
                for scene in result['scenes']:
                    self.assertEqual(integrity.prompt_errors(scene['final_prompt'],result['style_lock']),[])
                    self.assertTrue(scene['final_prompt'].endswith(style['style_tail']))


if __name__=='__main__': unittest.main(verbosity=2)
