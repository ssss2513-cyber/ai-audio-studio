#!/usr/bin/env python3
"""야담 대본 TXT -> 대본 분석 -> 화풍 후보 추천/사용자 선택/이미지 추천 V2.5.

권장 경로는 Claude 프로젝트가 대본 의미를 직접 읽어 analysis.json을 만드는 방식이다.
이 파일의 --script 모드는 외부 API 없이 작동하는 로컬/오프라인 1차 분석 폴백이며,
대본에 실제로 있는 어휘와 문장을 근거로 보수적으로 분류한다.
"""
from pathlib import Path
import argparse, json, re, sys
import recommend
import script_integrity
import scene_value_guard

VERSION = '2.7.2-r1'

CATEGORY = {
    'romance': ['로맨스','혼인','정혼','부부','신랑','신부','연정','사랑','재회','첫날밤','혼례','연인','고백','그리움','이별'],
    'tension': ['복수','갈등','누명','배신','위협','재판','탐욕','역모','쫓겨','쫓아','버렸','매맞','매를','칼','죽이','몰아붙','관아','사또','아전'],
    'animal': ['호랑이','백호','여우','강아지','짐승','산짐승','용','동물','보은'],
    'family': ['가족','효도','은혜','보은','화해','구원','부모','어머니','아버지','며느리','시어머니','형제','딸','아들'],
    'mystery': ['기이','괴담','미스터리','저주','비밀','정체','초자연','귀신','요괴','단서','발자국','흔적','사라졌','수상한']
}
GENRE_NAME = {
    'romance':'로맨스·혼인', 'tension':'권선징악·갈등', 'animal':'동물·보은 민담',
    'family':'가족·관계', 'mystery':'미스터리·기이'
}
TONE_NAME = {
    'romance':'설렘·관계', 'tension':'긴장·대립', 'animal':'신비·보은',
    'family':'정서·가족', 'mystery':'궁금증·미스터리'
}

ROLE_TERMS = ['두부장수','떡장수','심마니','며느리','시어머니','과부','거지','기생','머슴','선비','사또','아전','대감','양반','포졸','아이','소녀','소년','노인','할머니','할아버지','호랑이','백호','여우','강아지','용']
PROP_TERMS = ['주판','장부','유언장','열쇠','편지','칼','가마니','엽전','동전','두부','떡','발자국','낙인','밧줄','호롱불','등불','가마','상자','보자기','약초','비녀','족자']

LOCATION_RULES = [
    (['장터','시장'], '조선시대 장터', False),
    (['관아','동헌'], '조선시대 관아', True),
    (['방안','방 안','안방','안채','사랑채','실내','곳간'], '한옥 실내', True),
    (['주막'], '조선시대 주막', True),
    (['우물'], '마을 우물가', False),
    (['산길','산속','산 속','숲','산중'], '산길과 숲', False),
    (['강가','나루터','나루','강변'], '강가 또는 나루터', False),
    (['마당','대문','문앞','문 앞','댓돌','한옥','초가집','집 앞'], '한옥 마당 또는 대문 앞', False),
    (['절','사찰','산사'], '산사', True),
    (['길','행렬'], '마을 길', False),
]

TIME_RULES = [
    ('dawn', ['새벽','동틀','동이 트','여명']),
    ('night_out', ['한밤중','한밤','밤중','야밤','깊은 밤','밤이 깊','달빛','달이 중천','밤길','밤하늘']),
    ('dusk', ['해질녘','저물녘','황혼','땅거미','석양','해가 지','저녁 무렵']),
    ('day', ['한낮','대낮','낮','아침','햇빛','해가 떠','정오']),
]

EVENT_RULES = [
    ('animal', ['호랑이','백호','여우','짐승','용','동물','강아지']),
    ('reveal', ['정체','알고보니','알고 보니','드러났','밝혀졌','낙인','유언장','장부','증거']),
    ('clue', ['단서','발자국','흔적','편지','열쇠','주판']),
    ('confrontation', ['대치','따졌','몰아붙','위협','매맞','매를','칼을','재판','추궁','싸움','쫓','버리','내쫓']),
    ('return', ['돌아왔','돌아오','귀환','업혀','구해','구출','데려왔','살려']),
    ('market', ['장터','시장','엽전','백 냥','사들','장사']),
    ('arrival', ['문을 두드','문앞','문 앞','대문','찾아왔','찾아온','들어왔']),
    ('romance', ['혼인','정혼','신랑','신부','첫날밤','재회','연정','사랑']),
    ('authority', ['아전','사또','대감','관아','유언장','상속','재산']),
    ('travel', ['산길','길을 나섰','길을 걷','행렬','숲길','나루터']),
    ('reaction', ['놀라','충격','눈물','안도','깨달','힘이 풀','숨을 삼'])
]

EMOTION_RULES = [
    ('충격·놀람', ['놀라','충격','경악','힘이 풀','숨을 삼','눈이 커']),
    ('분노·대립', ['분노','화가','격분','따졌','몰아붙','대치','추궁']),
    ('두려움·불안', ['두려','무서','겁에','떨었','불안','위협']),
    ('슬픔·상실', ['눈물','슬퍼','울었','통곡','상실','버림']),
    ('안도·감동', ['안도','감사','고마','미소','살았다','돌아왔']),
    ('의심·호기심', ['수상','이상했','왜','단서','흔적','비밀','정체','발자국']),
    ('다정함·설렘', ['사랑','연정','정혼','혼인','재회','다정'])
]


def read_text(path):
    p = Path(path)
    for enc in ('utf-8-sig','utf-8','cp949','euc-kr'):
        try:
            return p.read_text(encoding=enc)
        except UnicodeDecodeError:
            pass
    return p.read_text(encoding='utf-8', errors='replace')


def extract_title_and_body(text):
    return script_integrity.extract_title_and_body(text)


def sentences_from_text(text):
    return script_integrity.sentences_from_text(text)


def paragraphs_as_sentence_groups(text):
    groups=[]
    for para in re.split(r'\n\s*\n',text.replace('\r\n','\n').replace('\r','\n')):
        para=para.strip()
        if not para: continue
        sents=sentences_from_text(para)
        if sents: groups.append(sents)
    return groups


def scene_groups_from_text(text, n):
    paras=paragraphs_as_sentence_groups(text)
    if paras and len(paras) >= n:
        # 문단이 충분하면 문단 경계를 우선 보존한다.
        packed=chunks_balanced(paras,n)
        return [[sent for para in group for sent in para] for group in packed]
    sentences=sentences_from_text(text)
    return chunks_balanced(sentences,n)


def chunks_balanced(items, n):
    if not items: return []
    n=max(1,min(int(n),len(items)))
    return [items[i*len(items)//n:(i+1)*len(items)//n] for i in range(n)]


PARTICLES = ('이','가','은','는','을','를','의','에','에서','에게','으로','로','와','과','도','만','처럼','까지','부터')

def term_count(text, term):
    # Single-syllable Korean terms such as 용/절/칼 must be lexical items, not substrings of 중요/시절.
    if re.fullmatch(r'[가-힣]', term):
        suffix='|'.join(map(re.escape, sorted(PARTICLES,key=len,reverse=True)))
        pat=rf'(?<![가-힣]){re.escape(term)}(?:(?:{suffix}))?(?=$|[^가-힣])'
        return len(re.findall(pat,text))
    return text.count(term)

def term_in_text(text, term):
    return term_count(text,term)>0

def hit_count(text, words):
    return sum(term_count(text,w) for w in words)


def flag_strength(count):
    if count <= 0: return 0
    if count <= 2: return 1
    if count <= 5: return 2
    return 3


def find_sentence_with_any(sentences, words):
    for sent in sentences:
        if any(term_in_text(sent,w) for w in words):
            return sent
    return ''


def detect_time(scene_sentences, indoors):
    joined=' '.join(scene_sentences)
    for value, words in TIME_RULES:
        evidence=find_sentence_with_any(scene_sentences, words)
        if evidence:
            if value=='night_out' and indoors:
                return 'night_in', evidence
            return value, evidence if value in {'night_out','night_in','dusk'} else ''
    return ('day_in' if indoors else 'day'), ''


def detect_location(text):
    for words,name,indoors in LOCATION_RULES:
        if any(term_in_text(text,w) for w in words):
            return name, indoors
    return '대본에 명시된 장소', False


def detect_event(text):
    scored=[]
    for order,(event,words) in enumerate(EVENT_RULES):
        score=hit_count(text,words)
        if score: scored.append((score,-order,event))
    return max(scored)[2] if scored else 'reaction'


def detect_emotion(text):
    scored=[]
    for order,(name,words) in enumerate(EMOTION_RULES):
        score=hit_count(text,words)
        if score: scored.append((score,-order,name))
    return max(scored)[2] if scored else '중립적 긴장'


def detect_tension(text,event):
    score=1
    if event in {'confrontation','reveal','clue'}: score += 1
    if any(w in text for w in ['칼','매맞','죽이','위협','역모','버렸','쫓겨']): score += 2
    if any(w in text for w in ['비밀','정체','사라졌','발자국','충격','경악']): score += 1
    return max(1,min(5,score))


def discover_names(text):
    names=[]
    patterns=[
        r'(?:며느리|과부|두부장수|떡장수|심마니|아전|사또|대감|선비|기생|머슴|소녀|소년)\s+([가-힣]{2,4})',
        r'(?:^|\n)\s*([가-힣]{2,4})\s*[:：]'
    ]
    for pat in patterns:
        for m in re.finditer(pat,text,re.M):
            name=m.group(1)
            for particle in ('에게','에서','으로','까지','부터','처럼','보다','의','을','를','은','는','이','가','와','과','도','만'):
                if len(name)>2 and name.endswith(particle):
                    name=name[:-len(particle)]
                    break
            if name and name not in names: names.append(name)
    return names[:10]


def detect_terms(text, terms, limit=6):
    found=[t for t in terms if term_in_text(text,t)]
    return found[:limit]


def detect_characters(text, known_names):
    found=[]
    for name in known_names:
        if name in text and name not in found: found.append(name)
    for role in ROLE_TERMS:
        if term_in_text(text,role) and role not in found: found.append(role)
    return found[:6]


def choose_quote(sentences):
    if not sentences: return ''
    signal_words=[]
    for _,ws in EVENT_RULES: signal_words.extend(ws)
    signal_words += PROP_TERMS
    ranked=[]
    for i,s in enumerate(sentences):
        ranked.append((hit_count(s,signal_words),-i,s))
    ranked.sort(reverse=True)
    return ranked[0][2]


def category_scores(text):
    return {k:hit_count(text,v) for k,v in CATEGORY.items()}


def auto_analyze_script(script_path, scene_count=40, title=None):
    raw=read_text(script_path)
    detected_title,text=extract_title_and_body(raw)
    sentences=sentences_from_text(text)
    if not sentences:
        raise ValueError('대본에서 비어 있지 않은 문장을 찾지 못했습니다.')
    groups=scene_groups_from_text(text, scene_count)
    known_names=discover_names(text)
    cs=category_scores(text)
    ordered=sorted(cs.items(), key=lambda kv:(-kv[1], list(CATEGORY).index(kv[0])))
    primary_key=ordered[0][0] if ordered and ordered[0][1]>0 else None
    secondary=[GENRE_NAME[k] for k,v in ordered[1:3] if v>0]
    flags={k:flag_strength(cs.get(k,0)) for k in CATEGORY}
    tones=[TONE_NAME[k] for k,v in ordered[:3] if v>0] or ['전통 야담']
    scenes=[]
    source_index=0
    for idx,group in enumerate(groups,1):
        scene_text=' '.join(group)
        location,indoors=detect_location(scene_text)
        req_time,time_evidence=detect_time(group,indoors)
        event=detect_event(scene_text)
        emotion=detect_emotion(scene_text)
        quote=choose_quote(group)
        chars=detect_characters(scene_text,known_names)
        props=detect_terms(scene_text,PROP_TERMS,limit=6)
        bool_animal=any(term_in_text(scene_text,w) for w in CATEGORY['animal'])
        bool_romance=any(term_in_text(scene_text,w) for w in CATEGORY['romance'])
        relation_present=any(w in scene_text for w in ['가족','부모','어머니','아버지','며느리','시어머니','형제','딸','아들'])
        family_warm=any(w in scene_text for w in ['화해','효도','감사','고마','안도','품에','돌아왔','구원','보은','은혜'])
        bool_family=relation_present and (family_warm or event in {'return','reaction'})
        bool_mystery=any(term_in_text(scene_text,w) for w in CATEGORY['mystery'])
        reveal=event=='reveal'
        confidence=sum(bool(x) for x in [chars,props,location!='대본에 명시된 장소',event!='reaction',time_evidence])
        scenes.append({
            'n':idx,
            'script_quote':quote,
            'start_sentence':group[0],
            'start_idx':source_index,
            'end_idx':source_index+len(group),
            'summary':quote,
            'characters':chars,
            'location':location,
            'indoors':indoors,
            'requested_time':req_time,
            'time_evidence':time_evidence,
            'emotion_primary':emotion,
            'tension':detect_tension(scene_text,event),
            'event_type':event,
            'important_props':props,
            'animal':bool_animal,
            'supernatural':any(term_in_text(scene_text,w) for w in ['귀신','요괴','신령','도깨비','용','변신','초자연']),
            'crowd':any(w in scene_text for w in ['사람들','구경꾼','군중','마을 사람','온 집안']),
            'romance':bool_romance,
            'family':bool_family,
            'mystery':bool_mystery,
            'reveal':reveal,
            'continuity_note':'',
            'auto_analysis_confidence':confidence
        })
        source_index+=len(group)
    for scene in scenes:
        scene['value_gate']=scene_value_guard.pending_gate()
    return {
        'version':VERSION,
        'analysis_mode':'direct_txt_offline_fallback',
        'source_file':str(Path(script_path).resolve()),
        'source_sha256':script_integrity.digest(Path(script_path).read_bytes()),
        'source_sentence_count':len(sentences),
        'title':title or detected_title or Path(script_path).stem,
        'genre_primary':GENRE_NAME[primary_key] if primary_key else '야담·민담',
        'genre_secondary':secondary,
        'tone':tones,
        'period':'조선시대/한국 전통 야담',
        'global_flags':flags,
        'global_keyword_counts':cs,
        'scenes':scenes
    }


def analysis_report(a, script_path=''):
    lines=[
        f'대본 자동 분석 결과 V{VERSION}',
        f'입력 대본: {script_path}',
        f"작품: {a.get('title','')}",
        f"핵심 장르: {a.get('genre_primary','')}",
        '보조 장르: '+(', '.join(a.get('genre_secondary',[])) or '없음'),
        '톤: '+(', '.join(a.get('tone',[])) or '없음'),
        '화풍 신호: '+json.dumps(a.get('global_flags',{}),ensure_ascii=False),
        '',
        '※ 이 보고서는 외부 AI/API 없이 대본의 실제 어휘와 문장을 이용한 1차 분석입니다.',
        '※ Claude 프로젝트에서는 Claude가 대본 의미를 직접 읽어 같은 스키마를 더 정밀하게 작성한 뒤 추천기를 실행하는 방식을 우선합니다.',
        ''
    ]
    for s in a.get('scenes',[]):
        lines += [
            f"[씬 {s['n']}]",
            f"근거 원문: {s['script_quote']}",
            f"장소/시간: {s['location']} / {s['requested_time']}",
            f"장면 유형: {s['event_type']} / 감정: {s['emotion_primary']} / 긴장도: {s['tension']}",
            '등장 요소: '+(', '.join(s['characters']) or '자동 식별 없음'),
            '핵심 소품: '+(', '.join(s['important_props']) or '자동 식별 없음'),
            f"자동분석 신뢰 신호: {s.get('auto_analysis_confidence',0)}/5",
            ''
        ]
    return '\n'.join(lines).rstrip()+'\n'


def build_work_cache(a, result, selection):
    """Compact cache created only AFTER explicit style selection."""
    sel=result['selected_style']
    return {
      'version': VERSION, 'mode': 'economy', 'title': a.get('title'),
      'source_file': a.get('source_file'), 'source_sha256': a.get('source_sha256'),
      'genre_primary': a.get('genre_primary'), 'genre_secondary': a.get('genre_secondary',[]),
      'tone': a.get('tone',[]), 'style_selection': selection,
      'selected_style': sel, 'style_lock': result['style_lock'],
      'STYLE_TAIL_FULL': result['style_lock']['STYLE_TAIL_FULL'],
      'style_sha256': result['style_lock']['sha256'],
      'scenes': [{
          'n': s.get('n'), 'start_sentence': s.get('start_sentence'), 'start_idx': s.get('start_idx'), 'end_idx': s.get('end_idx'), 'script_quote': s.get('script_quote'), 'summary': s.get('summary'),
          'characters': s.get('characters',[]), 'location': s.get('location'),
          'requested_time': s.get('requested_time'), 'time_evidence': s.get('time_evidence',''),
          'event_type': s.get('event_type'), 'emotion_primary': s.get('emotion_primary'),
          'tension': s.get('tension'), 'important_props': s.get('important_props',[]),
          'continuity_note': s.get('continuity_note',''),
          'value_gate': result['scenes'][s['n']-1].get('value_gate',{}),
          'value_source_text': result['scenes'][s['n']-1].get('value_source_text','')
      } for s in a.get('scenes',[])]
    }


def write_analysis_outputs(a, candidates, out_dir, script_path=''):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    recommend.save_json(out/'style-validation-last-run.json',{'version':VERSION,'status':'WAITING_STYLE_SELECTION'})
    if a.get('analysis_mode') == 'direct_txt_offline_fallback' and a.get('source_file'):
        path=Path(a['source_file'])
        if script_integrity.digest(path.read_bytes()) != a.get('source_sha256'):
            raise ValueError('SCRIPT_SOURCE: original changed since analysis')
        script_integrity.bind_source(out,path)
    recommend.save_json(out/'scene-value-validation-last-run.json',{'version':VERSION,'status':'PENDING','scope':scene_value_guard.SCOPE,'image_review_status':'NOT_REVIEWED'})
    recommend.save_json(out/'analysis.json',a)
    recommend.save_json(out/'대본분석결과.json',a)
    (out/'대본분석결과.txt').write_text(analysis_report(a,script_path),encoding='utf-8-sig')
    recommend.save_json(out/'style-candidates.json',candidates)
    (out/'화풍후보_선택대기.txt').write_text(recommend.candidate_report(candidates),encoding='utf-8-sig')
    (out/'STYLE_SELECTION.json').write_text(Path(__file__).with_name('STYLE_SELECTION_TEMPLATE.json').read_text(encoding='utf-8'),encoding='utf-8')
    summary='\n'.join([
        f"WAITING_STYLE_SELECTION V{VERSION}", f"작품: {a.get('title','')}",
        f"장면 수: {len(a.get('scenes',[]))}",
        '대본 분석 완료. 화풍은 아직 고정하지 않았습니다.',
        '추천 화풍 / 레퍼런스 화풍 / 직접 화풍 중 사용자가 선택해야 다음 단계로 진행합니다.',
        '장면별 서사/해설/교육적 가치 및 불쾌감은 아직 승인하지 않았습니다. Claude가 실제 원문과 프롬프트를 검토한 뒤 진행합니다.'
    ])+'\n'
    (out/'실행요약.txt').write_text(summary,encoding='utf-8-sig')


def write_final_outputs(a, result, selection, out_dir, mode='basic'):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    recommend.write_style_snapshot(out,result,selection)
    recommend.save_json(out/'STYLE_SELECTION.json',selection)
    recommend.save_json(out/'recommendations.json',result)
    recommend.save_json(out/'화풍추천결과.json',result)
    report=recommend.final_report(result)
    (out/'recommendations.txt').write_text(report,encoding='utf-8-sig')
    (out/'화풍추천결과.txt').write_text(report,encoding='utf-8-sig')
    selected=result['selected_style']
    (out/'선택화풍_STYLE_TAIL.txt').write_text(recommend.full_style_prompt(selected)+'\n',encoding='utf-8-sig')
    summary='\n'.join([
        f"PASS V{VERSION}", f"작품: {result.get('title','')}",
        f"선택 화풍: {selected['name']}", f"화풍 출처: {result.get('style_source')}",
        f"장면 수: {len(result.get('scenes',[]))}",
        '사용자 화풍 선택 -> 상세 얼굴 규칙 포함 -> 이미지 유형/구도 -> 최종 IMAGE PROMPT 생성 완료'
    ])+'\n'
    (out/'실행요약.txt').write_text(summary,encoding='utf-8-sig')
    if mode == 'economy': recommend.save_json(out/'작품캐시.json',build_work_cache(a,result,selection))


def main():
    ap=argparse.ArgumentParser(description='대본 TXT 분석 후 화풍 후보를 제시하고, 사용자 선택 후 최종 이미지 프롬프트를 생성합니다.')
    src=ap.add_mutually_exclusive_group(required=True)
    src.add_argument('--script',help='대본 TXT 경로. 로컬 키워드 기반 1차 분석을 수행합니다.')
    src.add_argument('--analysis',help='Claude/ChatGPT가 작성한 analysis.json 경로.')
    ap.add_argument('--scenes',type=int,default=40)
    ap.add_argument('--mode',choices=['basic','economy'],default='basic')
    ap.add_argument('--stage',choices=['analyze','bind-values','build'],default='analyze')
    ap.add_argument('--selection',default=None,help='build 단계의 STYLE_SELECTION.json')
    ap.add_argument('--reviewer',default=None)
    ap.add_argument('--title',default=None)
    ap.add_argument('--styles',default=str(Path(__file__).with_name('STYLE_BANK.json')))
    ap.add_argument('--types',default=str(Path(__file__).with_name('IMAGE_TYPE_BANK.json')))
    ap.add_argument('--out',default='output')
    args=ap.parse_args()
    try:
        if args.script:
            a=auto_analyze_script(args.script,args.scenes,args.title); source=str(args.script)
        else:
            a=recommend.load_json(args.analysis); source=str(args.analysis)
        a['processing_mode']=args.mode
        errors=recommend.validate_analysis(a)
        if errors:
            print('\n'.join('ERROR: '+x for x in errors)); return 1
        styles=recommend.load_json(args.styles)['styles']; types=recommend.load_json(args.types)['types']
        if args.stage=='analyze':
            candidates=recommend.build_candidates(a,styles,3,args.mode)
            write_analysis_outputs(a,candidates,args.out,source)
            print(f"WAITING_STYLE_SELECTION V{VERSION} [{args.mode}]: {len(candidates['candidates'])} candidates -> {args.out}")
            return 0
        if not args.selection: raise ValueError('build 단계에는 --selection STYLE_SELECTION.json이 필요합니다.')
        selection=recommend.load_json(args.selection)
        if args.stage=='bind-values':
            if not args.reviewer: raise ValueError('--reviewer is required')
            a=recommend.bind_scene_reviews(a,styles,types,selection,args.reviewer)
            recommend.save_json(Path(args.out)/'analysis.json',a)
            recommend.save_json(Path(args.out)/'scene-value-bind-last-run.json',dict(version=VERSION,status='BOUND',scene_count=len(a['scenes']),scope=scene_value_guard.SCOPE))
            print('BOUND SCENE REVIEWS:',Path(args.out)/'analysis.json'); return 0
        result=recommend.build_final(a,styles,types,selection,args.mode)
        write_final_outputs(a,result,selection,args.out,args.mode)
        print(f"PASS V{VERSION} [{args.mode}]: {len(result['scenes'])} scenes -> {args.out}")
        print('SELECTED STYLE:',result['selected_style']['name']); return 0
    except Exception as ex:
        try: recommend.save_json(Path(args.out)/'scene-value-validation-last-run.json',scene_value_guard.report(getattr(ex,'errors',[str(ex)]),0,'pipeline'))
        except OSError: pass
        try: recommend.save_json(Path(args.out)/'style-validation-last-run.json',{'status':'FAIL','error':str(ex),'version':VERSION})
        except OSError: pass
        print('ERROR:',ex); return 1

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
