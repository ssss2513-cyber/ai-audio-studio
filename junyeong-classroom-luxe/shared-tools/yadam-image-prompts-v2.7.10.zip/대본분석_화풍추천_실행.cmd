@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo See CLAUDE_PROJECT_INSTRUCTIONS.md: choose recommended, reference or manual before analysis.
python workflow_guard.py --help
pause
