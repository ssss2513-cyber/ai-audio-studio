"""V2.7. Preserve the user-selected full style text; no image generation.

A SHA-256 checksum detects accidental edits, not malicious tampering. Lock only
AFTER an explicit style selection; never substitute another style on failure.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import re
import sys

VERSION = '2.7.2-r2'
SPEC_KEYS = ('line_art', 'face_design', 'expression_direction', 'shading', 'palette')
LABELS = ('FACE DESIGN LOCK:', 'FACIAL EXPRESSION LOCK:', 'CEL SHADING LOCK:',
          'COLOR PALETTE LOCK:', 'LINE ART LOCK:')


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def fingerprint(value):
    return digest(json.dumps(value, ensure_ascii=False, sort_keys=True,
                             separators=(',', ':')))


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def checked_line(text, field):
    if not isinstance(text, str) or not text.strip():
        raise ValueError('STYLE: missing ' + field + '; do not use a generic fallback')
    if text != text.strip() or re.search(r'[\r\n{}@]', text):
        raise ValueError('STYLE: ' + field + ' must be a resolved single line without edge whitespace')
    if any(label in text for label in LABELS):
        raise ValueError('STYLE: use natural English style text, not added LOCK labels')
    return text


def full_text(style):
    """Return all provided style text without shortening ANY supplied component.

    Existing bank tails already contain the full components, so they are returned
    byte-for-byte. A new reference profile with a short base tail is completed
    using its unabridged five components once, BEFORE the snapshot is locked.
    """
    if not isinstance(style, dict):
        raise ValueError('STYLE: detailed style object required')
    spec = style.get('visual_spec')
    if not isinstance(spec, dict):
        raise ValueError('STYLE: visual_spec required; do not invent a replacement')
    for key in SPEC_KEYS:
        checked_line(spec.get(key), 'visual_spec.' + key)
    base = style.get('style_tail')
    if base is None or base == '':
        base = ', '.join(spec[k] for k in SPEC_KEYS)
    base = checked_line(base, 'style_tail')
    missing = [spec[k] for k in SPEC_KEYS if spec[k] not in base]
    # Preserve punctuation and every character of base and missing components.
    return base if not missing else base + ', ' + ', '.join(missing)


def make_lock(style, selection, title):
    if not isinstance(selection, dict) or selection.get('status') != 'SELECTED':
        raise ValueError('STYLE_SELECTION: explicit user selection required')
    text = full_text(style)
    return {
        'version': VERSION, 'status': 'SELECTED', 'title': str(title),
        'policy': 'FULL_STYLE_VERBATIM_IN_EVERY_PROMPT',
        'selection_sha256': fingerprint(selection),
        'style': copy.deepcopy(style),
        'STYLE_TAIL_FULL': text, 'sha256': digest(text),
        'characters': len(text),
        'fields_sha256': {k: digest(style['visual_spec'][k]) for k in SPEC_KEYS},
        'scope': 'Text integrity only; not visual style or security authentication'
    }


def lock_errors(lock, selection=None, title=None):
    errors = []
    if not isinstance(lock, dict) or lock.get('status') != 'SELECTED':
        return ['STYLE_LOCK: a user-selected full style snapshot is required']
    try:
        original = full_text(lock.get('style'))
    except (ValueError, TypeError) as exc:
        return ['STYLE_LOCK: ' + str(exc)]
    if lock.get('policy') != 'FULL_STYLE_VERBATIM_IN_EVERY_PROMPT':
        errors.append('STYLE_LOCK: full-original-text policy missing')
    if lock.get('STYLE_TAIL_FULL') != original:
        errors.append('STYLE_LOCK: STYLE_TAIL_FULL is shortened or differs from its source')
    if lock.get('sha256') != digest(original) or lock.get('characters') != len(original):
        errors.append('STYLE_LOCK: text checksum/length mismatch')
    expected = {k: digest(lock['style']['visual_spec'][k]) for k in SPEC_KEYS}
    if lock.get('fields_sha256') != expected:
        errors.append('STYLE_LOCK: line/face/expression/shading/palette checksum mismatch')
    if selection is not None:
        if selection.get('status') != 'SELECTED' or fingerprint(selection) != lock.get('selection_sha256'):
            errors.append('STYLE_LOCK: selection changed or not selected; discard old cache and bind again')
    if title is not None and lock.get('title') != str(title):
        errors.append('STYLE_LOCK: snapshot belongs to a different work')
    return errors


def state_style(state):
    errors = lock_errors(state.get('style_lock'), title=state.get('TITLE'))
    if errors:
        raise ValueError('; '.join(errors))
    text = state['style_lock']['STYLE_TAIL_FULL']
    if state.get('STYLE_TAIL') != text:
        raise ValueError('STYLE_TAIL: shortened/changed; bind the full selected style, never summarize it')
    return text


def prompt_errors(prompt, lock, label='PROMPT'):
    errors = lock_errors(lock)
    if errors:
        return errors
    original = lock['STYLE_TAIL_FULL']
    if not isinstance(prompt, str) or not prompt.strip():
        return [label + ': empty prompt']
    if '\n' in prompt or '\r' in prompt:
        errors.append(label + ': prompt must be a single line')
    if prompt.count(original) != 1:
        errors.append(label + ': the complete original STYLE_TAIL must appear exactly once')
    if not prompt.endswith(original):
        errors.append(label + ': full STYLE_TAIL must be the unchanged suffix')
    for key in SPEC_KEYS:
        if lock['style']['visual_spec'][key] not in prompt:
            errors.append(label + ': missing/changed original ' + key)
    if any(label_text in prompt for label_text in LABELS):
        errors.append(label + ': added LOCK labels are not part of the requested output format')
    return errors


def validate_flow(text, lock, expected_count=None):
    """Check exact requested section order, every portrait, every numbered scene."""
    errors = lock_errors(lock)
    if errors:
        return errors, {'uploads': 0, 'scenes': 0}
    text = text.lstrip('\ufeff')
    if text.splitlines()[:1] != ['STEP 1']:
        errors.append('FORMAT: first line must be STEP 1')
    script_heads = list(re.finditer(r'^\[대본 1~(\d+)\]$', text, re.M))
    scene_heads = list(re.finditer(r'^\[영어 프롬프트 1~(\d+)\]$', text, re.M))
    sep = list(re.finditer(r'^===프롬프트===$', text, re.M))
    if len(script_heads) != 1 or len(scene_heads) != 1 or len(sep) != 1:
        return errors + ['FORMAT: exactly one script/scene heading and separator required'], {'uploads': 0, 'scenes': 0}
    a, b, c = script_heads[0], sep[0], scene_heads[0]
    if not a.start() < b.start() < c.start():
        return errors + ['FORMAT: STEP 1 -> script -> separator -> English prompts order required'], {'uploads': 0, 'scenes': 0}
    n = int(a[1])
    if n < 1 or n != int(c[1]) or (expected_count is not None and n != expected_count):
        errors.append('FORMAT: declared scene counts do not match')
    if text[b.end():c.start()].strip():
        errors.append('FORMAT: extra text between separator and scene heading')
    # Preserve raw lines for exact comparisons; ignore only empty layout lines.
    head = [line for line in text[:a.start()].splitlines() if line.strip()]
    character_lines = head[1:]
    ids = []
    heading_re = re.compile(r'^=== ([A-Za-z][A-Za-z0-9_]*) \((.+), (.+) / 챕터 -\) ===$')
    if len(character_lines) % 3:
        errors.append('FORMAT: each character needs exactly heading, UPLOAD heading, one prompt')
    for i in range(0, len(character_lines) - 2, 3):
        header, upload_header, prompt = character_lines[i:i+3]
        match = heading_re.fullmatch(header)
        if not match:
            errors.append('FORMAT: invalid character heading: ' + header[:100]); continue
        key = match[1]; ids.append(key)
        if upload_header != '=== ' + key + ' UPLOAD ===':
            errors.append('FORMAT: UPLOAD ID does not match character header')
        if not prompt.startswith('Single figure portrait of '):
            errors.append('FORMAT: one Single figure portrait per character is required')
        errors.extend(prompt_errors(prompt, lock, 'UPLOAD ' + key))
    if len(ids) != len(set(ids)):
        errors.append('FORMAT: duplicate character ID')
    def numbered(section, kind):
        items = []
        for line in section.splitlines():
            if not line.strip(): continue
            match = re.fullmatch(r'(\d+)\. (.+)', line)
            if not match:
                errors.append('FORMAT: extra or invalid ' + kind + ' line'); continue
            items.append((int(match[1]), match[2]))
        if [i for i, _ in items] != list(range(1, n+1)):
            errors.append('FORMAT: ' + kind + ' rows must be exactly 1..N')
        return items
    numbered(text[a.end():b.start()], 'script')
    scenes = []
    for line in text[c.end():].splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r'(\d{3}) \| (.+?) \| (.+)', line)
        if not match:
            errors.append('FORMAT: scene lines must use 003 | source excerpt | @[asset] prompt')
            continue
        number = int(match[1]); excerpt = match[2]; rest = match[3]
        asset_refs = re.findall(r'@\[([A-Za-z][A-Za-z0-9_]*)\]', rest)
        prompt = re.sub(r'^(?:@\[[A-Za-z][A-Za-z0-9_]*\]\s*)+', '', rest).strip()
        scenes.append((number, excerpt, asset_refs, prompt))
    if [i for i, *_ in scenes] != list(range(1, n+1)):
        errors.append('FORMAT: scene rows must be exactly 001..N with zero padding')
    known = set(ids)
    for number, excerpt, asset_refs, prompt in scenes:
        errors.extend(prompt_errors(prompt, lock, 'SCENE ' + str(number)))
        if not excerpt.strip():
            errors.append('FORMAT: scene ' + str(number) + ' missing source excerpt before the second bar')
        if ' — ' not in prompt:
            errors.append('FORMAT: scene ' + str(number) + ' needs an em-dash separator')
        if re.search(r"@[A-Za-z][A-Za-z0-9_]*['’]s\b", prompt):
            errors.append('FLOWREF: scene ' + str(number) + ' contains @ID possessive suffix')
        if not asset_refs:
            errors.append('FLOWREF: scene ' + str(number) + ' needs at least one @[asset] call before the prompt body')
        unknown = set(re.findall(r'@([A-Za-z][A-Za-z0-9_]*)', prompt)) - known
        if unknown:
            errors.append('FLOWREF: scene ' + str(number) + ' unregistered IDs: ' + ', '.join(sorted(unknown)))
    return errors, {'uploads': len(ids), 'scenes': len(scenes), 'style_sha256': lock['sha256']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--flow', required=True)
    parser.add_argument('--lock', required=True)
    parser.add_argument('--selection', required=True)
    parser.add_argument('--report')
    args = parser.parse_args()
    try:
        lock = read_json(args.lock); selection = read_json(args.selection)
        errors = lock_errors(lock, selection)
        scan, counts = validate_flow(Path(args.flow).read_text(encoding='utf-8-sig'), lock)
        errors.extend(scan)
        # Re-resolve using the current bundled bank, not only the saved snapshot.
        import recommend
        styles = read_json(Path(__file__).with_name('STYLE_BANK.json'))['styles']
        chosen = recommend.resolve_selection(selection, styles, None)
        if full_text(chosen) != lock.get('STYLE_TAIL_FULL'):
            errors.append('STYLE_LOCK: current selection source differs from saved snapshot')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors, counts = [str(exc)], {}
    result = {'version': VERSION, 'status': 'FAIL' if errors else 'PASS',
              'errors': errors, 'counts': counts,
              'scope': 'Text integrity and format only; no rendered-image comparison'}
    if args.report: write_json(args.report, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if errors else 0

if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
