"""Image filenames have no leading cut number; cut order stays in metadata."""
import re

def image_filename(text, used=None):
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', ' ', str(text)[:30])
    stem = re.sub(r'^\d+_', '', stem).strip(' .') or '장면'
    if stem.upper() in {'CON','PRN','AUX','NUL'} or re.fullmatch(r'(COM|LPT)[1-9]', stem, re.I):
        stem += '_이미지'
    candidate = stem + '.png'
    if used is not None:
        suffix = 2
        while candidate.casefold() in used:
            candidate = f'{stem}_중복{suffix}.png'
            suffix += 1
        used.add(candidate.casefold())
    return candidate
