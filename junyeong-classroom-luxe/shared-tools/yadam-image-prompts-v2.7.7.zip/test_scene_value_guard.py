"""Production-integration regressions. These tests never certify real images."""
import copy
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import scene_value_guard as g
import gates
import assemble
import recommend
from test_value_support import make_gate, reviewed_analysis
from test_style_integrity import fixture, cli, STYLES, TYPES, SELECTION, analyzer
from test_script_integrity import hundred_fixture

HERE=Path(__file__).parent
SRC='정연은 문서의 매듭 두 개를 나란히 비교하였습니다.'
VISIBLE='the woman compares two knots side by side'
PROMPT='Medium shot of '+VISIBLE+', neutral daylight'

class ValueSchemaTests(unittest.TestCase):
    def setUp(self): self.gate=make_gate(SRC,VISIBLE)
    def check(self, gate=None, source=SRC, prompt=PROMPT, bound=False):
        return g.validate_gate(gate if gate is not None else self.gate,source,prompt,n=1,require_binding=bound)
    def test_each_single_role_qualifies(self):
        for role in g.ROLES:
            with self.subTest(role=role): self.assertEqual(self.check(make_gate(SRC,VISIBLE,role)),[])
    def test_any_nonempty_combination(self):
        for flags in itertools.product([False,True],repeat=3):
            if not any(flags):continue
            gate=copy.deepcopy(self.gate);gate['flags']=dict(zip(g.ROLES,flags))
            gate['primary']='mixed' if sum(flags)>1 else g.ROLES[flags.index(True)]
            with self.subTest(flags=flags):self.assertEqual(self.check(gate),[])
    def test_all_false_rejected(self):
        self.gate['flags']={k:False for k in g.ROLES};self.assertTrue(self.check())
    def test_string_false_and_integer_are_not_booleans(self):
        for fake in ('false','true',1,0,None,[],{}):
            with self.subTest(fake=fake):
                gate=copy.deepcopy(self.gate);gate['flags']['narrative']=fake;self.assertTrue(self.check(gate))
    def test_missing_gate_rejected(self):self.assertTrue(g.validate_gate(None))
    def test_extra_misspelled_flag_rejected(self):
        self.gate['flags']['narative']=True;self.assertTrue(self.check())
    def test_mismatched_primary_rejected(self):
        self.gate['primary']='educational';self.assertTrue(self.check())
    def test_mixed_cannot_mean_one_role(self):
        self.gate['primary']='mixed';self.assertTrue(self.check())
    def test_empty_or_placeholder_details_rejected(self):
        for key in ('source_evidence','reason','visualization','prompt_evidence','discomfort_reason'):
            for value in ('','  ','...','TODO','없음'):
                gate=copy.deepcopy(self.gate);gate[key]=value
                with self.subTest(key=key,value=value):self.assertTrue(self.check(gate))
    def test_another_cut_quote_rejected(self):self.assertTrue(self.check(source='다른 장면의 문장입니다.'))
    def test_labels_are_not_visual_evidence(self):
        self.gate['prompt_evidence']='narrative';self.assertTrue(self.check(prompt='narrative'))
    def test_actual_prompt_must_contain_evidence(self):self.assertTrue(self.check(prompt='A pretty landscape'))
    def test_medium_high_unknown_rejected(self):
        for risk in ('medium','high','unknown',None,'LOW'):
            self.gate['discomfort_risk']=risk
            with self.subTest(risk=risk):self.assertTrue(self.check())
    def test_low_risk_requires_mitigation(self):
        self.gate['discomfort_risk']='low';self.assertTrue(self.check())
        self.gate['mitigation']='Show the puzzled reaction and document, not a frightening depiction.'
        self.assertEqual(self.check(),[])
    def test_pending_is_not_approved(self):
        self.gate['review_status']='PENDING';self.assertTrue(self.check())
    def test_risk_phrase_despite_none_is_blocked(self):
        self.assertTrue(self.check(prompt=PROMPT+', graphic gore'))
    def test_explicit_negative_prompt_does_not_request_gore(self):
        self.assertEqual(self.check(prompt=PROMPT+'. no graphic gore'),[])
    def test_valid_review_binding_passes(self):
        gate=g.bind_gate(self.gate,SRC,PROMPT,'test-reviewer');self.assertEqual(self.check(gate,bound=True),[])
    def test_no_binding_fails_final_check(self):self.assertTrue(self.check(bound=True))
    def test_bind_does_not_auto_approve(self):
        self.gate['review_status']='PENDING'
        with self.assertRaises(g.ValueGateError):g.bind_gate(self.gate,SRC,PROMPT,'test-reviewer')
    def test_reviewer_required(self):
        with self.assertRaises(g.ValueGateError):g.bind_gate(self.gate,SRC,PROMPT,'')
    def test_prompt_changed_since_review(self):
        gate=g.bind_gate(self.gate,SRC,PROMPT,'test-reviewer');self.assertTrue(self.check(gate,prompt=PROMPT+', new person',bound=True))
    def test_review_fields_changed_since_review(self):
        gate=g.bind_gate(self.gate,SRC,PROMPT,'test-reviewer');gate['reason']='Changed review'
        self.assertTrue(self.check(gate,bound=True))
    def test_source_changed_since_review(self):
        gate=g.bind_gate(self.gate,SRC,PROMPT,'test-reviewer');self.assertTrue(self.check(gate,source=SRC+' 다음 사건.',bound=True))
    def test_empty_project_never_passes(self):self.assertTrue(g.project_errors({'chapters':[]},[]))
    def test_empty_analysis_never_passes(self):
        with self.assertRaises(g.ValueGateError):g.analysis_sources({'scenes':[]})

class ProductionValueTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.s,self.b,self.rows=fixture(self.root)
    def save(self):gates.save_json(self.root/'state.json',self.s)
    def test_required_in_real_final_command(self):
        del self.s['chapters'][27]['value_gate'];self.save()
        run=cli(self.root,'--final');self.assertNotEqual(run.returncode,0);self.assertIn('VALUE 28',run.stdout)
        self.assertFalse((self.root/'output').exists())
        self.assertEqual(g.load_json(self.root/'validation-last-run.json')['status'],'FAIL')
    def test_plan_blocks_missing_purpose_before_drafting(self):
        self.s['chapters'][0]['value_gate']=g.pending_gate();self.save()
        self.assertNotEqual(cli(self.root,'--plan').returncode,0)
    def test_uploaded_portraits_are_exempt(self):
        for c in self.s['chapters']:c.pop('value_gate')
        self.save();self.assertEqual(cli(self.root,'--characters').returncode,0)
    def test_binding_command_works_without_user_json_reentry(self):
        for c in self.s['chapters']:c['value_gate'].pop('review_binding')
        self.save();self.assertEqual(cli(self.root,'--bind-values','--reviewer','SYNTHETIC_TEST').returncode,0)
        self.assertEqual(cli(self.root,'--final').returncode,0)
    def test_binding_missing_reviewer_rejected(self):self.assertNotEqual(cli(self.root,'--bind-values').returncode,0)
    def test_missing_binding_blocks_final(self):
        self.s['chapters'][1]['value_gate'].pop('review_binding');self.save()
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
    def test_direct_bundle_export_cannot_bypass_gate(self):
        lines=[assemble.render_text(self.s,r) for r in self.rows]
        self.s['chapters'][0]['value_gate']['flags']['narrative']=False
        with self.assertRaises(g.ValueGateError):gates.write_bundle(self.root,self.s,self.b,lines)
    def test_changed_settings_invalidate_review(self):
        self.s['sets'][0]['anchor']='a completely different hillside';self.save()
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
    def test_rejected_run_does_not_replace_old_flow(self):
        self.assertEqual(cli(self.root,'--final').returncode,0)
        path=self.root/'output'/gates.flow_output_name(self.s['TITLE']);before=path.read_bytes()
        self.s['chapters'][31]['value_gate']['discomfort_risk']='high';self.save()
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
        self.assertEqual(path.read_bytes(),before)
        self.assertEqual(g.load_json(self.root/'scene-value-validation-last-run.json')['status'],'FAIL')
    def test_actual_flow_preflight(self):
        self.assertEqual(cli(self.root,'--final').returncode,0)
        path=self.root/'output'/gates.flow_output_name(self.s['TITLE'])
        run=subprocess.run([sys.executable,str(HERE/'scene_value_guard.py'),'--root',str(self.root),'--flow',str(path),'--report',str(self.root/'check.json')],capture_output=True,text=True,timeout=20)
        self.assertEqual(run.returncode,0,run.stdout+run.stderr)
        self.assertEqual(g.load_json(self.root/'check.json')['image_review_status'],'NOT_REVIEWED')
    def test_no_new_sections_or_style_shortening(self):
        self.assertEqual(cli(self.root,'--final').returncode,0)
        text=(self.root/'output'/gates.flow_output_name(self.s['TITLE'])).read_text(encoding='utf-8-sig')
        self.assertTrue(text.startswith('STEP 1\n'));self.assertEqual(text.count(self.s['STYLE_TAIL']),42)
        self.assertNotIn('value_gate',text);self.assertNotIn('VALUE:',text)
    def test_hundred_scene_failure_identifies_exact_number(self):
        s,b,rows=hundred_fixture(self.root);s['chapters'][99]['value_gate']['discomfort_risk']='medium'
        g.save_json(self.root/'state.json',s)
        run=cli(self.root,'--final');self.assertNotEqual(run.returncode,0);self.assertIn('VALUE 100',run.stdout)

class RecommenderValueTests(unittest.TestCase):
    def setUp(self):
        self.a=analyzer.auto_analyze_script(HERE/'샘플대본_로맨스_V25.txt',6)
    def approved(self):return reviewed_analysis(self.a,STYLES,TYPES,SELECTION)
    def test_local_analysis_does_not_fabricate_approval(self):
        for s in self.a['scenes']:
            self.assertEqual(s['value_gate']['review_status'],'PENDING')
            self.assertEqual(s['value_gate']['discomfort_risk'],'unknown')
    def test_build_rejects_unreviewed_analysis(self):
        with self.assertRaises(g.ValueGateError):recommend.build_final(self.a,STYLES,TYPES,SELECTION)
    def test_value_visualization_is_in_actual_prompt(self):
        a=self.approved();r=recommend.build_final(a,STYLES,TYPES,SELECTION)
        for s in r['scenes']:self.assertIn(s['value_gate']['visualization'],s['final_prompt'])
    def test_edited_source_hash_blocks_recommender(self):
        a=self.approved();a['source_sha256']='0'*64
        with self.assertRaises(g.ValueGateError):recommend.build_final(a,STYLES,TYPES,SELECTION)
    def test_empty_scenes_rejected(self):
        a=self.approved();a['scenes']=[]
        with self.assertRaises(ValueError):recommend.build_final(a,STYLES,TYPES,SELECTION)
    def test_summary_edit_requires_new_review(self):
        a=self.approved();a['scenes'][0]['summary']='New unsupported event'
        with self.assertRaises(g.ValueGateError):recommend.build_final(a,STYLES,TYPES,SELECTION)
    def test_no_auto_style_lock(self):
        c=recommend.build_candidates(self.a,STYLES)
        self.assertFalse(c['auto_style_lock']);self.assertEqual(c['status'],'WAITING_STYLE_SELECTION')
    def test_negative_result_cannot_be_written(self):
        r=recommend.build_final(self.approved(),STYLES,TYPES,SELECTION)
        r['scenes'][0]['final_prompt']=r['scenes'][0]['final_prompt'].replace(r['scenes'][0]['value_gate']['prompt_evidence'],'REMOVED',1)
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(g.ValueGateError):recommend.write_style_snapshot(d,r,SELECTION)
            self.assertFalse((Path(d)/'STYLE_LOCK.json').exists())
    def test_economy_cache_retains_approved_reviews(self):
        a=self.approved();r=recommend.build_final(a,STYLES,TYPES,SELECTION,'economy')
        cache=analyzer.build_work_cache(a,r,SELECTION)
        self.assertTrue(all(s['value_gate']['review_status']=='APPROVED' for s in cache['scenes']))
        self.assertEqual(cache['STYLE_TAIL_FULL'],r['style_lock']['STYLE_TAIL_FULL'])
    def test_both_modes_same_prompts_and_checks(self):
        a=self.approved()
        x=recommend.build_final(a,STYLES,TYPES,SELECTION,'basic');y=recommend.build_final(a,STYLES,TYPES,SELECTION,'economy')
        self.assertEqual([s['final_prompt'] for s in x['scenes']],[s['final_prompt'] for s in y['scenes']])
        self.assertEqual(x['scene_value_validation'],y['scene_value_validation'])

if __name__=='__main__':unittest.main(verbosity=2)
