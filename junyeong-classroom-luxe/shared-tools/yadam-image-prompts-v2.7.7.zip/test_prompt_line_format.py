import unittest
import gates

class PromptLineFormatTests(unittest.TestCase):
    def test_format_scene_prompt_line(self):
        state={"chapters":[{"set_id":"market_night"}], "TITLE":"T"}
        row={"n":1,"tags":["isun"],"subanchors":["guard"]}
        record={"n":1,"start_sentence_30":"그 장터에 어느 날부터 수상한 선비"}
        prompt='@isun, a nobleman — Medium shot of @isun in the alley, flat cel shading'
        line=gates.format_scene_prompt_line(state,record,row,prompt)
        self.assertTrue(line.startswith('001 | 그 장터에 어느 날부터 수상한 선비 | @[market_night] @[isun] @[guard] '))
        self.assertTrue(line.endswith('flat cel shading'))

if __name__ == '__main__':
    unittest.main()
