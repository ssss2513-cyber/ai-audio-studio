#!/usr/bin/env python3
"""Yadam image/style recommender v2.5.
Stage 1 ranks detailed style candidates but DOES NOT auto-select or lock one.
Stage 2 requires explicit user style selection (recommended/reference/manual), then builds prompts.
Standard library only. No image generation or semantic-policy approval.
"""
from pathlib import Path
import argparse, json, re, sys
import copy
import style_integrity
import scene_value_guard
import workflow_guard

VERSION='2.7.9'
DARK={'dusk','night_in','night_out'}
VALID_TIME={'day','day_in','dawn','dusk','night_in','night_out'}
SPEC_KEYS=('line_art','face_design','expression_direction','shading','palette')


def load_json(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def save_json(p,v):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')

def norm_text(*parts):
    vals=[]
    for p in parts:
        if isinstance(p,list): vals.extend(str(x) for x in p)
        elif isinstance(p,dict): vals.extend(f'{k} {v}' for k,v in p.items())
        elif p is not None: vals.append(str(p))
    return ' '.join(vals).lower()

def contains_any(text, words):
    return sum(1 for w in words if str(w).lower() in text)

def matched_terms(text, words):
    return [str(w) for w in words if str(w).lower() in text]

def validate_analysis(a):
    e=[]
    if not isinstance(a,dict): return ['analysis must be object']
    for k in ('title','genre_primary','scenes'):
        if k not in a: e.append('missing top-level field: '+k)
    scenes=a.get('scenes',[])
    if not isinstance(scenes,list) or not scenes:
        e.append('scenes must be nonempty list'); return e
    nums=[]
    for i,s in enumerate(scenes,1):
        if not isinstance(s,dict): e.append(f'scene {i}: object required'); continue
        nums.append(s.get('n'))
        for k in ('n','script_quote','summary','characters','location','indoors','requested_time','time_evidence','emotion_primary','tension','event_type','important_props'):
            if k not in s: e.append(f'scene {i}: missing {k}')
        if s.get('requested_time') not in VALID_TIME: e.append(f'scene {i}: invalid requested_time')
        if type(s.get('indoors')) is not bool: e.append(f'scene {i}: indoors boolean required')
        if not isinstance(s.get('characters'),list): e.append(f'scene {i}: characters list required')
        if not isinstance(s.get('important_props'),list): e.append(f'scene {i}: important_props list required')
        if type(s.get('tension')) is not int or not 1 <= s.get('tension',0) <= 5: e.append(f'scene {i}: tension 1..5 integer required')
        if not str(s.get('script_quote','')).strip(): e.append(f'scene {i}: script_quote must contain source evidence')
    if nums != list(range(1,len(scenes)+1)): e.append('scene n values must be exact 1..N order')
    return e


def style_reason(style, analysis):
    base=norm_text(analysis.get('genre_primary'),analysis.get('genre_secondary',[]),analysis.get('tone',[]),analysis.get('title'))
    hits=matched_terms(base,style.get('triggers',[]))
    parts=[]
    if hits: parts.append('작품 신호 '+', '.join(hits[:5]))
    flags=analysis.get('global_flags',{}) or {}
    sid=style['id']
    if 'romance' in sid and flags.get('romance',0): parts.append(f"romance 강도 {flags.get('romance')}")
    if 'tension' in sid and flags.get('tension',0): parts.append(f"tension 강도 {flags.get('tension')}")
    if 'animal' in sid and flags.get('animal',0): parts.append(f"animal 강도 {flags.get('animal')}")
    if 'family' in sid and flags.get('family',0): parts.append(f"family 강도 {flags.get('family')}")
    if 'mystery' in sid and flags.get('mystery',0): parts.append(f"mystery 강도 {flags.get('mystery')}")
    return ' / '.join(parts) if parts else '기본 조선 사극 2D 셀 웹툰 규칙과 안정적으로 일치'


def score_style(style, analysis):
    text=norm_text(analysis.get('genre_primary'),analysis.get('genre_secondary',[]),analysis.get('tone',[]),analysis.get('title'))
    flags=analysis.get('global_flags',{}) or {}
    score=float(style.get('base_score',0))+2*contains_any(text,style.get('triggers',[]))
    sid=style['id']
    if 'romance' in sid: score += float(flags.get('romance',0))*1.5
    if 'tension' in sid: score += float(flags.get('tension',0))*1.5
    if 'animal' in sid: score += float(flags.get('animal',0))*1.5
    if 'family' in sid: score += float(flags.get('family',0))*1.5
    if 'mystery' in sid: score += float(flags.get('mystery',0))*1.5
    # Distinguish romance substyles using tone signals.
    if sid=='joseon_romance_emotional' and contains_any(text,['그리움','고백','눈물','이별','감정','애틋']): score += 2
    if sid=='joseon_romance_melodrama' and contains_any(text,['갈등','비밀','신분','누명','배신']): score += 2
    if sid=='joseon_romance_bright' and contains_any(text,['혼인','정혼','재회','사랑','연인']): score += 1
    if sid=='joseon_authority_cel' and contains_any(text,['관아','재판','사또','아전','대감','판결','상속','문서']): score += 3
    return score


def build_candidates(a,styles,top_k=3,mode='basic'):
    workflow_guard.require_mode(a.get('workflow'))
    scored=[(score_style(s,a),s) for s in styles]
    scored.sort(key=lambda x:(-x[0],x[1]['id']))
    candidates=[]
    for rank,(score,s) in enumerate(scored[:top_k],1):
        candidates.append({
            'rank':rank,'id':s['id'],'name':s['name'],'score':round(score,2),
            'reason':style_reason(s,a),'style_summary_ko':s.get('style_summary_ko',''),
            'visual_spec':s.get('visual_spec',{}),'style_tail':s.get('style_tail',''),
            'reference_files':s.get('reference_files',[])
        })
    return {
        'version':VERSION,'mode':mode,'title':a.get('title'),
        'status':'WAITING_STYLE_SELECTION','auto_style_lock':False,
        'candidates':candidates,
        'next_choices':['recommended','reference','manual'],
        'message':'대본 분석 완료. 추천 화풍/레퍼런스 화풍/직접 화풍 중 사용자가 선택해야 다음 단계로 진행합니다.'
    }


def candidate_report(r):
    lines=[f"화풍 후보 추천 V{VERSION}",f"작품: {r.get('title','')}",
           '상태: WAITING_STYLE_SELECTION — 아직 화풍을 고정하지 않았습니다.','']
    for c in r['candidates']:
        v=c.get('visual_spec',{})
        lines += [f"[{c['rank']}] {c['name']} / 점수 {c['score']}",f"추천 이유: {c['reason']}",
                  f"특징: {c.get('style_summary_ko','')}",f"선/외곽선: {v.get('line_art','')}",
                  f"얼굴 상세: {v.get('face_design','')}",f"표정 방식: {v.get('expression_direction','')}",
                  f"셀 명암: {v.get('shading','')}",f"팔레트: {v.get('palette','')}"]
        if c.get('reference_files'): lines.append('내장 참고 이미지: '+', '.join(c['reference_files']))
        lines.append('')
    lines += ['다음 선택:', '1. 추천 화풍 사용 — 위 후보 번호 선택',
              '2. 레퍼런스 화풍 사용 — 첨부 이미지의 화풍만 분석',
              '3. 직접 화풍 입력', '',
              '※ 선택 전에는 final IMAGE PROMPT를 생성하지 않습니다.']
    return '\n'.join(lines).rstrip()+'\n'


def validate_visual_spec(v):
    return [k for k in SPEC_KEYS if not isinstance(v.get(k),str) or not v.get(k,'').strip()]


def resolve_selection(selection,styles,candidates):
    if not isinstance(selection,dict) or selection.get('status')!='SELECTED':
        raise ValueError('STYLE_SELECTION: explicit user selection required; auto style locking is disabled')
    choice=selection.get('choice')
    bank={s['id']:s for s in styles}
    if choice=='recommended':
        sid=(selection.get('recommended') or {}).get('style_id')
        if sid not in bank:
            raise ValueError('STYLE_SELECTION: unknown/missing recommended.style_id; no fallback')
        s=copy.deepcopy(bank[sid]); s['source']='recommended'
    elif choice=='reference':
        ref=selection.get('reference') or {}
        filename=ref.get('reference_file')
        if not isinstance(filename,str) or not filename.strip():
            raise ValueError('REFERENCE STYLE: identify the selected reference_file')
        profile=ref.get('profile')
        if profile is None:
            # Exact built-in names only. Never infer an external image style from its filename.
            catalog=load_json(Path(__file__).with_name('REFERENCE_CATALOG.json'))
            entry=next((e for e in catalog['files'] if filename in [e['file']]+e.get('aliases',[])),None)
            sid=entry.get('default_style_id') if entry else None
            if sid not in bank:
                raise ValueError('REFERENCE STYLE: a full visual profile is required for this reference')
            s=copy.deepcopy(bank[sid]); s['reference_files']=[entry['file']]
            s['style_summary_ko']='선택한 내장 레퍼런스에 연결된 저장 화풍 원문 사용'
        else:
            if not isinstance(profile,dict):
                raise ValueError('REFERENCE STYLE: profile must be an object')
            s=copy.deepcopy(profile)
            s.setdefault('id','reference_user_style')
            s.setdefault('name','사용자 레퍼런스 화풍')
            s['reference_files']=[filename]
        s['source']='reference'
    elif choice=='manual':
        m=selection.get('manual') or {}
        s=copy.deepcopy(m); s.setdefault('id','manual_user_style')
        s.setdefault('name','사용자 지정 화풍'); s['reference_files']=[]
        s['source']='manual'
    else:
        raise ValueError('STYLE_SELECTION: choice must be recommended/reference/manual')
    s.setdefault('family','flat_2d_korean_cel_webtoon')
    # Require all five original components. Never replace them with generic 2D defaults.
    style_integrity.full_text(s)
    return s


def score_image_type(t,scene):
    text=norm_text(scene.get('event_type'),scene.get('summary'),scene.get('emotion_primary'),scene.get('important_props'),scene.get('location'))
    score=3*contains_any(text,t.get('events',[]))+contains_any(text,t.get('keywords',[]))
    tid=t['id']
    if tid=='animal_encounter' and scene.get('animal'): score+=6
    if tid=='relationship' and scene.get('romance'): score+=5
    if tid=='clue_reveal' and scene.get('reveal'): score+=5
    if tid=='market_event' and '장터' in str(scene.get('location','')): score+=4
    if tid=='reaction' and int(scene.get('tension',1))>=4: score+=1
    return score


def choose_image_type(types,scene):
    scored=[(score_image_type(t,scene),t) for t in types]
    scored.sort(key=lambda x:(-x[0],x[1]['id']))
    if scored[0][0] <= 0:
        fallback=next(t for t in types if t['id']=='reaction')
        return 0,fallback
    return scored[0][0],scored[0][1]


def resolved_time(scene):
    req=scene.get('requested_time'); ev=str(scene.get('time_evidence','')).strip()
    if req in DARK and not ev:
        return ('day_in' if scene.get('indoors') else 'day','어두운 시간대 직접 근거가 없어 밝은 시간대로 자동 교정')
    return req,'대본 시간 근거 유지' if req in DARK else '밝은 시간대 유지'


def light_phrase(t):
    return {'day':'neutral daylight, even ambient fill','day_in':'neutral window daylight, even ambient fill',
            'dawn':'soft neutral dawn light, even ambient fill','dusk':'late daylight kept neutral, even ambient fill',
            'night_in':'local practical light with even ambient fill, surrounding tones stay neutral grey',
            'night_out':'neutral moonlight with even ambient fill, shadow areas still legible'}[t]


from image_filenames import image_filename

def safe_slug(s):
    s=re.sub(r'[<>:"/\\|?*\x00-\x1f]',' ',str(s)); s=re.sub(r'\s+','_',s).strip(' ._')
    return s[:60] or 'scene'


def full_style_prompt(style):
    """Unabridged original style, identical for basic/economy and all output paths."""
    return style_integrity.full_text(style)


def compose_prompt_text(scene,style,img_type,time_value):
    parts=['16:9 widescreen composition',
           'Scene: '+str(scene.get('summary','')).strip(),'Location: '+str(scene.get('location','')).strip(),
           'Lighting: '+light_phrase(time_value),'Image structure: '+img_type['shot']+'. '+img_type['composition'],
           'Primary emotion: '+str(scene.get('emotion_primary','')).strip()]
    chars=[str(x).strip() for x in scene.get('characters',[]) if str(x).strip()]
    if chars: parts.append('Characters present: '+', '.join(chars))
    props=[str(x).strip() for x in scene.get('important_props',[]) if str(x).strip()]
    if props: parts.append('Important props clearly readable: '+', '.join(props))
    if scene.get('crowd'): parts.append('Keep background crowd simplified and subordinate to the main subjects')
    if scene.get('continuity_note'): parts.append('Continuity lock: '+str(scene['continuity_note']).strip())
    if isinstance(scene.get('value_gate'),dict) and scene['value_gate'].get('visualization'):
        parts.append(scene['value_gate']['visualization'])
    parts.append('Do not invent people, props, weather, time of day, injuries, or supernatural effects not supported by the script evidence')
    return '. '.join(x.rstrip('. ') for x in parts if x)+'. '+full_style_prompt(style)


def compose_prompt(scene,style,img_type,time_value):
    text = compose_prompt_text(scene,style,img_type,time_value)
    visible = text[:-len(full_style_prompt(style))]
    errors = scene_value_guard.validate_gate(scene.get('value_gate'),prompt=text,
        evidence_text=visible,n=scene.get('n'),require_binding=True)
    if errors: raise scene_value_guard.ValueGateError(errors)
    return text


def bind_scene_reviews(a,styles,types,selection,reviewer):
    """Bind supplied APPROVED analysis to the actual deterministic prompts; no auto-review."""
    result = copy.deepcopy(a)
    sources = scene_value_guard.analysis_sources(result)
    style = resolve_selection(selection,styles,None)
    for scene, source in zip(result['scenes'], sources):
        _, kind = choose_image_type(types,scene); time,_ = resolved_time(scene)
        prompt = compose_prompt_text(scene,style,kind,time)
        scene['value_gate'] = scene_value_guard.bind_gate(scene.get('value_gate'),source,prompt,
            reviewer,prompt[:-len(full_style_prompt(style))],scene['n'])
    return result


def validate_final_values(result):
    scenes = result.get('scenes', [])
    if not isinstance(scenes,list) or not scenes: return ['VALUE: no final scenes']
    if [x.get('n') for x in scenes] != list(range(1,len(scenes)+1)):
        return ['VALUE: final scene ids must be 1..N']
    errors=[]
    style=result.get('style_lock',{}).get('STYLE_TAIL_FULL','')
    for s in scenes:
        text=s.get('final_prompt',''); visible=text[:-len(style)] if style and text.endswith(style) else text
        if not isinstance(s.get('value_source_text'),str) or not s['value_source_text'].strip():
            errors.append('VALUE: final source snapshot missing')
        errors += scene_value_guard.validate_gate(s.get('value_gate'),source=s.get('value_source_text'),
            prompt=text,evidence_text=visible,n=s.get('n'),require_binding=True)
    return errors


def build_final(a,styles,types,selection,mode='basic'):
    workflow_guard.require_mode(a.get('workflow'), selected=True)
    basic_errors=validate_analysis(a)
    if basic_errors: raise ValueError('; '.join(basic_errors))
    sources=scene_value_guard.analysis_sources(a)
    candidates=build_candidates(a,styles,3,mode)
    selected=resolve_selection(selection,styles,candidates)
    v=selected.get('visual_spec') or {}
    lock=style_integrity.make_lock(selected,selection,a.get('title',''))
    out={'version':VERSION,'mode':mode,'title':a.get('title'),'status':'SELECTED',
         'style_lock':lock,'style_source':selected.get('source'),'selected_style':{
             'id':selected['id'],'name':selected['name'],'visual_spec':v,
             'style_tail':selected.get('style_tail',''),'STYLE_TAIL_FULL':lock['STYLE_TAIL_FULL'],'reference_files':selected.get('reference_files',[]),
             'style_summary_ko':selected.get('style_summary_ko','')},
         'auto_style_lock':False,'scene_style_switch':False,'scenes':[]}
    used_image_names = set()
    for scene, source in zip(a['scenes'],sources):
        value_errors=scene_value_guard.validate_gate(scene.get('value_gate'),source=source,n=scene['n'],require_binding=True)
        if value_errors: raise scene_value_guard.ValueGateError(value_errors)
        iscore,itype=choose_image_type(types,scene); t,treason=resolved_time(scene)
        fname=image_filename(scene.get('start_sentence') or source, used_image_names)
        out['scenes'].append({ 'n':scene['n'],'script_quote':scene['script_quote'],'summary':scene['summary'],
          'start_sentence':scene.get('start_sentence'), 'start_idx':scene.get('start_idx'), 'end_idx':scene.get('end_idx'),
          'selected_style':{'id':selected['id'],'name':selected['name'],'source':selected.get('source')},
          'image_type':{'id':itype['id'],'name':itype['name'],'score':round(iscore,2),'hook':itype['hook']},
          'composition':itype['composition'],'shot':itype['shot'],'time':t,'time_reason':treason,
          'recommended_image_filename':fname,'final_prompt':compose_prompt(scene,selected,itype,t),
          'value_gate':copy.deepcopy(scene['value_gate']),'value_source_text':source})
        errors=style_integrity.prompt_errors(out['scenes'][-1]['final_prompt'],lock,'SCENE '+str(scene['n']))
        if errors: raise ValueError('; '.join(errors))
    errors=validate_final_values(out)
    if errors: raise scene_value_guard.ValueGateError(errors)
    out['scene_value_validation']=scene_value_guard.report([],len(out['scenes']))
    return out


def final_report(r):
    s=r['selected_style']; v=s.get('visual_spec',{})
    lines=[f"야담 이미지·화풍 최종 결과 V{VERSION}",f"작품: {r['title']}",
           f"선택 화풍: {s['name']} / 출처 {r.get('style_source')}",
           f"얼굴 상세: {v.get('face_design','')}",f"표정 방식: {v.get('expression_direction','')}",
           f"셀 명암: {v.get('shading','')}",f"팔레트: {v.get('palette','')}",
           '※ 사용자 선택 후 잠금된 화풍을 모든 장면에 동일 적용하며 장면별 자동 화풍 교체는 하지 않습니다.','']
    for x in r['scenes']:
        lines += [f"[씬 {x['n']}]",f"근거: {x['script_quote']}",f"장면: {x['summary']}",
                  f"화풍: {x['selected_style']['name']}",f"이미지 유형: {x['image_type']['name']}",
                  f"시간대: {x['time']} — {x['time_reason']}",f"구도: {x['composition']}",f"샷: {x['shot']}",
                  f"추천 파일명: {x['recommended_image_filename']}",'최종 IMAGE PROMPT:',x['final_prompt'],'']
    return '\n'.join(lines).rstrip()+'\n'


def write_style_snapshot(out, result, selection):
    """Internal source of truth; this is not an extra section in the Flow TXT."""
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    value_errors=validate_final_values(result)
    if value_errors: raise scene_value_guard.ValueGateError(value_errors)
    save_json(out/'scene-value-validation-last-run.json',scene_value_guard.report([],len(result['scenes'])))
    lock=result['style_lock']
    errors=style_integrity.lock_errors(lock,selection,result.get('title'))
    for scene in result.get('scenes',[]):
        errors+=style_integrity.prompt_errors(scene['final_prompt'],lock,'SCENE '+str(scene['n']))
    if errors: raise ValueError('; '.join(errors))
    save_json(out/'STYLE_SELECTION.json',selection)
    save_json(out/'STYLE_LOCK.json',lock)
    for name in ('selected-style.txt','선택화풍_STYLE_TAIL.txt'):
        (out/name).write_text(lock['STYLE_TAIL_FULL']+'\n',encoding='utf-8-sig')
    save_json(out/'style-validation-last-run.json',{
        'version':VERSION,'status':'PASS','sha256':lock['sha256'],
        'mode':result.get('mode'),'scene_count':len(result.get('scenes',[])),
        'scope':'Full style text checks only; not rendered-image validation'})


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--analysis',default='analysis.json')
    ap.add_argument('--styles',default=str(Path(__file__).with_name('STYLE_BANK.json')))
    ap.add_argument('--types',default=str(Path(__file__).with_name('IMAGE_TYPE_BANK.json')))
    ap.add_argument('--mode',choices=['basic','economy'],default='basic')
    ap.add_argument('--stage',choices=['candidates','bind-values','build'],default='candidates')
    ap.add_argument('--selection',default=None)
    ap.add_argument('--reviewer',default=None)
    ap.add_argument('--out',default='output')
    args=ap.parse_args()
    try:
        a=load_json(args.analysis); e=validate_analysis(a)
        if e:
            print('\n'.join('ERROR: '+x for x in e)); return 1
        styles=load_json(args.styles)['styles']; types=load_json(args.types)['types']; out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
        if args.stage=='candidates':
            r=build_candidates(a,styles,3,args.mode); save_json(out/'style-candidates.json',r)
            (out/'화풍후보_선택대기.txt').write_text(candidate_report(r),encoding='utf-8-sig')
            print(f"WAITING_STYLE_SELECTION: {len(r['candidates'])} candidates -> {out}"); return 0
        if not args.selection: raise ValueError('--selection STYLE_SELECTION.json required for build stage')
        selection=load_json(args.selection)
        if args.stage=='bind-values':
            if not args.reviewer: raise ValueError('--reviewer required to bind completed reviews')
            reviewed=bind_scene_reviews(a,styles,types,selection,args.reviewer)
            save_json(out/'analysis.json',reviewed)
            save_json(out/'scene-value-bind-last-run.json',dict(version=VERSION,status='BOUND',scene_count=len(reviewed['scenes']),scope=scene_value_guard.SCOPE))
            print('BOUND SCENE REVIEWS:',out/'analysis.json'); return 0
        r=build_final(a,styles,types,selection,args.mode)
        write_style_snapshot(out,r,selection)
        save_json(out/'recommendations.json',r); save_json(out/'화풍추천결과.json',r)
        report=final_report(r); (out/'recommendations.txt').write_text(report,encoding='utf-8-sig'); (out/'화풍추천결과.txt').write_text(report,encoding='utf-8-sig')
        (out/'selected-style.txt').write_text(full_style_prompt(r['selected_style'])+'\n',encoding='utf-8-sig')
        print(f"PASS V{VERSION}: {len(r['scenes'])} final scene prompts -> {out}"); print('SELECTED STYLE:',r['selected_style']['name']); return 0
    except Exception as ex:
        try: save_json(Path(args.out)/'scene-value-validation-last-run.json',scene_value_guard.report(getattr(ex,'errors',[str(ex)]),0,'pipeline'))
        except OSError: pass
        try: save_json(Path(args.out)/'style-validation-last-run.json',{'status':'FAIL','error':str(ex),'version':VERSION})
        except OSError: pass
        print('ERROR:',ex); return 1

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
