"""SYNTHETIC TEST DATA ONLY. Never use these approvals for a real manuscript."""
import copy
import scene_value_guard as guard

def make_gate(source, visible, role='narrative'):
    return {'primary':role,'flags':{k:k==role for k in guard.ROLES},
        'source_evidence':source,'reason':'Synthetic fixture: verifies schema and visible-text linkage, not semantic quality.',
        'visualization':visible,'prompt_evidence':visible,'discomfort_risk':'none',
        'discomfort_reason':'Synthetic non-graphic fixture for program testing only.',
        'mitigation':'','review_status':'APPROVED'}

def annotate_project(state,body,rows):
    import assemble
    for c,row in zip(state['chapters'],rows):
        source=guard.source_for_cut(body,c)
        visible=row['body'].split(', in ',1)[0]
        c['value_gate']=make_gate(source,visible)
        full=assemble.render_text(state,row)
        c['value_gate']=guard.bind_gate(c['value_gate'],source,full,'SYNTHETIC_TEST_FIXTURE',n=row['n'])
    return state

def reviewed_analysis(a,styles,types,sel):
    import recommend
    a=copy.deepcopy(a)
    sources=guard.analysis_sources(a)
    for s,source in zip(a['scenes'],sources):
        visible='Show the documented scene in context: '+s['summary'].rstrip('. ')
        s['value_gate']=make_gate(source,visible)
    return recommend.bind_scene_reviews(a,styles,types,sel,'SYNTHETIC_TEST_FIXTURE')

def reviewed_build_final(a,styles,types,sel,mode='basic'):
    import recommend
    return recommend.build_final(reviewed_analysis(a,styles,types,sel),styles,types,sel,mode)
