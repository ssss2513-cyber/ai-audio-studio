"""V2.7: one UPLOAD portrait and exact original style suffix; no image generation."""
import random
import re
import style_integrity
import scene_value_guard

SHOTS = {
 'long_shot':'Long shot of', 'medium_shot':'Medium shot of',
 'medium_close_up':'Medium close-up of', 'close_up_portrait':'Close-up of',
 'extreme_close_up':'Extreme close-up of', 'insert_shot':'Insert, detail of',
 'low_angle':'Low angle of', 'high_angle':'High angle of',
 'dutch_angle':'Dutch angle of', 'eye_level':'Eye level of',
 'birds_eye':'Overhead view of', 'worms_eye':"Worm's eye view of",
 'front_view':'Front view of', 'side_profile':'Side profile of',
 'three_quarter':'Three-quarter view of', 'from_behind':'From behind,',
 'over_the_shoulder':'Over-the-shoulder of', 'two_shot':'Two-shot of',
 'reaction_shot':'Reaction of', 'negative_space':'Negative space around',
 'wide_landscape':'Wide landscape of',
 'extreme_wide_establishing':'Extreme wide establishing shot of',
 'tiny_figure_vast_landscape':'Tiny figure in a vast landscape,',
 'frame_within_frame':'Framed by', 'foreground_blur':'Foreground blur over',
 'through_doorway':'Through a doorway,', 'between_pillars':'Between pillars,'}
CLOSE = {'medium_shot','medium_close_up','close_up_portrait','extreme_close_up'}
LIGHTS = {
 'day':'neutral daylight, even ambient fill',
 'day_in':'neutral window light, even ambient fill',
 'dawn':'soft neutral dawn light, even ambient fill',
 'dusk':'late daylight, light still neutral, even ambient fill',
 'night_in':'local lamp illumination with even ambient fill, surrounding tones stay neutral grey',
 'night_out':'neutral moonlight with even ambient fill'}
SAFE = 'shadow areas still legible, mid-key exposure, no text or watermark'

def character_prompts(state):
    """One UPLOAD portrait per registered character; never shorten the chosen style."""
    style=style_integrity.state_style(state)
    result=[]
    for group, anchors in [('principal',state.get('ingredients',[])),
                           ('supporting',state.get('subanchors',[]))]:
        for anchor in anchors:
            description=anchor.get('upload_text') or anchor['text']
            view=anchor.get('upload_view','front view')
            expression=anchor.get('upload_expression','neutral calm')
            upload=('Single figure portrait of '+description+', medium shot from waist up, '
                    +view+', '+expression+', plain flat neutral gray background, '
                    'soft even neutral lighting, subject fully isolated, '
                    'background is a plain backdrop only and not part of the character identity, '
                    'no shadows on ground, no color tint, no props no other figures, '+style)
            errors=style_integrity.prompt_errors(upload,state['style_lock'],'UPLOAD '+anchor['id'])
            if errors: raise ValueError('; '.join(errors))
            result.append(dict(id=anchor['id'],name=anchor.get('name') or anchor['id'],
                role=anchor.get('role') or 'character',group=group,anchor=anchor['text'],upload=upload))
    return result


def assign_shots(chapters, seed=None):
    """Use optional chapter shot_candidates to constrain semantics before sampling.
    S only CLOSE; two_shot only with explicit person_count == 2.
    No claim to reproduce original TIER1 quotas."""
    rng = random.Random(seed)
    output = []
    for c in chapters:
        choices = c.get('shot_candidates') or ['medium_shot','medium_close_up',
                    'close_up_portrait','long_shot','eye_level','three_quarter']
        choices = [s for s in choices if s in SHOTS
                   and (c.get('motion') != 'S' or s in CLOSE)
                   and (s != 'two_shot' or c.get('person_count') == 2)]
        if not choices:
            raise ValueError('no compatible shot candidate; fix plan, do not add people')
        output.append({'shot': rng.choice(choices)})
    return output

def render_text(state, row):
    """Requested @ID format plus the exact full style, inserted by code only."""
    style=style_integrity.state_style(state)
    chapter=state['chapters'][row['n']-1]
    anchors={x['id']:x for x in state.get('ingredients',[])+state.get('subanchors',[])}
    ids=row['tags']+row.get('subanchors',[])
    prefix=', '.join('@'+key+', '+anchors[key]['text'] for key in ids)
    body=row['body']
    if chapter['set_id']!='oneoff':
        sets={x['id']:x['anchor'] for x in state['sets']}
        body=body.replace('{SET}',sets[chapter['set_id']])
    light=LIGHTS[chapter['time']]
    if chapter['time']=='night_in' and chapter.get('light_variant',0)==1:
        light='neutral even indoor fill, local lamp illumination'
    suffix=[light,
        'reference defines face and garment identity only, pose and framing follow this description',
        'no text no modern objects no modern buildings, natural colors, '
        'shadow areas still legible, mid-key exposure, neutral white balance, no color cast']
    if state.get('aspect_16_9',True): suffix.append('16:9 composition')
    # A background-only scene retains the same em-dash structure without inventing a person.
    core=(prefix if prefix else 'No characters')+' — '+body.strip()+', '+', '.join(suffix)
    final=core+', '+style
    errors=style_integrity.prompt_errors(final,state['style_lock'],'SCENE '+str(row['n']))
    if errors: raise ValueError('; '.join(errors))
    return final


def render(state, row):
    """Production renderer; UPLOAD references are intentionally exempt."""
    prompt = render_text(state, row)
    chapter = state['chapters'][row['n']-1]
    visible = prompt[:-len(state['STYLE_TAIL'])].split(' — ', 1)[-1].split(', reference defines face', 1)[0]
    errors = scene_value_guard.validate_gate(chapter.get('value_gate'), prompt=prompt,
        evidence_text=visible, n=row['n'])
    if errors: raise scene_value_guard.ValueGateError(errors)
    return prompt
