# 장면 기능·불쾌감 검사 — 2.7.2 수정본 r1

사용자 제작 기준: 모든 본편 이미지에서 서사·해설·교육적 가치 중 최소 하나를 시각적으로 표현합니다. 동시에 불쾌감을 유발하는 연출을 피합니다. 이것을 유튜브 공식 합격 기준이나 플랫폼 승인으로 표시하지 않습니다.

## 제작자의 실제 검토
Claude가 원문 해당 컷과 작성할 그림을 읽고 각 장면의 value_gate를 작성합니다. 사용자가 JSON을 직접 작성하게 하지 않습니다. 단순히 true를 채우거나 모든 장면을 서사형으로 자동 승인하지 않습니다.
- narrative: 사건의 진행, 선택, 변화, 관계 또는 앞뒤 사건을 이해하는 데 필요한 맥락이 보이는가.
- explanatory: 단서·비교·원인·결과·상황이 화면에서 이해되는가.
- educational: 관찰·판단·배려·생활·문화·문제 해결의 의미를 화면과 해당 대본으로 이해할 수 있는가.
- 풍경이나 인물의 조용한 표정도 장소 전환·관계 변화·판단의 맥락을 명확히 전달하면 역할이 있습니다. 예쁘거나 배경이라는 이유만으로 일괄 탈락/합격시키지 않습니다.
- 인물의 외모·나이·장애·신분 자체를 불쾌 요소로 취급하지 않습니다. 잔혹한 확대, 혐오·역겨움·수치심을 유도하는 연출, 과도한 공포 묘사를 검토합니다.
- 위험 표현이 있으면 원문 사건을 조작하지 않고 행동·단서·반응 중심으로 다시 연출합니다. 컷을 임의 삭제/병합하거나 인물을 지어내지 않습니다.
- 이 검사는 본편 장면 대상입니다. STEP 1 UPLOAD 기준 초상은 제작용이라 제외합니다.

## 내부 기록
analysis.scenes[i].value_gate / state.chapters[i].value_gate에 아래를 저장합니다.
- primary: narrative, explanatory, educational, mixed.
- flags: narrative/explanatory/educational의 실제 boolean 3개. 최소 하나 true. 문자열 'false'는 허용하지 않습니다.
- source_evidence: 해당 컷 원문의 정확한 인용.
- reason: 무엇을 이해시키며 어떤 역할이 있는지 구체적으로 기록.
- visualization: 장면에 실제로 나타낼 행동·관계·단서의 영어 설명. 추천 경로는 이 문장을 프롬프트에 실제 삽입합니다.
- prompt_evidence: 실제 장면 프롬프트 안에 있는 시각적 표현의 정확한 일부. 서사/교육 같은 라벨만 적지 않습니다.
- discomfort_risk: none/low/medium/high/unknown. none/low만 진행 가능.
- discomfort_reason: 실제 확인한 연출과 판단 근거. low는 mitigation에 완화 방법까지 기록.
- review_status: 실제 대본·표현 의미 검토 뒤 APPROVED. 검토 전 PENDING.
- review_binding: 코드가 기록하는 검토 당시 원문/프롬프트/평가 내용 해시. 임의로 만들지 않습니다.

none/low는 검토자가 입력한 위험도이지 불쾌감이 0이라는 객관적 보장이 아닙니다. 실제 그림을 아직 보지 않았으면 이미지 검토는 NOT_REVIEWED로 남깁니다.

## 실제 실행 — Claude Flow 제작 경로
1. 원본 TXT 바인딩, 분석, 사용자 화풍 선택 및 --bind-style은 기존대로 실행합니다.
2. state.chapters의 모든 컷에 실제 검토한 value_gate를 작성하고 --plan / --cast 실행.
3. 8컷씩 본문을 작성합니다. 해당 장면의 prompt_evidence가 실제 body에 있도록 작성/검토한 후 --chunk N 실행.
4. 모든 장면의 검토가 끝나면 아래를 실행합니다.
```bash
python gates.py --root work --bind-values --reviewer Claude
python gates.py --root work --final
```
--bind-values는 미작성 필드를 채우거나 승인하지 않습니다. 이미 검토되어 APPROVED인 내용을 검사하고 현재 프롬프트와 연결합니다. 명령 자체는 의미 검토를 대신하지 않습니다.
문장·캐릭터·세트·화풍·검토 내용이 바뀌면 해당 내용을 다시 검토하고 --bind-values를 다시 실행합니다.
--final은 새 검사를 건너뛸 수 없습니다. 독립 검사기를 수동 실행해야만 적용되는 부속 문서가 아닙니다.

## 로컬 추천 경로
기존 TXT 1차 분석은 키워드 기반입니다. value_gate는 PENDING/unknown으로 초기화되며 스스로 안전/교육성을 승인하지 않습니다. Claude가 원문을 실제로 검토하여 source_file/source_sha256/start_idx/end_idx/start_sentence와 value_gate를 채웁니다.
```bash
python 대본분석_화풍추천.py --analysis work/analysis.json --stage bind-values --selection work/STYLE_SELECTION.json --reviewer Claude --out work
python 대본분석_화풍추천.py --analysis work/analysis.json --stage build --selection work/STYLE_SELECTION.json --mode basic --out work/result
```
recommend.py도 동일한 --stage bind-values / build를 지원합니다. basic/economy 기준은 같고, 캐시에도 원문·화풍·검토 기록을 보존합니다.

## 최종 파일과 실패 처리
최종 Flow 파일은 기존 STEP 1 / 캐릭터 UPLOAD / [대본 1~N] / ===프롬프트=== / [영어 프롬프트 1~N] 형식을 그대로 유지합니다. 내부 value_gate나 검사보고는 파일 본문에 넣지 않습니다. 대본 목록만 첫 30자, 원본/화풍/얼굴 묘사는 전체를 보존합니다.
실패 시 VALUE 28처럼 컷 번호와 사유를 출력하고 최종 출력에서 차단합니다. 이전 성공 파일이 남아 있어도 현재 결과로 전달하지 않습니다. validation-last-run.json / scene-value-validation-last-run.json을 확인합니다.

## 자동 검사의 한계
코드는 원문 인용·표현문구 존재·필드형식·변경 여부·일부 위험 어구를 검사합니다. 인용이 실제로 사건을 뒷받침하는지, 감정이 적절한지, 실제 이미지가 그 장면을 표현했는지는 Claude/제작자의 실제 의미·시각 검토가 필요합니다. 프로그램이 생성 이미지를 보았거나 유튜브 심사를 통과했다고 표시하지 않습니다.
