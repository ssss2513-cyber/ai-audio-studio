#!/usr/bin/env python3
"""Offline package readiness check. Does not generate prompts or images."""
import argparse
import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

VERSION = '2.7.10'

def check(root):
    root = Path(root).resolve()
    errors = []
    count = 0
    try:
        manifest = json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8-sig'))
        if manifest.get('version') != VERSION:
            raise ValueError('PACKAGE_MANIFEST version mismatch')
        records = manifest['files']
        for name, item in records.items():
            if Path(name).name != name or name in ('.','..'):
                errors.append('Unsafe package filename: ' + name)
                continue
            path = root/name
            if not path.is_file():
                errors.append('MISSING: ' + name)
                continue
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != item['sha256']:
                errors.append('CHANGED: ' + name)
                continue
            if path.suffix == '.py':
                try:
                    ast.parse(data.decode('utf-8-sig'), filename=str(path))
                except (SyntaxError, UnicodeError) as exc:
                    errors.append('SYNTAX: ' + name + ': ' + str(exc))
            count += 1
        if not errors:
            modules = manifest['import_modules']
            code = ('import sys, importlib; sys.path.insert(0, sys.argv[1]); '
                    '[importlib.import_module(n) for n in sys.argv[2:]]; '
                    'print("IMPORTS_OK")')
            run = subprocess.run([sys.executable, '-B', '-c', code, str(root), *modules],
                                 capture_output=True, text=True, encoding='utf-8', timeout=30)
            if run.returncode:
                errors.append('IMPORT: ' + (run.stderr or run.stdout).strip())
        optional = [n for n in manifest.get('optional_reference_images', []) if not (root/n).is_file()]
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
        errors.append(str(exc)); optional = []
    return {'version': VERSION, 'status': 'READY' if not errors else 'FAIL',
            'tools_directory': str(root), 'checked_runtime_files': count,
            'errors': errors, 'optional_reference_images_not_copied': optional,
            'scope': 'File existence, hashes, Python syntax and imports only; not generation validation'}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = ap.parse_args()
    report = check(args.root)
    try:
        (args.root/'SETUP_REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    except OSError as exc:
        report['errors'].append('REPORT_WRITE: ' + str(exc)); report['status'] = 'FAIL'
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'READY' else 1

if __name__ == '__main__':
    raise SystemExit(main())
