import json, tempfile, unittest
from pathlib import Path
import recommend
from test_value_support import annotate_project, reviewed_analysis, reviewed_build_final
import importlib.util
HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('analyzer',HERE/'대본분석_화풍추천.py')
analyzer=importlib.util.module_from_spec(spec); spec.loader.exec_module(analyzer)

class V25Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.styles=recommend.load_json(HERE/'STYLE_BANK.json')['styles']
        cls.types=recommend.load_json(HERE/'IMAGE_TYPE_BANK.json')['types']
        cls.a=analyzer.auto_analyze_script(HERE/'샘플대본_로맨스_V25.txt',6)

    def test_analysis_valid(self):
        self.assertEqual(recommend.validate_analysis(self.a),[])
    def test_no_false_dragon_from_jungyo(self):
        self.assertEqual(self.a['global_keyword_counts']['animal'],0)
    def test_no_false_temple_from_sijeol(self):
        self.assertNotIn('산사',[s['location'] for s in self.a['scenes']])
    def test_candidates_wait(self):
        r=recommend.build_candidates(self.a,self.styles)
        self.assertEqual(r['status'],'WAITING_STYLE_SELECTION')
        self.assertFalse(r['auto_style_lock'])
    def test_top_romance(self):
        r=recommend.build_candidates(self.a,self.styles)
        self.assertIn('로맨스',r['candidates'][0]['name'])
    def test_every_candidate_has_face_detail(self):
        r=recommend.build_candidates(self.a,self.styles)
        for c in r['candidates']:
            self.assertTrue(c['visual_spec']['face_design'])
            self.assertIn('eyes',c['visual_spec']['face_design'])
    def test_unselected_rejected(self):
        with self.assertRaises(ValueError):
            recommend.resolve_selection({'status':'WAITING_STYLE_SELECTION'},self.styles,None)
    def test_recommended_lock_after_choice(self):
        sel={'status':'SELECTED','choice':'recommended','recommended':{'style_id':'joseon_romance_emotional'}}
        r=reviewed_build_final(self.a,self.styles,self.types,sel)
        self.assertEqual({s['selected_style']['id'] for s in r['scenes']},{'joseon_romance_emotional'})
    def test_full_face_style_original_in_every_prompt(self):
        sel={'status':'SELECTED','choice':'recommended','recommended':{'style_id':'joseon_romance_emotional'}}
        r=reviewed_build_final(self.a,self.styles,self.types,sel)
        self.assertTrue(all(s['final_prompt'].endswith(r['style_lock']['STYLE_TAIL_FULL']) for s in r['scenes']))
    def test_reference_selection(self):
        v={'line_art':'clean thin closed outlines','face_design':'adult Korean faces with oval jawlines, almond eyes, dark irises, natural brows, straight noses, defined lips, opaque skin planes','expression_direction':'subtle eye and mouth micro-expressions','shading':'hard two-tone cel shadows','palette':'cool jade blue plum cream palette'}
        sel={'status':'SELECTED','choice':'reference','reference':{'reference_file':'ref.png','profile':{'name':'REF','visual_spec':v,'style_tail':', '.join(v.values())}}}
        r=reviewed_build_final(self.a,self.styles,self.types,sel)
        self.assertEqual(r['selected_style']['name'],'REF')
        self.assertTrue(all(s['selected_style']['id']=='reference_user_style' for s in r['scenes']))
    def test_reference_requires_full_spec(self):
        sel={'status':'SELECTED','choice':'reference','reference':{'profile':{'name':'BAD','visual_spec':{'line_art':'x'},'style_tail':'x'}}}
        with self.assertRaises(ValueError): reviewed_build_final(self.a,self.styles,self.types,sel)
    def test_dark_without_evidence_becomes_day(self):
        scene=dict(self.a['scenes'][0]); scene['requested_time']='night_out'; scene['time_evidence']=''; scene['indoors']=False
        self.assertEqual(recommend.resolved_time(scene)[0],'day')
    def test_style_bank_all_detailed(self):
        for s in self.styles:
            self.assertEqual(recommend.validate_visual_spec(s.get('visual_spec',{})),[])
            self.assertTrue(s.get('style_tail'))

if __name__=='__main__': unittest.main(verbosity=2)
