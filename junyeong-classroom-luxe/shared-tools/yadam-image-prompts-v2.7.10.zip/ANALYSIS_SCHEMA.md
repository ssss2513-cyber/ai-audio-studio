# 2.7.10: WORKFLOW_RULES.md 우선. 아래 자료의 순서와 충돌하면 현재 순서를 따릅니다.
[2.7.2 수정본 r1 현재 실행 계약]
실행 준비는 CLAUDE_PROJECT_INSTRUCTIONS.md의 첫 단계와 PACKAGE_MANIFEST.json을 따릅니다.
원본 TXT/body.json/script-map.json의 원문 전체는 보존합니다.
[대본 1~N] 및 script-starts.txt의 표시 문장만 원문 첫 문장의 앞 30자(공백·문장부호 포함, 번호 제외)입니다.
30자 이하 문장은 그대로 쓰며, 말줄임표를 새로 붙이지 않습니다.
화풍·얼굴 상세 원문은 30자 제한 대상이 아닙니다. 모든 UPLOAD/장면에서 원문 전체를 유지합니다.
아래에 남은 원문 전체 출력 문구가 있으면 내부 원문 보존에만 적용하며, 표시 규격은 이 계약을 따릅니다.

# 대본 분석 및 화풍 선택 스키마 — 2.7.2 수정본 r1

## analysis.json
필수: `title`, `genre_primary`, `genre_secondary`, `tone`, `period`, `global_flags`, `scenes`.
각 scene은 `n`, `script_quote`, `summary`, `characters`, `location`, `indoors`, `requested_time`, `time_evidence`, `emotion_primary`, `tension`, `event_type`, `important_props`를 가진다.

## 2단계 출력: style-candidates.json
대본 분석 뒤 `STYLE_BANK.json`을 점수화해 상위 후보 3개를 만든다. **후보는 추천일 뿐 자동 선택값이 아니다.**
각 후보에는 `visual_spec` 전체와 `style_tail`을 포함한다.

## 3단계 입력: STYLE_SELECTION.json
### 추천 화풍 사용
```json
{"version":"2.7","status":"SELECTED","choice":"recommended","recommended":{"style_id":"joseon_romance_emotional"},"lock_after_selection":true,"allow_scene_style_switch":false}
```
### 레퍼런스 화풍 사용
```json
{"version":"2.7","status":"SELECTED","choice":"reference","reference":{"reference_file":"사용자첨부.png","profile":{"name":"레퍼런스 화풍","visual_spec":{"line_art":"...","face_design":"...","expression_direction":"...","shading":"...","palette":"..."},"style_tail":"..."}},"lock_after_selection":true,"allow_scene_style_switch":false}
```
### 직접 화풍
```json
{"version":"2.7","status":"SELECTED","choice":"manual","manual":{"name":"사용자 지정 화풍","style_tail":"상세 영어 화풍 원문","visual_spec":{"line_art":"...","face_design":"...","expression_direction":"...","shading":"...","palette":"..."}},"lock_after_selection":true,"allow_scene_style_switch":false}
```

`status=SELECTED`가 아니거나 choice가 없으면 최종 IMAGE PROMPT를 만들지 않는다.

모든 ...은 설명용 빈칸이며 실제 데이터에서는 상세 원문으로 채웁니다. STYLE_LOCK.json은 --bind-style이 생성합니다. 원문 문구를 축약한 상태로는 최종 게이트를 통과하지 못합니다.

## 2.7.2 수정본 r1 원문 대응 필드
새 분석의 각 scene에는 start_idx(포함), end_idx(제외), start_sentence(원문 첫 문장 전체)를 보존합니다.
script_quote는 해당 구간의 근거 인용, summary는 분석용 설명이며 [대본 1~N]에 대입하지 않습니다.
로컬 자동 분석은 이 세 필드를 원본에서 생성합니다. 절약형 캐시와 추천 결과에도 그대로 복사합니다.
최종 Flow TXT는 SCRIPT_SOURCE.json과 SOURCE_SCRIPT.txt를 기준으로 원문 대응을 검증합니다.


## 새 필수 필드
source_file과 source_sha256으로 실제 원본을 확인합니다. scenes에는 원문 인덱스와 전체 start_sentence를 보존합니다.
각 scenes/chapters에 value_gate를 기록하며 구체적인 계약과 순서는 SCENE_VALUE_RULES.md를 따릅니다.
ANALYSIS_TEMPLATE의 PENDING은 샘플 기본값일 뿐 통과 가능한 데이터가 아닙니다.
