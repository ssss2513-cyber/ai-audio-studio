# 2.7.10
WORKFLOW_RULES.md의 순서·18장·동의·ID 규칙을 먼저 적용합니다. 아래는 기존 구조 검사 참고입니다.

# 재구현 검증 도구 규칙 — V2.7

이 파일과 함께 배포된 gates.py, pools.py, assemble.py는 원본 코드의 복원본이 아니라 사용자 운영 지침을 바탕으로 새로 만든 도구다. 이 문서는 V2.7 실행 인터페이스이며 화풍원문_필독.md 및 사용자 지정 최종 형식을 함께 따른다. 의미 판단·대본 충실도·유튜브 정책·생성 이미지 품질은 별도 검토한다.

## 실행 환경

Python 3.9 이상, 표준 라이브러리만 사용한다. Python 파일과 STYLE_BANK.json, REFERENCE_CATALOG.json은 모두 같은 폴더에 둔다. 네트워크·API 키·유료 모델·외부 패키지가 필요 없다. 프롬프트를 검증·조립하는 도구이며 그림이나 완성된 영어 대본/장면을 자동 생성하지 않는다.

작업 폴더에서 실행하거나 `python /도구경로/gates.py --root /작업경로 --final` 형태로 실행한다.

## 입력 파일

- `body.json`: 비어 있지 않은 대본 문장 문자열 리스트.
- `state.json`: 아래 스키마. 대본에서 읽은 사실과 의미 판단을 바탕으로 클로드가 작성한다.
- `bodies/chunk1.json` ~ `chunk5.json`: 40컷일 때 8컷씩 배열. 각 파일 n은 각각 1~8, 9~16 등 정확한 오름차순. 모든 청크는 실제 본문을 포함해야 한다.

```json
{
  "TITLE":"작품명",
  "expected_count":40,
  "STYLE_TAIL":"--bind-style이 선택 원문 전체로 설정",
  "aspect_16_9":true,
  "n_action":10,
  "chapters":[{
    "start_idx":0,"end_idx":5,"intensity":"H","motion":"A",
    "time":"day","set_id":"yard","person_count":1,"minor_present":false
  }],
  "sets":[{"id":"yard","anchor":"a packed earth courtyard"}],
  "shots":[{"shot":"medium_shot"}],
  "ingredients":[{
    "id":"suyeon","age":30,"role":"Korean woman",
    "text":"a 30-year-old Korean woman, oval face, pinned hair, wearing a blue jeogori and navy chima",
    "valence":"중립","valence_quote":"대본에 실제로 있는 정확한 구절"
  }],
  "subanchors":[]
}
```

위 예시는 스키마 설명을 위해 챕터 하나만 보여준 것이므로 그대로 40컷 검증을 통과하지 않는다. 실제로는 chapters와 shots 각각 40개를 채운다.

밤·해질녘 컷은 대본 분석 근거를 추가한다. 해당 컷 자체에 밤 시간 근거가 있으면 `"time_evidence":"대본의 정확한 원문 구절"`을 넣는다. 같은 밤 사건이 끊김 없이 이어져 현재 컷에 시간 표현이 반복되지 않을 때만 `"time_continuity_from":12`처럼 직접 근거가 있는 앞 컷 번호를 가리킨다. 분위기·긴장감·비·눈·실내·가난한 집이라는 이유만으로 밤을 선택하지 않는다.

각 청크 행:

```json
{"n":1,"tags":["suyeon"],"subanchors":[],"main_verb":"walking","body":"Medium shot of @suyeon walking ... in {SET}, ..."}
```

이 행 역시 구조 예시이며 말줄임표 대신 실제 본문을 작성해야 한다. `main_verb`는 새 버전에서 명시적으로 추가한 필드다. 본문에 실제 등장하는 주된 진행형 동사 한 개를 소문자로 쓴다. 코드가 의미상 주동사를 판별하는 것은 아니므로 클로드가 일치 여부를 검토한다.

## 지원 명령

1. `python gates.py --api`: 인터페이스와 차이점 요약.
2. `python gates.py --style "화풍 영어"`: 금지 표현·빈 문자열·미해결 자리표시자·줄바꿈 검사 후 그대로 출력. 원문을 자동 삭제/치환하지 않으며 STYLE_TAIL 저장은 작성자가 한다.
3. `python gates.py --plan`: 수량·연속 대본 범위·샷·A/S/N·강도·시간대 검사.
4. `python gates.py --cast`: 계획 + 배역 ID·나이·근거 인용 검사.
5. `python gates.py --chunk 3`: 계획·배역·1~3번 청크 전체 검사. 누적 동사를 매번 원본에서 다시 센다.
6. `python gates.py --swap "12=medium_close_up"`: 계획과 배역 검사를 통과하는 변경만 state.json에 저장한다. 실패 시 원본을 덮어쓰지 않는다. 성공 후 해당 컷 본문의 샷 문구도 클로드가 수정하고 청크/최종 검증을 다시 수행한다.
7. `python gates.py --final`: 계획·배역·모든 청크 검사 후 output 폴더에 결과 기록. 실패하면 종료 코드 1. 성공하면 0.

## 자동 검사 범위

- 대본 인덱스는 0부터 시작한다. start_idx 포함, end_idx 제외. 모든 문장을 처음부터 끝까지 중복·누락 없이 덮는다.
- 컷 수 기본 100. 다른 수량은 expected_count에 명시한다. A 목표 기본 10/40컷. S는 전체의 15~25% (40컷에서 6~10). 짧은 컷 수에서는 이 정수 범위를 만족하지 못할 수 있으므로 계획 조정이 필요하다.
- 같은 감정 강도 5연속 금지. 완전한 8컷 블록에는 L/M/H 모두 필요. 상승·하강의 의미적 리듬은 사람이 별도 검토한다.
- 시간 허용값: day, day_in, dawn, dusk, night_in, night_out. 밝은 시간은 앞의 세 개, 어두운 시간은 뒤의 세 개로 계산한다.
- **대본 분석 후 밤 배경 최소화:** `dusk`·`night_in`·`night_out`은 해당 컷 범위 안의 정확한 원문 `time_evidence`가 있거나, 직접 근거 컷부터 현재 컷까지 어두운 시간이 끊기지 않는 `time_continuity_from`이 있을 때만 허용한다. 둘 다 없으면 실외는 `day`, 실내는 `day_in`을 우선한다. 비율 상한은 목표치가 아니며, 대본을 훼손하지 않는 범위에서 어두운 컷 수를 가장 적게 잡는다.
- dusk+night_in ≤30%, 어두운 시간 ≤40%, 밝은 시간 ≥45%, dusk ≤15%.
- `ACTION_EXEMPT:true` 사용 시 ACTION_EXEMPT_REASON 필수. `SEQ_EXEMPT:[1]`이면 SEQ_EXEMPT_REASONS에 `{"1":"대본상 이유"}` 필수. 시간 비율이 대본과 충돌하면 TIME_EXEMPT_REASON에 이유를 쓴다. TIME_EXEMPT_REASON은 비율 상한만 예외 처리하며 컷별 밤 근거는 면제하지 않는다. 실제 검증 보고에 예외가 기록된다. 예외가 허용됐다는 것과 장면의 타당성은 다르다.
- 앵커 최대 5, named 준앵커 최대 3. 모든 인물은 id/text/age를 가진다. 주연에는 valence와 대본의 정확한 valence_quote가 필요하다. 출력용 name/role과 UPLOAD 전용 upload_text/upload_view/upload_expression은 작성자가 확정한다. 인용의 존재만 코드가 검사하며 배역 판단의 옳고 그름은 클로드가 판단한다.
- 준앵커 chapters는 선택 사항이다. 지정 시 `"6,12,19"` 또는 `[6,12,19]`로 쓴다.
- 각 컷의 person_count는 나열한 주연+준앵커 수와 같아야 한다. 묘사할 모든 인물은 준앵커 등으로 등록한다. 군중 숫자를 임의로 줄이지 않는다.
- 본문 @참조와 tags/subanchors의 집합이 정확히 일치해야 한다. minor_present는 참조한 나이와 일치해야 한다.
- 세트가 oneoff이면 {SET}를 쓰지 않고, 본문 속 실제 배경 구절을 setting_evidence로 별도 지정한다. 그 구절이 본문에 존재하는지 검사한다. 배경 의미의 타당성은 사람이 판단한다.
- **M4 재구현:** 본문 슬롯만 A 60~80 / S 45~65 / N 30~50 단어. {SET} 제외, @id는 1단어, 하이픈 단어는 1단어. 광원·SAFE·앵커·화풍은 본문 예산에서 제외한다. 최종 조립 줄은 화풍 원문을 제외한 부분만 170단어 이하로 검사한다. 화풍 전체는 길이 때문에 줄이지 않는다. 준앵커 전용 자동 예외 없음.
- **M11 재구현:** A에는 알려진 이동축+지지축 표현, S에는 지지축+표정 표현 2개. 알려진 표현 목록은 gates.py 상수에 있으며 자연어 동의어 전체를 인식하지 않는다. 금지 표현과 부수효과 규모 표현 검사도 단순 어휘 검사다.
- S 샷은 medium_shot, medium_close_up, close_up_portrait, extreme_close_up 중 하나. 임의로 Medium을 앞에 덧붙이는 과거 예외는 사용하지 않는다.
- **M15 재구현:** 등록된 샷의 정확한 표면형으로 본문이 시작해야 한다. two_shot은 명시된 2인 장면에만 허용.
- **M16 재구현:** main_verb를 전체 컷에서 집계. 한 동사 최대 3회. 다른 보조 진행형 표현까지 모두 집계하는 검사는 아니다.
- **M18 재구현:** 0명 no people / 1명 one figure only / 2명 two figures / 3명 three figures 등 필수. 인원 신호와 solo 모순 검사. 모든 자연어 모순을 판별하지는 않는다.
- 최종 결과에는 등록된 @인물태그를 유지한다. 중괄호 자리표시자와 프롬프트 내부 줄바꿈은 없어야 한다. @ID 소유격 접미사는 금지한다.

원본 M2/M3/M6/M10/M12의 완전 재현, TIER1_STRONG 비율, UPLOAD 전용 의상 분리, 30개 색상 필터, 의미 기반 최적 분할은 구현하지 않았다. 이 기능들이 자동으로 된다고 보고하지 않는다. 단어 제한이나 정규식 통과를 유튜브 정책 승인으로 해석하지 않는다.

## Python 함수

`gates.load_script('script.txt')`: UTF-8 TXT의 비어 있지 않은 줄을 문장 목록으로 읽는다. 한 줄에 여러 문장이 있으면 먼저 클로드가 경계를 정리해 body.json을 작성한다. 자동 한국어 문장 분리기가 아니다.

`gates.split_chapters(body,40,want)`: want는 정확히 39개의 오름차순 내부 경계 인덱스. 이를 그대로 보존한다. want 생략 시 문장 수 균등 분할이며 서사 최적화가 아니다.

`pools.cast(specs,seed=123)`: specs에 id, age, role, valence, valence_quote, clothing, hair 필수. 묘사는 영어, valence는 선역/위엄/악역/중립. 선택 face로 대본상 특징 고정 가능. 의상에 {COLOR}를 명시한 경우에만 색상 추첨. 나이·신분·성별·도덕성을 무작위로 바꾸지 않는다. seed와 결과를 저장해 작품 안에서 유지한다.

`assemble.assign_shots(chapters,seed=123)`: 각 챕터의 선택적 shot_candidates 목록에서 샷을 고른다. S·2인 제약 적용. 의미에 맞는 후보를 클로드가 먼저 정해야 한다.

## 산출물과 실패 보고

--final 성공 시 output/prompts.txt, cut-plan.json, style.txt, validation.json과 `output/[대본제목]_flow.txt`를 생성한다. 대본 제목은 state.json의 TITLE을 사용하며, Windows 파일명에 쓸 수 없는 기호는 공백으로 정리한다. 검증결과에는 실제 최종 TXT 파일명, 검사 범위와 사용한 예외를 기록한다. 클로드는 대본 의미 검토 결과를 보완한다.

매 --final 실행은 작업 폴더의 validation-last-run.json에 PASS/FAIL을 기록한다. 실패 시 이전 성공 파일은 남을 수 있으므로 종료 코드와 마지막 보고를 먼저 확인한다. 이전 파일을 현재 입력이 통과한 결과로 전달하지 않는다.

테스트: `python -m unittest -v test_style_integrity test_v25`. 테스트 데이터는 기능 검사용 가상 데이터이며 실제 영상용 대본/프롬프트가 아니다.

## 1.1 추가: 캐릭터 프롬프트 별도 출력

배역이 정해지면 `python gates.py --characters`를 실행한다. 선택 바인딩을 완료한 state.json, STYLE_LOCK.json, STYLE_SELECTION.json과 body.json이 필요하며 chapters/shots/청크는 아직 없어도 된다. 앵커의 text에 얼굴·머리·나이·의상을 작성해야 유용한 참고 프롬프트가 된다. 누락 외형을 도구가 추측해서 추가하지 않는다.

output/character-prompts.txt — 주연·조연 각각 UPLOAD 상반신 초상 1개, ID별로 정리.
output/characters.json — ID, 선택적 name, principal/supporting 구분, 원본 anchor, upload.
output/character-validation.json — 배역·스타일 검사 결과와 인물/프롬프트 수.

각 이미지의 영어 프롬프트 부분만 생성 도구에 입력한다. 이름/ID 제목은 이미지 안에 그릴 글자가 아니다. 같은 anchor와 STYLE_TAIL을 그대로 사용하므로 별도 배역 추첨을 하지 않는다. 일반적인 참고 자세만 추가하며 대본의 새 사건을 만들지 않는다. 연령에 맞는 자연스러운 자세를 지시한다.

--final도 이 세 파일을 현재 앵커 기준으로 다시 출력한다. 따라서 최종 장면과 캐릭터 파일의 외형 정의가 일치한다. 사용자는 원하는 경우 character-prompts.txt를 캐릭터프롬프트.txt로, characters.json을 캐릭터설정.json으로 복사해 전달받을 수 있다.

매 --characters 실행은 character-validation-last-run.json에 PASS/FAIL을 기록한다. 실패하면 이전 성공 파일을 현재 결과로 전달하지 않는다. 캐릭터 검사는 어휘/배역 구조 검사이며 이미지 생성이나 얼굴 일관성 보장이 아니다. 캐릭터 기준 프롬프트는 본편 40컷에 포함하지 않으며 A/S/N 어절 예산은 장면 본문에만 적용한다.
## 1.2 추가: [대본 1~40] 원문 시작문장 목록

--final 성공 시 output/script-starts.txt와 output/script-map.json도 필수 생성한다.
script-starts.txt는 [대본 1~N] 아래에 '번호. 원문 첫 문장'을 출력한다. 시작문장은 body.json[chapter.start_idx]에서 그대로 추출하며 번역·요약·잘라내기를 하지 않는다. 모든 프롬프트 행 번호와 일치한다.
script-map.json은 n, start_idx, end_idx, start_sentence, sentences(해당 컷의 전체 원문 문장 배열)를 저장한다. 중복되는 원문 문장도 인덱스로 구분하며, 검증된 구간은 원문 전체를 중복·누락 없이 덮는다.
원본 첨부 TXT를 body.json으로 전처리할 때 문장 내용을 고쳐 쓰지 않는 것은 작성자의 책임이다. 이 도구는 body.json에서의 보존·대응만 보장하며 외부 원문 파일과의 자동 대조 기능은 없다.
사용자에게 대본_시작문장.txt / 대본_컷대응.json으로 복사해 전달할 수 있다. 편집용 대본 목록을 요청받으면 채팅에도 표시하고 파일도 제공한다.
## 1.3 출력 형식 및 최종 파일명
--final은 `state.json`의 `TITLE`을 사용한 `[대본제목]_flow.txt`에 STEP 1의 캐릭터별 UPLOAD, [대본 1~N], ===프롬프트===, [영어 프롬프트 1~N]을 순서대로 모아 출력한다. 예: TITLE이 `쫓겨난 과부를 재워준 두부장수`이면 `쫓겨난 과부를 재워준 두부장수_flow.txt`가 생성된다. 파일명에 쓸 수 없는 기호는 공백으로 정리한다. prompts.txt와 통합 TXT의 장면 프롬프트에는 1. / 2. / 3. 번호가 붙는다. 번호는 어절 검사 후 붙이는 편집용 표시이며 생성 이미지에 그릴 문자가 아니다. 기존 내용과 검사 규칙은 바꾸지 않는다. 사용자에게는 이 통합 TXT를 우선 첨부한다.


[V2.7.2-r2 본편 프롬프트 형식]
- [영어 프롬프트 1~N]의 각 줄은 `003 | 대본 원문 30자 | @[배경] @[인물] 실제프롬프트...` 형식을 사용합니다.
- `003 | ...`의 저장 문구는 해당 컷 대본 첫 문장의 앞 30자 그대로여야 하며 임의 요약 금지입니다.
- `@[...]` 에셋 호출은 해당 컷의 배경 set_id와 tags/subanchors와 일치해야 합니다.
- 실제 이미지 저장 파일명도 `대본원문30자.png` 기준으로 사용합니다.


[V2.7.5 이미지 저장 파일명 — 현재 프로젝트 적용 기준]
- 실제 이미지 파일명 앞에 컷 번호와 밑줄(숫자_)을 붙이지 않습니다.
- 본편은 `대본원문30자.png`, 에셋은 `영문ID.png` 또는 해당 에셋 이름으로 저장합니다.
- 예: `003_문 안에서 빗장이 밀리는 소리가 났지요.png` → `문 안에서 빗장이 밀리는 소리가 났지요.png`.
- Flow 프롬프트의 `003 | 원문30자 | @[에셋] 프롬프트` 번호와 대본 목록 번호는 순서 대응을 위해 유지합니다.
- 파일명 금지 문자는 공백으로 정리하며 이름이 겹치면 뒤에 `_중복2`, `_중복3`을 붙여 덮어쓰지 않습니다.
- image_filenames.py를 사용하고 image-filenames.json에 컷 번호와 저장 파일명 대응을 보존합니다.
- 이 규칙은 기본/절약형 모두 같으며 화풍·얼굴·캐릭터·컷 수·원문 보존 규칙은 유지합니다.
