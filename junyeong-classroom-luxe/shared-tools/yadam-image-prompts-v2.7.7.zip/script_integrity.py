#!/usr/bin/env python3
"""V2.7.3: full original-script integrity with separate 30-character list display.

Original source is never shortened. Only rendered list rows use a 30-character prefix.
Only outer layout whitespace and explicit 제목:/작품명: title lines are excluded.
The local sentence splitter is conservative and is not a Korean NLP parser.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

VERSION = '2.7.3'
DISPLAY_LIMIT = 30

def display_start(sentence):
    """Display only: first 30 Unicode code points, including spaces/punctuation."""
    if not isinstance(sentence, str):
        raise TypeError('start sentence must be text')
    return sentence[:DISPLAY_LIMIT]

SNAPSHOT = 'SOURCE_SCRIPT.txt'
MANIFEST = 'SCRIPT_SOURCE.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def body_digest(body):
    return digest(json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))


def decode_bytes(raw):
    for enc in ('utf-8-sig', 'cp949', 'euc-kr'):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            pass
    raise ValueError('SCRIPT_SOURCE: cannot decode original TXT without replacing characters')


def extract_title_and_body(text):
    title = ''
    lines = []
    for line in text.replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        m = re.match(r'^(?:작품명|제목)\s*[:：]\s*(.+)$', line.strip())
        if m and not title:
            title = m[1].strip()
        else:
            lines.append(line)
    return title, '\n'.join(lines)


def sentences_from_text(text):
    """Return full source units; never split within ... or at a character limit.

    A physical line is the fallback unit. Ordinary sentence punctuation followed
    by optional closing quotation marks and whitespace can divide that line.
    Interior whitespace/punctuation and authentic ellipses remain unchanged.
    """
    boundary = re.compile(r'''(?:(?<!\.)\.(?!\.)|[!?。！？]+)["'”’」』)\]]*(?=\s|$)''')
    result = []
    for line in text.replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        line = line.strip()
        if not line:
            continue
        start = 0
        for match in boundary.finditer(line):
            end = match.end()
            unit = line[start:end].strip()
            if unit:
                result.append(unit)
            start = end
        rest = line[start:].strip()
        if rest:
            result.append(rest)
    return result


def source_body(raw):
    text, encoding = decode_bytes(raw)
    _, body_text = extract_title_and_body(text)
    body = sentences_from_text(body_text)
    if not body:
        raise ValueError('SCRIPT_SOURCE: original script is empty')
    return body, encoding


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def bind_source(root, source_path):
    """Read the actual input TXT, copy its bytes, and derive body.json from it.

    Never silently replace an incompatible existing body.json. A shortened output
    list is not an original source and must not be bound as one.
    """
    root, source = Path(root), Path(source_path)
    raw = source.read_bytes()
    text, _ = decode_bytes(raw)
    if re.search(r'^\[대본 1~\d+\]\s*$', text, re.M) or re.search(r'^STEP 1\s*$', text, re.M):
        raise ValueError('SCRIPT_SOURCE: supply the original manuscript, not a Flow output/start list')
    body, encoding = source_body(raw)
    root.mkdir(parents=True, exist_ok=True)
    body_path = root / 'body.json'
    if body_path.exists():
        existing = json.loads(body_path.read_text(encoding='utf-8-sig'))
        if existing != body:
            raise ValueError('SCRIPT_SOURCE: existing body.json differs from original TXT; '
                             'use a new work directory and rebuild from the original, not by guessing endings')
    snapshot = root / SNAPSHOT
    if snapshot.resolve() != source.resolve():
        temp = snapshot.with_suffix('.txt.tmp')
        temp.write_bytes(raw)
        temp.replace(snapshot)
    info = {'version': VERSION, 'source_name': source.name, 'snapshot': SNAPSHOT,
            'source_sha256': digest(raw), 'encoding': encoding,
            'body_sha256': body_digest(body), 'sentence_count': len(body),
            'policy': 'FULL_SOURCE_WITH_PREFIX30_DISPLAY',
            'scope': 'Exact text/indices; not proof of semantic sentence boundaries or source completeness'}
    write_json(root / MANIFEST, info)
    write_json(body_path, body)
    return body, info


def verified_source(root, body=None):
    root = Path(root)
    if not (root / MANIFEST).is_file() or not (root / SNAPSHOT).is_file():
        raise ValueError('SCRIPT_SOURCE: original TXT not bound; first run '
                         'gates.py --root WORK --bind-script ORIGINAL.txt')
    info = json.loads((root / MANIFEST).read_text(encoding='utf-8-sig'))
    raw = (root / SNAPSHOT).read_bytes()
    if digest(raw) != info.get('source_sha256'):
        raise ValueError('SCRIPT_SOURCE: original snapshot changed; refuse stale results')
    expected, encoding = source_body(raw)
    if body_digest(expected) != info.get('body_sha256') or len(expected) != info.get('sentence_count'):
        raise ValueError('SCRIPT_SOURCE: source manifest does not match original sentences')
    if body is not None and body != expected:
        mismatches = [i + 1 for i, (a, b) in enumerate(zip(body, expected)) if a != b] if isinstance(body, list) else []
        sample = ','.join(map(str, mismatches[:8]))
        raise ValueError('SCRIPT_SOURCE: body.json is shortened, rewritten or missing source text'
                         + (' (source sentence ' + sample + ')' if sample else ''))
    return expected, info


def source_errors(root, body):
    try:
        verified_source(root, body)
        return []
    except (OSError, ValueError, TypeError, KeyError) as exc:
        return [str(exc)]


def expected_starts(root, state, body):
    original, info = verified_source(root, body)
    chapters = state.get('chapters', [])
    if not chapters:
        raise ValueError('SCRIPT_START: chapters missing')
    previous = 0
    result = []
    for n, chapter in enumerate(chapters, 1):
        a, b = chapter.get('start_idx'), chapter.get('end_idx')
        if type(a) is not int or type(b) is not int or a != previous or not 0 <= a < b <= len(original):
            raise ValueError(f'SCRIPT_START {n}: source ranges must be continuous and complete')
        result.append(original[a])
        previous = b
    if previous != len(original):
        raise ValueError('SCRIPT_START: source tail is missing from chapter ranges')
    return result, info


def flow_errors(text, expected):
    """Compare output rows to exact 30-character source prefixes; preserve original ellipses."""
    text = text.lstrip('\ufeff')
    heads = list(re.finditer(r'^\[대본 1~(\d+)\]$', text, re.M))
    if len(heads) != 1:
        return ['SCRIPT_START: exactly one [대본 1~N] heading required']
    start = heads[0]
    end = re.search(r'^===프롬프트===$', text[start.end():], re.M)
    section = text[start.end():start.end() + end.start()] if end else text[start.end():]
    errors, rows = [], []
    if int(start[1]) != len(expected):
        errors.append('SCRIPT_START: heading count differs from source plan')
    for line in section.splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r'(\d+)\. (.+)', line)
        if not match:
            errors.append('SCRIPT_START: invalid or additional text in source-start list')
            continue
        rows.append((int(match[1]), match[2]))
    if [n for n, _ in rows] != list(range(1, len(expected) + 1)):
        errors.append('SCRIPT_START: missing/duplicate/out-of-order row number')
    for n, value in rows:
        if 1 <= n <= len(expected) and value != display_start(expected[n-1]):
            errors.append(f'SCRIPT_START {n}: display must equal the first 30 source characters; '
                          'no summary, appended ellipsis or changes to source allowed')
    return errors


def validate_flow(root, state, body, text):
    try:
        starts, info = expected_starts(root, state, body)
        errors = flow_errors(text, starts)
        return errors, {'source_sha256': info['source_sha256'], 'start_count': len(starts),
                        'policy': 'FULL_SOURCE_WITH_PREFIX30_DISPLAY',
                        'max_start_characters': max(len(display_start(x)) for x in starts),
                        'max_source_start_characters': max(map(len, starts)), 'display_limit': DISPLAY_LIMIT}
    except (OSError, ValueError, TypeError, KeyError) as exc:
        return [str(exc)], {}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--source', help='Original manuscript TXT to bind; not a generated start list')
    action.add_argument('--flow', help='Finished Flow TXT or script-starts.txt to check')
    args = parser.parse_args()
    errors, counts = [], {}
    try:
        if args.source:
            body, counts = bind_source(args.root, args.source)
        else:
            state = json.loads((args.root/'state.json').read_text(encoding='utf-8-sig'))
            body = json.loads((args.root/'body.json').read_text(encoding='utf-8-sig'))
            text = Path(args.flow).read_text(encoding='utf-8-sig')
            errors, counts = validate_flow(args.root, state, body, text)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        errors = [str(exc)]
    report = {'version': VERSION, 'status': 'FAIL' if errors else 'PASS', 'errors': errors,
              'counts': counts, 'scope': 'Original-source text fidelity; not semantic or image-quality approval'}
    write_json(args.root/'script-validation-last-run.json', report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
