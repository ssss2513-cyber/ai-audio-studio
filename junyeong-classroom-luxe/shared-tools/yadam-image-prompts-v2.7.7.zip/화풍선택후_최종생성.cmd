@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist "%~dp0output\analysis.json" (
  echo [FAIL] output\analysis.json이 없습니다. 먼저 대본분석_화풍추천_실행.cmd를 실행하세요.
  pause
  exit /b 1
)
if not exist "%~dp0output\STYLE_SELECTION.json" (
  echo [FAIL] output\STYLE_SELECTION.json이 없습니다.
  pause
  exit /b 1
)
set "MODE=basic"
findstr /C:"\"processing_mode\": \"economy\"" "%~dp0output\analysis.json" >nul && set "MODE=economy"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0대본분석_화풍추천.py" --analysis "%~dp0output\analysis.json" --mode %MODE% --stage build --selection "%~dp0output\STYLE_SELECTION.json" --out "%~dp0output"
) else (
  python "%~dp0대본분석_화풍추천.py" --analysis "%~dp0output\analysis.json" --mode %MODE% --stage build --selection "%~dp0output\STYLE_SELECTION.json" --out "%~dp0output"
)
if errorlevel 1 (
  echo [FAIL] STYLE_SELECTION.json이 SELECTED 상태인지, 선택 정보가 완전한지 확인하세요.
) else (
  echo [PASS] 선택 화풍 원문과 연출 자료를 저장했습니다. 최종 Flow TXT는 Claude 장면 작성 후 gates.py --final로 완성합니다.
)
pause
