## 2.7.2 수정본 r1 — 실제 생성·출력에 연결된 필수 검사
- 본편 이미지마다 서사/해설/교육적 가치 중 하나 이상을 실제 행동·관계·단서로 표현합니다. 불쾌감을 주는 자극적 연출은 피합니다.
- Claude가 원문과 실제 프롬프트를 검토하고 SCENE_VALUE_RULES.md 규격의 value_gate를 analysis.scenes와 state.chapters에 작성합니다. 사용자에게 JSON이나 파일명을 스스로 만들라고 하지 않습니다.
- flags만 true로 채우지 않습니다. 원문 근거 source_evidence, 실제 화면 표현 visualization, 프롬프트에 존재하는 prompt_evidence, 불쾌감 검토 근거가 필요합니다. 비어 있거나 검토 전이면 진행을 멈추고 AI가 해당 장면을 보완합니다.
- 사용자 화풍 선택, 상세 화풍/얼굴 원문 전체 유지, 기본/절약형, 대본목록 30자 규칙은 그대로입니다. 새 검사 내용은 최종 Flow 본문에 별도 섹션으로 출력하지 않습니다.
- 모든 청크의 의미 검토 후 `python gates.py --root work --bind-values --reviewer Claude`를 실행한 다음 `--final`을 실행합니다. 분석/표현/화풍을 수정했다면 다시 검토·바인딩합니다. --bind-values는 자동 승인이 아닙니다.
- 로컬 추천 경로는 `--stage bind-values --reviewer Claude` 다음 `--stage build`를 사용합니다. 분석만 한 상태는 PENDING으로 남깁니다.
- STEP 1 UPLOAD는 본편 장면이 아니므로 새 장면 기능 검사를 요구하지 않습니다.
- 실제 이미지가 없으면 시각 검토 완료나 불쾌감 완전 제거, 유튜브 승인이라고 표현하지 않습니다.

# 실행 준비 — 2.7.2 수정본 r1 설치 복구 (대본 제작보다 먼저)

현재 작업 폴더가 비어 있다는 사실만으로 첨부/프로젝트 전체에 파일이 없다고 결론 내리지 않습니다.
1. 이 대화 및 프로젝트에서 실제 접근 가능한 첨부 목록/경로를 확인합니다. 경로를 추측하지 않습니다.
2. `실행파일복구_2.7.2수정본.txt`가 있으면 이것은 대본이 아니라 실행 가능한 Python 복구 파일입니다. 긴 내장 데이터는 읽어 출력하지 말고 컴퓨팅 도구로 실행합니다.
   `python "실제첨부경로/실행파일복구_2.7.2수정본.txt" --target "실제쓰기가능경로/yadam_tools_v272_r1"`
3. 복구가 없지만 이 버전의 ZIP/파일들이 있으면 실제 파일을 작업용 도구 폴더로 풀거나 복사한 뒤 `python setup_check.py`를 실행합니다. 원본/기존 산출물은 지우지 않습니다.
4. `SETUP_REPORT.json`의 실제 READY/누락/해시 오류와 `gates.py --api` 결과를 확인합니다. READY는 파일 준비 완료일 뿐 대본·화풍·이미지 검증 통과가 아닙니다.
5. 이 버전은 `PACKAGE_MANIFEST.json`에 나열된 파일만 필수로 요구합니다. assets.py, events.py, style_contract.py, production_settings.py는 이 버전의 파일/의존성이 아닙니다. 다른 버전의 이름을 필수로 추가하거나 빈 가짜 모듈을 만들지 않습니다.
6. 모듈은 도구 폴더에 두고, --root에는 대본 작업 폴더를 전달합니다. 예: `python "도구폴더/gates.py" --root "작업폴더" --api`.
7. 코드 실행 자체가 없거나 원본 파일에 접근할 수 없으면 실제 제한을 말합니다. 실행하지 않은 복구/검증을 완료했다고 하지 않습니다.

그다음 기존 기본/절약형 선택 → 대본 전체 분석 → 사용자 화풍 선택 → 본편 제작 순서를 지킵니다.
화풍 원문은 모든 UPLOAD/장면에 전체 유지합니다. 30자 제한은 [대본 1~N] 표시만 적용합니다.

---

# Claude 프로젝트 지침 — 정확한 산출물 형식 고정 2.7.2 수정본 r1

## 2.7.2 수정본 r1 대본 목록 30자 표시 / 원본은 전체 보존 — 기본/절약형 공통

- `[대본 1~N]`의 각 번호에는 **그 컷이 시작되는 원문 첫 문장의 앞 30자만** 넣습니다. 40컷/100컷 모두 같습니다.
- 문장이 길면 앞에서부터 정확히 30자까지만 출력합니다. 자동으로 `...`·`…`·`이하 생략`을 새로 붙이지 않습니다.
- 원문에 실제 있는 말줄임표, 따옴표, 문장부호는 보존합니다. 말줄임표 자체를 오류로 간주하거나 무조건 삭제하지 않습니다.
- `summary`와 `script_quote`는 분석용입니다. 시작문장 대신 출력하지 않습니다. 시작문장은 `body.json[chapter.start_idx]`에서 코드로 추출합니다.
- 원본 TXT를 먼저 바인딩해 생성된 `body.json`을 사용합니다. 잘린 목록/최종 Flow TXT를 원본으로 등록하지 않습니다. `body.json`을 요약하거나 문장 뒤를 추측해 채우지 않습니다.
- 원본이 없으면 잘린 문장의 뒷부분을 창작하지 않습니다. 실제 원본 TXT를 확보할 때까지 최종 출력 PASS를 내지 않습니다.
- 최종 TXT 전달 전 원본 스냅샷·body.json·컷 인덱스의 일치와 시작문장 표시값=원문[:30]을 검사합니다. 하나라도 다르면 FAIL이며 원본으로 돌아가 수정합니다.
- 절약형은 분석 설명만 줄입니다. 캐시에 `start_sentence` 전체와 `start_idx`, `end_idx`, 원문 파일/해시를 보존합니다. 표시용 `start_sentence_30`은 원문 앞 30자로 별도 계산합니다.
- 컷 수는 사용자가 정한 N을 유지합니다. 예시의 40은 고정 제한이 아닙니다. N=100이면 두 목록 모두 정확히 1~100입니다.
- 이 패치는 화풍은행·레퍼런스 이미지·얼굴 묘사·화풍 선택 절차·최종 출력 섹션을 변경하지 않습니다.

### 내부 필수 순서
대본을 받으면 Claude가 다음 작업을 수행합니다. 사용자가 JSON을 직접 만들 필요는 없습니다.

```bash
python gates.py --root work --bind-script "/실제첨부경로/대본.txt"
```

위 명령은 원본 바이트를 `work/SOURCE_SCRIPT.txt`에 복사하고 `SCRIPT_SOURCE.json`, `body.json`을 만듭니다.
이후 body.json을 읽어 대본 분석과 컷 경계를 정합니다. 기존 body.json이 원본과 다르면 몰래 덮어쓰지 않습니다.
새 작업 폴더에 원본을 바인딩하고 분석/컷 대응부터 다시 작성합니다. 원래 대본 파일은 수정하지 않습니다.

사용자 화풍 선택, --bind-style, --plan, --cast, 청크 검증, --final은 그대로 실행합니다.
--final은 대본 원문과 화풍 원문을 모두 검사한 뒤 기존 형식의 `[대본제목]_flow.txt`를 만듭니다.
다른 경로로 작성한 최종 TXT는 다음 대본 검사도 반드시 실행합니다.

```bash
python script_integrity.py --root work --flow "work/output/대본제목_flow.txt"
```

대본 검사 결과는 `script-validation-last-run.json`에 저장됩니다. 검사 보고를 Flow 본문에 붙이지 않습니다.
원본 파일 자체의 잘림 여부와 문장 경계의 의미적 타당성을 자동으로 보증하는 도구는 아닙니다.
줄바꿈만으로 끊어진 원문 단위는 최초 대본 검토에서 확인합니다. 잘린 원본에서 뒷문장을 추측하지 않습니다.


## V2.7 최우선 — 선택한 화풍 원문을 줄이지 않습니다

1. 대본 분석 뒤 사용자에게 추천/레퍼런스/직접 화풍 중 선택받는 절차를 유지합니다. 이미 선택했으면 같은 질문을 반복하지 않습니다. 선택 전 자동 잠금은 금지합니다.
2. 선택 화풍의 `style_tail`과 `visual_spec` 다섯 항목(line_art, face_design, expression_direction, shading, palette)을 원문 그대로 사용합니다. 선·얼굴·눈·눈썹·코·입·피부·머리·표정·명암·팔레트를 짧은 태그로 바꾸지 않습니다.
3. **기본/절약형 모두 최종 프롬프트 품질 규칙이 같습니다. 절약하는 것은 반복 분석/설명이지 화풍 문장이 아닙니다.** 작품캐시에도 상세 화풍 원문 전체를 저장합니다.
4. `STYLE_TAIL_FULL`은 코드가 선택 자료에서 조립·복사합니다. 이미 완전한 원문은 글자와 구두점까지 그대로 유지합니다. 원문에 포함된 필수 세부 문장은 임의로 요약·재번역·동의어 치환하지 않습니다.
5. 모든 캐릭터 UPLOAD와 모든 영어 장면 프롬프트 끝에 동일한 원문 전체를 **한 번씩 실제로** 붙입니다. 앞부분에 한 번만 쓰기, '동일 화풍', '위와 같음', '$STYLE_TAIL', '로맨스 2D'로 대체하기, 일부 컷에서 생략하기를 금지합니다.
6. 산출물에는 사용자가 정한 `STEP 1 → UPLOAD → [대본 1~N] → ===프롬프트=== → [영어 프롬프트 1~N]`만 씁니다. `FACE DESIGN LOCK:` 같은 새 제목/라벨을 붙이지 않습니다. 상세 문장은 기존 프롬프트 한 줄의 끝부분에 자연스러운 영어 원문으로 들어갑니다.
7. 사용자 예시의 보배/한도원, 복식, 짧은 화풍 문구는 형식 예시일 뿐 다른 작품에 자동 복사하지 않습니다. 현재 선택한 레퍼런스의 화풍을 예시의 기본 2D 문구로 덮어쓰지 않습니다.
8. 전체 170단어 제한 때문에 화풍을 줄이지 않습니다. 기존 A/S/N 본문 예산은 그대로이고, 170단어 검사는 **화풍 원문을 제외한 부분**에만 적용합니다. 원문 화풍은 이 예산에서 제외합니다.
9. 프로필이 누락되거나 손상되면 일반 2D로 조용히 대체하지 않습니다. 원본을 복구하거나 구체적인 누락을 확인한 뒤 진행합니다. 새 레퍼런스 이미지의 시각 분석은 Claude가 실제 이미지를 확인해 작성하며, 이 Python 코드가 이미지를 시각적으로 분석하는 것은 아닙니다.
10. 선택한 화풍이 기본 2D로 축약되어 나온 뒤 '풀버전으로 다시 만들어 드릴까요?'라고 묻지 않습니다. **처음부터 풀버전으로 생성하고, 전달 전에 누락을 해결합니다.** 이미지 생성기의 결과가 참고 이미지와 완전히 같다고 보장하지는 않습니다.

### 내부 실행 순서 — 사용자가 JSON을 직접 만들게 하지 않습니다
Claude가 사용자 선택을 `STYLE_SELECTION.json`에 기록하고 state.json/body.json/청크를 작성합니다.

```bash
python gates.py --root work --bind-style
python gates.py --root work --plan
python gates.py --root work --cast
python gates.py --root work --final
```

`--bind-style`은 선택한 원문을 `STYLE_LOCK.json` 및 `state.json`에 복사합니다. 대본/인물/장면 설정은 바꾸지 않습니다. `--final`은 현재 선택 자료, 저장 원문, 모든 UPLOAD, 모든 장면의 원문 일치를 검사한 뒤에만 최종 TXT를 저장합니다. 내부 결과 보고는 최종 Flow TXT 안에 추가하지 않습니다.

다른 작업 경로에서 만든 완성 TXT도 다음과 같이 검사합니다.

```bash
python style_integrity.py --flow "작품_flow.txt" --lock work/STYLE_LOCK.json --selection work/STYLE_SELECTION.json --report work/style-check.json
```

화풍이 바뀌면 기존 캐시를 재사용하지 않고 사용자 선택에서 원문을 다시 바인딩합니다. 캐릭터 참조 전용 검사인 `flow_character_preflight.py`만 통과했다고 화풍 검사를 통과한 것으로 취급하지 않습니다.


## 최우선 규칙
- 최종 산출물은 사용자가 준 형식 그대로만 만든다.
- 추가 섹션, 추가 설명, 추가 태그, 추가 보고를 붙이지 않는다.
- 최종 결과 파일은 `[대본제목]_flow.txt` 한 개다.
- 최종 결과 파일 안의 순서는 반드시 아래와 같다.

```text
STEP 1

=== 영문ID (한글이름, 영문역할 / 챕터 -) ===
=== 영문ID UPLOAD ===
Single figure portrait of ...

[다음 캐릭터도 동일 반복]

[대본 1~40]
1. [대본 원문 첫 문장의 앞 30자]
2. [대본 원문 첫 문장의 앞 30자]
...
40. [대본 원문 첫 문장의 앞 30자]

===프롬프트===
[영어 프롬프트 1~40]
1. @영문ID, ... — ...
2. @영문ID, ... — ...
...
40. @영문ID, ... — ...
```

## STEP 1 캐릭터 블록 규칙
- 캐릭터마다 반드시 아래 3줄 구조만 사용한다.

```text
=== bobae (보배, peddler's daughter / 챕터 -) ===
=== bobae UPLOAD ===
Single figure portrait of a Korean Joseon-era peddler's daughter, faded indigo jeogori, hair in a low bun with binyeo, softly rounded eyes, oval face, thin arched brows, broad firm chin, straight narrow mouth, small rounded nose, small compact frame, medium shot from waist up, three-quarter left, neutral calm, plain flat neutral gray background, soft even neutral lighting, subject fully isolated, background is a plain backdrop only and not part of the character identity, no shadows on ground, no color tint, no props no other figures, [사용자가 선택한 STYLE_TAIL_FULL 원문 전체]
```

- 반드시 얼굴 묘사를 상세하게 넣는다.
- 예: eyes, face, brows, chin, mouth, nose, frame.
- 캐릭터별 UPLOAD 프롬프트에는 장면 설명을 넣지 않는다.

## [대본 1~40] 규칙
- 각 번호에는 해당 컷의 대본 원문 첫 문장의 앞 30자만 넣는다.
- 요약하거나 임의로 덧붙이지 않는다.
- 문장부호와 인용부호를 유지한다.

## [영어 프롬프트 1~40] 규칙
- 각 줄은 반드시 번호로 시작한다.
- 캐릭터 참조는 반드시 `@영문ID`를 사용한다.
- 기본 형태는 아래와 같다.

```text
1. @domanbok, faded indigo jeogori and baji, topknot with a plain headband, calm hooded eyes, oval face, solid upright frame, @bobae, faded indigo jeogori, long dark chima, hair in a low bun with binyeo, softly rounded eyes, oval face, small compact frame — Medium close-up of @domanbok and @bobae walking side by side along the lane, in crowded marketplace stalls, packed earth lane, cloth awnings, two figures, no duplicate or cloned figures, a cloth bundle carried on his back, worn sandals on the packed earth, cool daylight, reference defines face and garment identity only, pose and framing follow this description, no text no modern objects no modern buildings, natural colors, shadow areas still legible, mid-key exposure, neutral white balance, no color cast, [사용자가 선택한 STYLE_TAIL_FULL 원문 전체]
```

## 금지
- STEP 2 같은 추가 섹션 금지
- HOOK:, SAFE:, 설명문, 해설문, 요약문 추가 금지
- 캐릭터 ID 뒤에 `'s`, `’s`, 조사 붙이기 금지
- 예: `@bobae's hand` 금지 → `the hand of @bobae` 사용
- 등록되지 않은 캐릭터 ID 사용 금지

## 화풍/선택 규칙
- 대본 분석 후 화풍 추천/레퍼런스/직접 선택 절차는 유지한다.
- 그러나 최종 산출물 파일에는 선택 과정 설명을 쓰지 않는다.
- 최종 파일에는 오직 사용자가 준 형식의 산출물만 넣는다.


[V2.7.2-r2 본편 프롬프트 형식]
- [영어 프롬프트 1~N]의 각 줄은 `003 | 대본 원문 30자 | @[배경] @[인물] 실제프롬프트...` 형식을 사용합니다.
- `003 | ...`의 저장 문구는 해당 컷 대본 첫 문장의 앞 30자 그대로여야 하며 임의 요약 금지입니다.
- `@[...]` 에셋 호출은 해당 컷의 배경 set_id와 tags/subanchors와 일치해야 합니다.
- 실제 이미지 저장 파일명도 `대본원문30자.png` 기준으로 사용합니다.


[V2.7.5 이미지 저장 파일명 — 현재 프로젝트 적용 기준]
- 실제 이미지 파일명 앞에 컷 번호와 밑줄(숫자_)을 붙이지 않습니다.
- 본편은 `대본원문30자.png`, 에셋은 `영문ID.png` 또는 해당 에셋 이름으로 저장합니다.
- 예: `003_문 안에서 빗장이 밀리는 소리가 났지요.png` → `문 안에서 빗장이 밀리는 소리가 났지요.png`.
- Flow 프롬프트의 `003 | 원문30자 | @[에셋] 프롬프트` 번호와 대본 목록 번호는 순서 대응을 위해 유지합니다.
- 파일명 금지 문자는 공백으로 정리하며 이름이 겹치면 뒤에 `_중복2`, `_중복3`을 붙여 덮어쓰지 않습니다.
- image_filenames.py를 사용하고 image-filenames.json에 컷 번호와 저장 파일명 대응을 보존합니다.
- 이 규칙은 기본/절약형 모두 같으며 화풍·얼굴·캐릭터·컷 수·원문 보존 규칙은 유지합니다.
