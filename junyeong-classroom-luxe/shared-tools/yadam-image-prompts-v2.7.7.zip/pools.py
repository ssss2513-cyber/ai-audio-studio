"""Rebuilt v1.0: seeded character anchors; not the unavailable original."""
import random
import re

FACES = ['oval face, straight brows', 'long face, gently arched brows',
         'round face, narrow brows', 'broad face, level brows',
         'slender face, thick brows', 'square face, fine brows']
COLORS = ['muted blue', 'grey', 'muted green', 'brown', 'cream', 'navy']
VALENCES = {'선역', '위엄', '악역', '중립'}

def cast(specs, seed=None):
    """specs: [{id, age:int, role, valence, valence_quote, clothing, hair}].
    clothing/hair are script-compatible EN descriptions; never infer gender/status.
    Optional face locks a script-required face; otherwise unique faces are sampled.
    Returns [{id, text, valence, valence_quote, age, role}]."""
    if not isinstance(specs, list) or not 1 <= len(specs) <= 5:
        raise ValueError('specs must contain 1..5 principal characters')
    rng = random.Random(seed)
    faces = rng.sample(FACES, len(specs))
    colors = rng.sample(COLORS, len(specs))
    result, seen = [], set()
    for i, spec in enumerate(specs):
        key = spec.get('id', '')
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', key) or key in seen:
            raise ValueError('character id must be unique ASCII identifier')
        seen.add(key)
        if type(spec.get('age')) is not int or not 0 <= spec['age'] <= 120:
            raise ValueError('age must be supplied from script/character planning')
        for field in ('role', 'clothing', 'hair', 'valence_quote'):
            if not isinstance(spec.get(field), str) or not spec[field].strip():
                raise ValueError('required: ' + field)
        if spec.get('valence') not in VALENCES:
            raise ValueError('valence must be 선역/위엄/악역/중립')
        # Only explicitly optional color placeholders are randomized.
        clothing = spec['clothing'].replace('{COLOR}', colors[i])
        face = spec.get('face') or faces[i]
        text = f"a {spec['age']}-year-old {spec['role']}, {face}, {spec['hair']}, wearing {clothing}"
        record=dict(id=key,text=text,age=spec['age'],role=spec['role'],
                    valence=spec['valence'],valence_quote=spec['valence_quote'])
        for field in ('name','upload_text','upload_view','upload_expression'):
            if field in spec: record[field]=spec[field]
        result.append(record)
    return result
