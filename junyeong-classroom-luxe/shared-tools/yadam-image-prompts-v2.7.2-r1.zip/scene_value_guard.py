#!/usr/bin/env python3
"""Required production gate: narrative OR explanatory OR educational, plus comfort review.
Checks declared reviews, source quotes and visible prompt evidence; not a vision model.
No field is automatically approved. No YouTube or image-quality guarantee is made.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import re
from pathlib import Path

VERSION = '2.7.2-r1'
ROLES = ('narrative', 'explanatory', 'educational')
SCOPE = ('Declared semantic review, exact cut-source evidence, actual prompt evidence, '
         'review freshness and a limited risk-phrase screen. Rendered images not reviewed.')
# Deliberately narrow: this is a supplementary phrase screen, not exhaustive moderation.
RISK_PATTERNS = (
    r'\b(?:graphic gore|gory wounds?|exposed entrails|rotting corpse|severed limbs?|'
    r'blood[- ]soaked|mutilated bod(?:y|ies)|humiliation spectacle|torture close[- ]?up)\b',
    r'(?:내장이\s*드러|잘린\s*팔다리|썩은\s*시체|피투성이|고문\s*클로즈업|상처를\s*확대)',
)
NEGATION = re.compile(r'(?:\b(?:no|without|avoid|exclude|never depict|do not show)\s+[^.;]*$|금지[^.;]*$)', re.I)
PLACEHOLDER = re.compile(r'^(?:\s*|\.\.\.|…|TODO|TBD|N/?A|없음|미정|추후작성|\[.*\]|<.*>)$', re.I)

class ValueGateError(ValueError):
    def __init__(self, errors):
        self.errors = list(errors)
        super().__init__('\n'.join(self.errors))

def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save_json(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)

def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def gate_digest(gate):
    data = {k: v for k, v in gate.items() if k != 'review_binding'}
    return digest(json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')))

def meaningful(value):
    return isinstance(value, str) and not PLACEHOLDER.fullmatch(value.strip())

def pending_gate():
    return {'primary': '', 'flags': {k: False for k in ROLES},
            'source_evidence': '', 'reason': '', 'visualization': '', 'prompt_evidence': '',
            'discomfort_risk': 'unknown', 'discomfort_reason': '', 'mitigation': '',
            'review_status': 'PENDING'}

def risk_phrases(text):
    found = []
    for pattern in RISK_PATTERNS:
        for match in re.finditer(pattern, text, re.I):
            # A negative prompt can enumerate forbidden depictions without asking for them.
            before = re.split(r'[.;\n]', text[:match.start()])[-1]
            if not NEGATION.search(before):
                found.append(match.group())
    return found

def validate_gate(gate, source=None, prompt=None, evidence_text=None, n='?', require_binding=False):
    prefix = f'VALUE {n}: '
    if not isinstance(gate, dict):
        return [prefix + 'value_gate missing; analyze and review this scene first']
    errors = []
    flags = gate.get('flags')
    if not isinstance(flags, dict) or set(flags) != set(ROLES) or any(type(flags.get(k)) is not bool for k in ROLES):
        errors.append(prefix + 'flags must contain exactly three true/false boolean values')
        active = []
    else:
        active = [k for k in ROLES if flags[k]]
        if not active:
            errors.append(prefix + 'at least one narrative/explanatory/educational function is required')
    primary = gate.get('primary')
    if primary not in (*ROLES, 'mixed') or (primary == 'mixed' and len(active) < 2) or (primary in ROLES and primary not in active):
        errors.append(prefix + 'primary must agree with the active flags')
    for field in ('source_evidence', 'reason', 'visualization', 'prompt_evidence', 'discomfort_reason'):
        if not meaningful(gate.get(field)):
            errors.append(prefix + field + ' must contain a concrete, non-placeholder description')
    if gate.get('review_status') != 'APPROVED':
        errors.append(prefix + 'review_status must be APPROVED after source/prompt semantic review')
    risk = gate.get('discomfort_risk')
    if risk not in ('none', 'low'):
        errors.append(prefix + 'discomfort_risk must be none/low; unknown, medium and high are blocked')
    if risk == 'low' and not meaningful(gate.get('mitigation')):
        errors.append(prefix + 'low risk requires a concrete mitigation description')
    quote = gate.get('source_evidence', '')
    if source is not None and (not isinstance(source, str) or not source.strip() or not isinstance(quote, str) or quote not in source):
        errors.append(prefix + 'source_evidence must occur verbatim inside THIS cut, not another cut')
    evidence = gate.get('prompt_evidence', '')
    if meaningful(evidence):
        if len(evidence.strip()) < 8 or re.fullmatch(r'(?:narrative|explanatory|educational|서사|해설|교육적 가치)', evidence.strip(), re.I):
            errors.append(prefix + 'prompt_evidence must be a visible action/relation/detail, not a category label')
    if prompt is not None:
        visible = evidence_text if evidence_text is not None else prompt
        if not isinstance(prompt, str) or not prompt.strip():
            errors.append(prefix + 'actual prompt is empty')
        elif not isinstance(evidence, str) or evidence not in visible:
            errors.append(prefix + 'prompt_evidence is absent from the actual scene content')
        else:
            for word in risk_phrases(prompt):
                errors.append(prefix + 'risky depiction phrase: ' + word)
    if require_binding:
        binding = gate.get('review_binding')
        if not isinstance(binding, dict):
            errors.append(prefix + 'review binding missing; run --bind-values after completing the review')
        else:
            if binding.get('schema') != 1 or not meaningful(binding.get('reviewer')):
                errors.append(prefix + 'invalid review binding')
            if binding.get('gate_sha256') != gate_digest(gate):
                errors.append(prefix + 'review fields changed after binding; review again')
            for field, value in (('source_sha256', source), ('prompt_sha256', prompt)):
                checksum = binding.get(field)
                if not isinstance(checksum, str) or not re.fullmatch('[0-9a-f]{64}', checksum):
                    errors.append(prefix + 'invalid ' + field)
                elif value is not None and checksum != digest(value):
                    errors.append(prefix + field + ' changed after review; review and bind again')
    return errors

def bind_gate(gate, source, prompt, reviewer, evidence_text=None, n='?'):
    """Snapshot a supplied APPROVED declaration. This does not perform semantic approval."""
    errors = validate_gate(gate, source, prompt, evidence_text, n, require_binding=False)
    if not meaningful(reviewer):
        errors.append('VALUE: explicit reviewer required')
    if errors:
        raise ValueGateError(errors)
    result = copy.deepcopy(gate)
    result['review_binding'] = {'schema': 1, 'reviewer': reviewer,
        'gate_sha256': gate_digest(result), 'source_sha256': digest(source), 'prompt_sha256': digest(prompt)}
    return result

def source_for_cut(body, chapter):
    a, b = chapter.get('start_idx'), chapter.get('end_idx')
    if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(body):
        raise ValueError('VALUE: invalid source range')
    return '\n'.join(body[a:b])

def project_errors(state, body, rows=None, lines=None, require_binding=False):
    chapters = state.get('chapters', [])
    if not isinstance(chapters, list) or not chapters:
        return ['VALUE: no chapters; empty projects never pass']
    if not isinstance(body, list) or not body or any(not isinstance(s, str) or not s.strip() for s in body):
        return ['VALUE: valid full source body required']
    if rows is not None:
        expected = list(range(1, len(rows) + 1))
        if not rows or len(rows) > len(chapters) or [r.get('n') for r in rows] != expected:
            return ['VALUE: row ids must be contiguous 1..N']
    if lines is not None and (len(lines) != len(chapters)):
        return ['VALUE: final prompt count and chapter count differ']
    errors = []; limit = len(rows) if rows is not None else len(chapters)
    for i, chapter in enumerate(chapters[:limit], 1):
        try:
            source = source_for_cut(body, chapter)
            if lines is not None:
                prompt = lines[i-1]
            elif rows is not None:
                import assemble
                prompt = assemble.render_text(state, rows[i-1])
            else:
                prompt = None
            # Do not accept evidence occurring only in the style tail or character prefix.
            visible = None
            if prompt is not None:
                style = state.get('STYLE_TAIL', '')
                visible = prompt[:-len(style)] if style and prompt.endswith(style) else prompt
                visible = visible.split(' — ', 1)[-1]
                visible = visible.split(', reference defines face', 1)[0]
            errors += validate_gate(chapter.get('value_gate'), source, prompt, visible, i, require_binding)
        except (ValueError, KeyError, TypeError, IndexError) as exc:
            errors.append(f'VALUE {i}: {exc}')
    return errors

def analysis_sources(analysis):
    """Verify whole-source hash and ordered cut ranges before accepting AI-written evidence."""
    import script_integrity
    scenes = analysis.get('scenes')
    if not isinstance(scenes, list) or not scenes:
        raise ValueGateError(['VALUE: analysis.scenes must be a nonempty list'])
    path = analysis.get('source_file')
    if not isinstance(path, str) or not path:
        raise ValueGateError(['VALUE: analysis.source_file required; bind the real source TXT first'])
    raw = Path(path).read_bytes()
    if script_integrity.digest(raw) != analysis.get('source_sha256'):
        raise ValueGateError(['VALUE: analysis source hash mismatch'])
    body = script_integrity.source_body(raw)[0]
    sources = []; end = 0
    for i, scene in enumerate(scenes, 1):
        if not isinstance(scene, dict) or type(scene.get('n')) is not int or scene['n'] != i or scene.get('start_idx') != end:
            raise ValueGateError([f'VALUE {i}: source ranges and numbering must be ordered and contiguous'])
        sources.append(source_for_cut(body, scene)); end = scene['end_idx']
        if scene.get('start_sentence') != body[scene['start_idx']]:
            raise ValueGateError([f'VALUE {i}: start_sentence differs from original source'])
    if end != len(body):
        raise ValueGateError(['VALUE: scene ranges must cover the complete source'])
    return sources

def report(errors, scene_count, stage='prompt'):
    return {'version': VERSION, 'status': 'FAIL' if errors else 'PASS',
            'stage': stage, 'scene_count': scene_count, 'errors': list(errors),
            'scope': SCOPE, 'image_review_status': 'NOT_REVIEWED', 'platform_approval': 'NOT_ASSESSED'}

def bind_project(root, reviewer):
    """Bind supplied chapter reviews to existing source and final prompt bytes."""
    import assemble
    import gates
    import script_integrity
    root = Path(root)
    state, body = load_json(root/'state.json'), load_json(root/'body.json')
    errors = script_integrity.source_errors(root, body) + gates.verify_selected_style_source(root, state)
    if errors: raise ValueGateError(errors)
    rows = gates.read_rows(root, len(state['chapters']))
    errors = project_errors(state, body, rows=rows)
    if errors: raise ValueGateError(errors)
    candidate = copy.deepcopy(state)
    for row, chapter in zip(rows, candidate['chapters']):
        full = assemble.render_text(candidate, row)
        chapter['value_gate'] = bind_gate(chapter['value_gate'], source_for_cut(body, chapter), full, reviewer, n=row['n'])
    save_json(root/'state.json', candidate)
    return candidate

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path)
    ap.add_argument('--analysis', type=Path)
    ap.add_argument('--flow', type=Path)
    ap.add_argument('--report', type=Path, default=Path('scene-value-report.json'))
    args = ap.parse_args(); count = 0
    try:
        if args.root:
            state, body = load_json(args.root/'state.json'), load_json(args.root/'body.json')
            import gates, script_integrity
            errors = script_integrity.source_errors(args.root, body) + gates.verify_selected_style_source(args.root, state)
            if args.flow:
                text = args.flow.read_text(encoding='utf-8-sig')
                tail = text.split('[영어 프롬프트 1~', 1)[-1]
                pairs = re.findall(r'^(\d+)\. (.+)$', tail, re.M)
                count = len(state['chapters'])
                if [int(n) for n, _ in pairs] != list(range(1, count + 1)):
                    errors.append('VALUE: final Flow numbering mismatch')
                errors += project_errors(state, body, lines=[s for _, s in pairs], require_binding=True)
            else:
                rows = gates.read_rows(args.root, len(state['chapters'])); count = len(rows)
                errors += project_errors(state, body, rows=rows, require_binding=True)
        elif args.analysis:
            a = load_json(args.analysis); sources = analysis_sources(a); count = len(sources)
            errors = []
            for scene, source in zip(a['scenes'], sources):
                errors += validate_gate(scene.get('value_gate'), source, n=scene['n'])
        else:
            raise ValueError('--root or --analysis is required')
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        errors = exc.errors if isinstance(exc, ValueGateError) else [str(exc)]
    stage = 'analysis_only' if args.analysis and not args.root else 'prompt'
    result = report(errors, count, stage); save_json(args.report, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if errors else 0

if __name__ == '__main__':
    raise SystemExit(main())
