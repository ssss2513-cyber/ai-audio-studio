"""Regression tests for full original-script starts. All scripts are synthetic."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import gates
import script_integrity as script
import style_integrity
import recommend
from test_value_support import annotate_project, reviewed_analysis, reviewed_build_final
from test_style_integrity import fixture, cli, STYLES, TYPES, SELECTION, analyzer

HERE=Path(__file__).parent
VERBS=['standing','walking','watching','waiting','listening','holding','examining',
       'carrying','folding','counting','lifting','lowering','pointing','resting',
       'reading','writing','sorting','sewing','tying','tracing','kneeling',
       'reaching','leaning','bracing','settling','touching','wiping','tightening',
       'loosening','placing','stacking','checking','measuring','arranging']


def hundred_fixture(root, mode='basic'):
    root=Path(root)
    state,_,oldrows=fixture(root,mode)
    body=[]
    for i in range(1,101):
        if i==1:
            s='"검사용 대사는... 말줄임표 뒤에도 이어지며 문장이 끝나는 지점까지 그대로 기록되어야 합니다."'
        elif i==2:
            s='"다른 검사용 대사도… 원문에 있는 말줄임표와 닫는 인용부호를 그대로 보존합니다."'
        elif i==3:
            s='검사용 긴 문장에는 '+('반드시 보존할 원문 정보와 인물의 설명이 이어지고, '*70)+'마지막 확인 문구까지 빠짐없이 들어 있습니다.'
        elif i==4:
            s='"그럼 지금부터…"'
        else:
            s=f'검사용 장면 {i}에서 보배와 한도원은 마당에 놓인 문서를 확인하며, 이 문장이 중간에서 잘리지 않고 끝까지 남아 있는지 살펴보았습니다.'
        body.append(s)
    state['TITLE']='대본 원문 보존 100컷 기능검사'
    # The selected style title is bound again; style contents are unchanged.
    state['expected_count']=100
    state['n_action']=25
    state['chapters']=[]; state['shots']=[]; rows=[]
    for x in state['ingredients']: x['valence_quote']=body[0]
    for i in range(100):
        motion='A' if i<25 else 'S' if i<45 else 'N'
        state['chapters'].append({'start_idx':i,'end_idx':i+1,'motion':motion,
          'intensity':('L','M','H')[i%3],'time':'day','set_id':'yard','person_count':2,'minor_present':False})
        state['shots'].append({'shot':'medium_shot'})
        verb=VERBS[i%len(VERBS)]
        text=f'Medium shot of @bobae {verb} beside @hando, in {{SET}}, two figures, no duplicate or cloned figures'
        if motion in ('A','S'): text+=', both feet planted on the ground'
        if motion=='A': text+=', elbows driven forward'
        if motion=='S': text+=', eyes fixed on the gate, mouth pressed into a calm line'
        text+=', a low wall behind them, a wooden post near the gate'
        low,high=gates.BUDGET[motion]
        while len(gates.words(text))<low: text+=', the plain courtyard wall nearby'
        assert len(gates.words(text))<=high
        rows.append({'n':i+1,'tags':['bobae','hando'],'subanchors':[],'main_verb':verb,'body':text})
    gates.save_json(root/'state.json',state); gates.save_json(root/'body.json',body)
    source=root/'fixture_source.txt'; source.write_text('\n\n'.join(body),encoding='utf-8-sig')
    script.bind_source(root,source)
    for start in range(0,100,8):
        gates.save_json(root/'bodies'/f'chunk{start//8+1}.json',rows[start:start+8])
    gates.bind_selected_style(root,state)
    annotate_project(state,body,rows)
    gates.save_json(root/'state.json',state)
    return state,body,rows


class SourceUnitTests(unittest.TestCase):
    def test_internal_ascii_ellipsis_not_split(self):
        s='"이것은... 생략하지 않은 시험 문장입니다."'
        self.assertEqual(script.sentences_from_text(s),[s])
    def test_authentic_unicode_ellipsis_not_removed(self):
        s='"그럼 지금부터…"'
        self.assertEqual(script.sentences_from_text(s),[s])
    def test_closing_quote_preserved_with_sentence_split(self):
        self.assertEqual(script.sentences_from_text('"시험입니다." 다음 문장입니다.'),['"시험입니다."','다음 문장입니다.'])
    def test_decimal_not_split(self):
        self.assertEqual(script.sentences_from_text('수치는 3.14 입니다.'),['수치는 3.14 입니다.'])
    def test_long_single_sentence_has_no_character_cap(self):
        s='"'+('원문 내용, '*500)+'마지막입니다."'
        self.assertEqual(script.sentences_from_text(s),[s])
    def test_explicit_title_is_not_manuscript_sentence(self):
        text='제목: 시험\n\n첫 문장입니다.\n두 번째입니다.'
        body,_=script.source_body(text.encode())
        self.assertEqual(body,['첫 문장입니다.','두 번째입니다.'])
    def test_crlf_and_utf8_bom_raw_snapshot_unchanged(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); p=root/'input.txt'; raw='첫 문장입니다.\r\n둘째 문장입니다.'.encode('utf-8-sig'); p.write_bytes(raw)
            body,_=script.bind_source(root,p)
            self.assertEqual((root/script.SNAPSHOT).read_bytes(),raw)
            self.assertEqual(body,['첫 문장입니다.','둘째 문장입니다.'])
    def test_existing_short_body_not_silently_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); p=root/'input.txt'; p.write_text('긴 원문 문장을 온전히 보존해야 합니다.',encoding='utf-8')
            gates.save_json(root/'body.json',['긴 원문…'])
            with self.assertRaises(ValueError): script.bind_source(root,p)
            self.assertEqual(gates.read_json(root/'body.json'),['긴 원문…'])
    def test_flow_output_cannot_be_used_as_original(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); p=root/'output.txt'; p.write_text('[대본 1~100]\n1. 잘린 문장…',encoding='utf-8')
            with self.assertRaises(ValueError): script.bind_source(root,p)
    def test_cp949_source_supported_without_replacement(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); p=root/'input.txt'; p.write_bytes('한글 대본을 그대로 보존합니다.'.encode('cp949'))
            body,_=script.bind_source(root,p)
            self.assertEqual(body,['한글 대본을 그대로 보존합니다.'])
    def test_empty_input_rejected(self):
        with self.assertRaises(ValueError): script.source_body(b' \n')


class FullHundredStartTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.state,self.body,self.rows=hundred_fixture(self.root)
    def build(self):
        result=cli(self.root,'--final')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        path=self.root/'output'/gates.flow_output_name(self.state['TITLE'])
        return path,path.read_text(encoding='utf-8-sig')
    def test_100_prefix30_starts_in_final_file(self):
        path,text=self.build()
        errors,counts=script.validate_flow(self.root,self.state,self.body,text)
        self.assertEqual(errors,[]); self.assertEqual(counts['start_count'],100)
        for i,s in enumerate(self.body,1): self.assertIn(f'\n{i}. {s[:30]}\n',text)
    def test_long_source_kept_but_display_prefix30(self):
        _,text=self.build()
        self.assertGreater(len(self.body[2]),1000)
        self.assertIn('3. '+self.body[2][:30],text)
    def test_original_ellipsis_survives(self):
        _,text=self.build()
        for i in (0,1,3): self.assertIn(f'{i+1}. '+self.body[i][:30],text)
    def test_shortening_output_unicode_fails(self):
        _,text=self.build()
        text=text.replace('3. '+self.body[2][:30],'3. '+self.body[2][:25]+'…',1)
        self.assertTrue(any('SCRIPT_START 3:' in e for e in script.validate_flow(self.root,self.state,self.body,text)[0]))
    def test_shortening_output_ascii_fails(self):
        _,text=self.build()
        text=text.replace('1. '+self.body[0][:30],'1. "검사용 대사는...',1)
        self.assertTrue(any('SCRIPT_START 1:' in e for e in script.validate_flow(self.root,self.state,self.body,text)[0]))
    def test_punctuation_change_fails(self):
        _,text=self.build()
        text=text.replace('4. '+self.body[3],'4. 그럼 지금부터…',1)
        self.assertTrue(script.validate_flow(self.root,self.state,self.body,text)[0])
    def test_missing_row_fails(self):
        _,text=self.build(); text=text.replace('50. '+self.body[49][:30]+'\n','',1)
        self.assertTrue(script.validate_flow(self.root,self.state,self.body,text)[0])
    def test_duplicate_row_fails(self):
        _,text=self.build(); old='50. '+self.body[49][:30]+'\n'; text=text.replace(old,old+old,1)
        self.assertTrue(script.validate_flow(self.root,self.state,self.body,text)[0])
    def test_wrong_declared_count_fails(self):
        _,text=self.build(); text=text.replace('[대본 1~100]','[대본 1~40]')
        self.assertTrue(script.validate_flow(self.root,self.state,self.body,text)[0])
    def test_shortened_body_blocked_before_new_final(self):
        changed=list(self.body); changed[4]=changed[4][:30]+'…'; gates.save_json(self.root/'body.json',changed)
        result=cli(self.root,'--final')
        self.assertNotEqual(result.returncode,0)
        self.assertFalse((self.root/'output').exists())
        self.assertIn('SCRIPT_SOURCE',result.stdout)
    def test_changed_source_snapshot_fails(self):
        path=self.root/script.SNAPSHOT; path.write_bytes(path.read_bytes()+b'changed')
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
    def test_missing_original_manifest_blocks_final(self):
        (self.root/script.MANIFEST).unlink()
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
    def test_stale_success_not_overwritten_on_failure(self):
        p,_=self.build(); before=p.read_bytes()
        gates.save_json(self.root/'body.json',[self.body[0][:5]+'…']+self.body[1:])
        self.assertNotEqual(cli(self.root,'--final').returncode,0)
        self.assertEqual(p.read_bytes(),before)
        self.assertEqual(gates.read_json(self.root/'validation-last-run.json')['status'],'FAIL')
    def test_standalone_script_preflight_cli(self):
        p,_=self.build()
        run=subprocess.run([sys.executable,str(HERE/'script_integrity.py'),'--root',str(self.root),'--flow',str(p)],text=True,capture_output=True,encoding='utf-8',timeout=20)
        self.assertEqual(run.returncode,0,run.stdout+run.stderr)
        self.assertEqual(json.loads(run.stdout)['counts']['start_count'],100)
    def test_separate_start_list_also_prefix30(self):
        self.build(); text=(self.root/'output'/'script-starts.txt').read_text(encoding='utf-8-sig')
        self.assertEqual(script.flow_errors(text,self.body),[])
    def test_wrong_indices_blocked(self):
        self.state['chapters'][2]['start_idx']=4
        with self.assertRaises(ValueError): script.expected_starts(self.root,self.state,self.body)
    def test_basic_economy_full_output_identical(self):
        _,text=self.build()
        self.state['processing_mode']='economy'; gates.save_json(self.root/'state.json',self.state)
        _,economy=self.build()
        self.assertEqual(text,economy)
    def test_all_102_style_copies_retained(self):
        _,text=self.build()
        self.assertEqual(text.count(self.state['STYLE_TAIL']),102)
        self.assertEqual(style_integrity.validate_flow(text,self.state['style_lock'],100)[0],[])
    def test_summary_is_not_used_as_start(self):
        for c in self.state['chapters']:
            c['summary']='줄인 분석 요약…'; c['script_quote']='다른 근거 구절…'
        gates.save_json(self.root/'state.json',self.state)
        _,text=self.build()
        self.assertEqual(script.validate_flow(self.root,self.state,self.body,text)[0],[])
    def test_analyzer_100_first_sentences_exact(self):
        a=analyzer.auto_analyze_script(self.root/'fixture_source.txt',100)
        self.assertEqual([s['start_sentence'] for s in a['scenes']],self.body)
        self.assertEqual([s['start_idx'] for s in a['scenes']],list(range(100)))
    def test_economy_cache_keeps_complete_start_sentences(self):
        a=analyzer.auto_analyze_script(self.root/'fixture_source.txt',100)
        r=reviewed_build_final(a,STYLES,TYPES,SELECTION,'economy')
        cache=analyzer.build_work_cache(a,r,SELECTION)
        self.assertEqual([s['start_sentence'] for s in cache['scenes']],self.body)
        self.assertEqual([s['start_sentence'] for s in r['scenes']],self.body)


if __name__=='__main__': unittest.main(verbosity=2)
