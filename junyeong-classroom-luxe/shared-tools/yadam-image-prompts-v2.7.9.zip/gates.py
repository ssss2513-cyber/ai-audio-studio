"""Rebuilt v1.0. Standard library only. Explicit lexical checks, not policy approval.
All paths are relative to cwd or --root. Never modifies the supplied script.
"""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import re
import sys
import assemble
import style_integrity
import script_integrity
import scene_value_guard
import workflow_guard

VERSION = '2.7.9'
BANNED = ['mid-stride','caught mid-','off balance','staggering','weight thrown',
          'wheeling','pivoting','turning to face','angry','determined',
          'expression of','golden','dimly lit','at night','pale skin']
SUPPORT = ['back foot planted','both feet planted','palm pressed flat',
           'weight settled onto','forearm braced against','knees pressed to']
MOVE = ['torso twisted','elbows driven','arms swung','spine angled',
        'chest turned','hips squared']
EXPRESS = ['mouth pressed','eyes fixed','eyes lowered','jaw set','brow drawn',
           'lips parted','chin level']
BUDGET = {'A':(60,80),'S':(45,65),'N':(30,50)}
DARK_TIMES = {'dusk','night_in','night_out'}

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)

def load_script(path='script.txt'):
    """Read full original source units without truncation or ellipsis insertion."""
    return script_integrity.source_body(Path(path).read_bytes())[0]


def split_chapters(body, count=100, want=None):
    """start_idx inclusive, end_idx exclusive. want = count-1 exact boundary indices.
    Without want, evenly divides sentence counts (NOT semantic optimization)."""
    if not isinstance(body, list) or type(count) is not int or count < 1 or len(body) < count:
        raise ValueError('at least one sentence per chapter is required')
    cuts = list(want) if want is not None else [i*len(body)//count for i in range(1,count)]
    if len(cuts) != count-1 or any(type(x) is not int for x in cuts):
        raise ValueError('want must contain count-1 integer boundaries')
    if cuts != sorted(set(cuts)) or any(x <= 0 or x >= len(body) for x in cuts):
        raise ValueError('boundaries must be unique, ascending, internal indices')
    bounds = [0] + cuts + [len(body)]
    return [dict(start_idx=a,end_idx=b) for a,b in zip(bounds,bounds[1:])]

def words(text):
    # Count English lexical tokens, hyphenated words as one, @id as one.
    # Exclude {SET}; only the authored body is counted for M4.
    return re.findall(r"@?[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*", text.replace('{SET}', ''))

def banned(text):
    return [p for p in BANNED if re.search(r'(?<!\w)' + re.escape(p) + r'(?!\w)', text, re.I)]

def style_banned(text):
    # Two exact negative instructions in the unchanged bundled style bank.
    # Detection only: never delete or rewrite text in the actual STYLE_TAIL.
    probe=text
    for negative in ('without looking angry by default','avoid generic angry face'):
        probe=probe.replace(negative,'')
    return banned(probe)

def has_direct_time_evidence(chapter, body):
    """True only when an exact nonempty quote occurs inside this cut's script range.
    The code verifies location, not whether the quote semantically proves darkness.
    """
    a, b = chapter.get('start_idx'), chapter.get('end_idx')
    quote = chapter.get('time_evidence')
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(body)
            or not isinstance(quote, str) or not quote.strip()):
        return False
    return quote in '\n'.join(body[a:b])

def has_valid_dark_continuity(chapter_no, chapters, body):
    """Allow a dark cut to cite an earlier directly evidenced cut only when the
    entire interval remains dark. chapter_no and time_continuity_from are 1-based.
    """
    chapter = chapters[chapter_no-1]
    source_no = chapter.get('time_continuity_from')
    if type(source_no) is not int or not 1 <= source_no < chapter_no:
        return False
    source = chapters[source_no-1]
    return (source.get('time') in DARK_TIMES
            and has_direct_time_evidence(source, body)
            and all(c.get('time') in DARK_TIMES
                    for c in chapters[source_no-1:chapter_no]))

def plan_errors(s, body):
    e = []
    try: style_integrity.state_style(s)
    except ValueError as exc: e.append(str(exc))
    cs = s.get('chapters', [])
    n = s.get('expected_count', 100)
    if type(n) is not int or n < 1 or len(cs) != n:
        e.append('PLAN: chapter count must match expected_count (default 100)')
    if not isinstance(body, list) or not body or any(not isinstance(x,str) or not x.strip() for x in body):
        return e + ['PLAN: body.json must be a nonempty list of sentence strings']
    if not cs:
        return e + ['PLAN: chapters missing']
    if not s.get('TITLE') or not isinstance(s.get('STYLE_TAIL'),str) or not s['STYLE_TAIL'].strip():
        e.append('PLAN: TITLE and STYLE_TAIL required')
    if style_banned(s.get('STYLE_TAIL','')):
        e.append('STYLE: prohibited phrase in STYLE_TAIL')
    sets = s.get('sets', [])
    setids = [x['id'] for x in sets]
    if len(setids) != len(set(setids)) or any(not x.get('anchor','').strip() for x in sets):
        e.append('PLAN: duplicate set ids or empty anchor')
    shots = s.get('shots', [])
    if len(shots) != len(cs):
        e.append('PLAN: shots count mismatch')
    previous = 0
    for i,c in enumerate(cs,1):
        a,b = c.get('start_idx'),c.get('end_idx')
        if type(a) is not int or type(b) is not int or a != previous or not 0 <= a < b <= len(body):
            e.append(f'PLAN {i}: ranges must be contiguous [start,end) with full coverage')
        previous = b
        if c.get('motion') not in BUDGET or c.get('intensity') not in ('H','M','L'):
            e.append(f'PLAN {i}: invalid motion/intensity')
        if c.get('time') not in assemble.LIGHTS:
            e.append(f'PLAN {i}: invalid time')
        elif c.get('time') in DARK_TIMES:
            if not (has_direct_time_evidence(c, body)
                    or has_valid_dark_continuity(i, cs, body)):
                e.append(f'PLAN {i}: dark time requires exact time_evidence from this cut '
                         'or time_continuity_from pointing to an earlier directly evidenced '
                         'dark cut across an uninterrupted dark sequence')
        if c.get('set_id') not in setids + ['oneoff']:
            e.append(f'PLAN {i}: unknown set')
        if type(c.get('person_count')) is not int or c['person_count'] < 0:
            e.append(f'PLAN {i}: explicit person_count required')
        if type(c.get('minor_present')) is not bool:
            e.append(f'PLAN {i}: minor_present boolean required')
        if c.get('light_variant',0) not in (0,1):
            e.append(f'PLAN {i}: light_variant must be 0 or 1')
        if i <= len(shots):
            shot = shots[i-1]['shot']
            if shot not in assemble.SHOTS:
                e.append(f'PLAN {i}: unknown shot')
            if c.get('motion') == 'S' and shot not in assemble.CLOSE:
                e.append(f'M11 {i}: S requires a CLOSE-set shot')
            if shot == 'two_shot' and c.get('person_count') != 2:
                e.append(f'M15 {i}: two_shot requires exactly 2 planned people')
    if previous != len(body):
        e.append('PLAN: last end_idx must equal sentence count')
    if s.get('ACTION_EXEMPT'):
        if not str(s.get('ACTION_EXEMPT_REASON','')).strip():
            e.append('PLAN: ACTION_EXEMPT_REASON required')
    else:
        target = s.get('n_action', 10 if len(cs)==40 else round(len(cs)/4))
        if sum(c.get('motion')=='A' for c in cs) != target:
            e.append(f'PLAN: expected {target} action chapters')
    sn = sum(c.get('motion')=='S' for c in cs)
    if not math.ceil(len(cs)*.15) <= sn <= math.floor(len(cs)*.25):
        e.append('PLAN: S chapters must be 15..25 percent (6..10 of 40)')
    intensities = [c.get('intensity') for c in cs]
    for i in range(len(cs)-4):
        if len(set(intensities[i:i+5])) == 1:
            e.append(f'PLAN: 5 equal intensities at {i+1}')
    exemptions = s.get('SEQ_EXEMPT', [])
    reasons = s.get('SEQ_EXEMPT_REASONS', {})
    for block in exemptions:
        if type(block) is not int or not 1 <= block <= math.ceil(len(cs)/8) or not reasons.get(str(block)):
            e.append('PLAN: SEQ_EXEMPT block number and reason required')
    for start in range(0,len(cs),8):
        group = intensities[start:start+8]
        if len(group)==8 and start//8+1 not in exemptions and not {'L','M','H'} <= set(group):
            e.append(f'PLAN: block {start//8+1} needs L/M/H or documented exemption')
    times = Counter(c.get('time') for c in cs)
    if s.get('TIME_EXEMPT_REASON'):
        pass  # Explicit, documented exception preserves script time of day.
    else:
        ratios = [(times['dusk']+times['night_in'], .30),
                  (times['dusk']+times['night_in']+times['night_out'], .40),
                  (times['dusk'], .15)]
        if any(value/len(cs) > limit for value,limit in ratios):
            e.append('PLAN: dark-time ratio exceeded; preserve script, document TIME_EXEMPT_REASON if needed')
        if sum(times[t] for t in ('day','day_in','dawn'))/len(cs) < .45:
            e.append('PLAN: bright-time ratio below 45 percent')
    return e

def cast_errors(s, body):
    e, seen = [], set()
    principals, subs = s.get('ingredients', []), s.get('subanchors', [])
    if len(principals)>5 or sum(bool(x.get('named')) for x in subs)>3:
        e.append('CAST: max 5 anchors, max 3 named subanchors')
    script = '\n'.join(body)
    for x in principals+subs:
        key = x.get('id','')
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',key) or key in seen:
            e.append('CAST: invalid/duplicate id ' + str(key))
        seen.add(key)
        if not isinstance(x.get('text'),str) or not x['text'].strip():
            e.append(f'CAST {key}: missing text')
        elif re.search(r'[@{}\r\n]', x['text']):
            e.append(f'CAST {key}: anchor must be resolved single-line text')
        if type(x.get('age')) is not int or not 0 <= x.get('age',-1) <= 120:
            e.append(f'CAST {key}: age required')
        if x in principals:
            if x.get('valence') not in ('선역','위엄','악역','중립'):
                e.append(f'CAST {key}: invalid valence')
            if not x.get('valence_quote') or x['valence_quote'] not in script:
                e.append(f'CAST {key}: valence_quote must occur verbatim in body.json')
    return e

def read_rows(root, count, through=None):
    limit = through if through is not None else math.ceil(count/8)
    if not 1 <= limit <= math.ceil(count/8):
        raise ValueError('invalid chunk number')
    rows = []
    for chunk in range(1,limit+1):
        part = read_json(root/'bodies'/f'chunk{chunk}.json')
        wanted = list(range((chunk-1)*8+1,min(chunk*8,count)+1))
        if not isinstance(part,list) or [x.get('n') for x in part] != wanted:
            raise ValueError(f'chunk{chunk}: expected exact ordered n values {wanted}')
        rows.extend(part)
    return rows

def row_errors(s, rows):
    e, verbs, lines = [], Counter(), []
    main = {x['id']:x for x in s.get('ingredients',[])}
    subs = {x['id']:x for x in s.get('subanchors',[])}
    for row in rows:
        n, text = row['n'], row.get('body','')
        c = s['chapters'][n-1]
        shot = s['shots'][n-1]['shot']
        prefix = assemble.SHOTS[shot]
        if not isinstance(text,str) or not text.strip() or '\n' in text or '\r' in text:
            e.append(f'ROW {n}: body must be nonempty single-line string'); continue
        low = text.lower()
        tags, extras = row.get('tags',[]), row.get('subanchors',[])
        ids = tags+extras
        if len(set(ids)) != len(ids) or any(x not in main for x in tags) or any(x not in subs for x in extras):
            e.append(f'CAST {n}: duplicate or unknown row ids'); continue
        possessive_refs = re.findall(r"@[A-Za-z][A-Za-z0-9_]*['’]s\b", text)
        if possessive_refs:
            e.append(f"FLOWREF {n}: do not attach possessive 's directly to @ID: {', '.join(possessive_refs)}; rewrite as 'the hand of @id' or equivalent")
        refs = set(re.findall(r'@([A-Za-z][A-Za-z0-9_]*)',text))
        if refs != set(ids):
            e.append(f'CAST {n}: @references must exactly match listed anchors'); continue
        if len(ids) != c['person_count']:
            e.append(f'M18 {n}: planned people must equal referenced anchors')
        if c['minor_present'] != any((main|subs)[x]['age']<18 for x in ids):
            e.append(f'CAST {n}: minor_present disagrees with referenced ages')
        for key in extras:
            allowed = subs[key].get('chapters')
            if allowed:
                valid = [int(x) for x in allowed.split(',')] if isinstance(allowed,str) else allowed
                if n not in valid:
                    e.append(f'CAST {n}: subanchor {key} not allowed in chapter')
        if c['set_id']=='oneoff':
            if '{SET}' in text or not row.get('setting_evidence') or row['setting_evidence'] not in text:
                e.append(f'SET {n}: oneoff needs setting_evidence present in body, no SET placeholder')
        elif text.count('{SET}') != 1:
            e.append(f'SET {n}: exactly one SET placeholder required')
        count = len(words(text)); lo,hi = BUDGET[c['motion']]
        if not lo <= count <= hi:
            e.append(f'M4 {n}: {count} body words (required {lo}..{hi})')
        if not low.startswith(prefix.lower()):
            e.append(f'M15 {n}: body must start with {prefix}')
        for phrase in banned(text):
            e.append(f'M11 {n}: prohibited phrase: {phrase}')
        if c['motion'] in ('A','S') and not any(x in low for x in SUPPORT):
            e.append(f'M11 {n}: support-axis phrase missing')
        if c['motion']=='A' and not any(x in low for x in MOVE):
            e.append(f'M11 {n}: movement-axis phrase missing')
        if c['motion']=='S' and sum(x in low for x in EXPRESS)<2:
            e.append(f'M11 {n}: at least two expression phrases required')
        verb = row.get('main_verb','')
        if not re.fullmatch('[a-z]+ing',verb) or not re.search(r'\b'+re.escape(verb)+r'\b',low):
            e.append(f'M16 {n}: main_verb must be one present ing verb in body')
        else:
            verbs[verb] += 1
        signals = {0:'no people',1:'one figure only',2:'two figures',3:'three figures',4:'four figures',5:'five figures'}
        required = signals.get(len(ids),f'{len(ids)} figures')
        if required not in low:
            e.append(f'M18 {n}: missing person signal: {required}')
        if len(ids)!=1 and any(x in low for x in ('one figure only','a single figure','solo')):
            e.append(f'M18 {n}: contradictory solo signal')
        for amount,signal in signals.items():
            if signal in low and amount != len(ids):
                e.append(f'M18 {n}: conflicting person signal {signal}')
        if re.search(r'\b(dust|smoke|straw)\b',low) and not any(x in low for x in ('thin','a few','a skid of','two or three')):
            e.append(f'M11 {n}: effect scale limiter missing')
        try:
            line = assemble.render(s,row)
            if re.search(r'[{}\r\n]',line):
                e.append(f'FINAL {n}: unresolved placeholder or newline')
            full_style=style_integrity.state_style(s)
            core=line[:-len(full_style)] if line.endswith(full_style) else line
            if len(words(core))>170:
                e.append(f'M4 {n}: non-style portion {len(words(core))} words >170; '
                         'shorten scene text, NEVER the full selected style')
            e.extend(style_integrity.prompt_errors(line,s['style_lock'],f'SCENE {n}'))
            if banned(core) or style_banned(full_style):
                e.append(f'FINAL {n}: prohibited phrase in assembled anchors/style/set')
            lines.append(line)
        except (KeyError,ValueError) as exc:
            e.append(f'ASSEMBLE {n}: {exc}')
    for verb,count in sorted(verbs.items()):
        if count>3:
            e.append(f'M16: {verb} occurs {count} times (max 3)')
    return e,verbs,lines

def character_errors(s, body):
    errors = cast_errors(s, body)
    try: style_integrity.state_style(s)
    except ValueError as exc: errors.append(str(exc))
    style = s.get('STYLE_TAIL', '')
    if not isinstance(style, str) or not style.strip() or re.search(r'[@{}\r\n]', style) or style_banned(style):
        errors.append('CHARACTERS: valid resolved STYLE_TAIL required')
    if not s.get('ingredients') and not s.get('subanchors'):
        errors.append('CHARACTERS: no character anchors supplied')
    for anchor in s.get('ingredients', []) + s.get('subanchors', []):
        if isinstance(anchor.get('text'), str) and banned(anchor['text']):
            errors.append(f"CHARACTERS {anchor['id']}: prohibited phrase in anchor")
    return errors

def write_characters(root, s):
    records=assemble.character_prompts(s)
    out=root/'output'; out.mkdir(exist_ok=True)
    save_json(out/'characters.json',records)
    parts=['STEP 1','']
    for record in records:
        parts.extend([f"=== {record['id']} ({record['name']}, {record['role']} / 챕터 -) ===",
                      f"=== {record['id']} UPLOAD ===",record['upload'],''])
    (out/'character-prompts.txt').write_text('\n'.join(parts),encoding='utf-8-sig')
    save_json(out/'character-validation.json',dict(version=VERSION,status='PASS',
        characters=len(records),prompts=len(records),style_sha256=s['style_lock']['sha256'],
        scope='One UPLOAD portrait; full-style text checks only; no image verification'))


def script_mapping(state, body):
    """Exact source text, never summarize/rewrite or search ambiguously by value."""
    return [dict(n=i, start_idx=c['start_idx'], end_idx=c['end_idx'],
                 start_sentence=body[c['start_idx']],
                 start_sentence_30=script_integrity.display_start(body[c['start_idx']]),
                 sentences=body[c['start_idx']:c['end_idx']])
            for i,c in enumerate(state['chapters'],1)]

def write_script_mapping(root, state, body):
    script_integrity.expected_starts(root, state, body)
    records = script_mapping(state,body)
    out = root/'output'
    out.mkdir(exist_ok=True)
    save_json(out/'script-map.json',records)
    text = f'[대본 1~{len(records)}]\n\n' + '\n'.join(
        f"{r['n']}. {r['start_sentence_30']}" for r in records) + '\n'
    (out/'script-starts.txt').write_text(text,encoding='utf-8-sig')

def numbered_prompts(lines):
    return '\n'.join(f'{i}. {line}' for i,line in enumerate(lines,1)) + '\n'

def scene_asset_tokens(state, row):
    ids=state['chapters'][row['n']-1].get('asset_ids')
    if not isinstance(ids,list) or not ids or len(ids)!=len(set(ids)):
        raise ValueError('ASSET: exact registered per-cut asset_ids required')
    known={a['id'] for a in state.get('assets',[])}
    if set(ids)-known: raise ValueError('ASSET: unregistered call ID')
    return ['@['+key+']' for key in ids]


def format_scene_prompt_line(state, record, row, prompt):
    """003 | source excerpt | @[asset] @[asset] actual prompt."""
    excerpt = record['start_sentence_30']
    assets = ' '.join(scene_asset_tokens(state, row))
    return f"{record['n']:03d} | {excerpt} | {assets} {prompt}".strip()

def flow_output_name(title):
    """Return a Windows-safe final TXT name derived from state TITLE."""
    if not isinstance(title, str) or not title.strip():
        raise ValueError('bundle: nonempty TITLE required for final filename')
    stem = title.strip()
    if stem.lower().endswith('.txt'):
        stem = stem[:-4].rstrip()
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', ' ', stem)
    stem = re.sub(r'\s+', ' ', stem).strip(' .')
    if not stem:
        raise ValueError('bundle: TITLE has no usable filename characters')
    if stem.upper() in {'CON','PRN','AUX','NUL',
                        'COM1','COM2','COM3','COM4','COM5','COM6','COM7','COM8','COM9',
                        'LPT1','LPT2','LPT3','LPT4','LPT5','LPT6','LPT7','LPT8','LPT9'}:
        stem += '_대본'
    return stem + '_flow.txt'

def write_bundle(root, state, body, rows, lines):
    workflow_guard.require_plan(state, body, rows, lines)
    # Even callers bypassing main() cannot export unchecked scenes.
    value_errors = scene_value_guard.project_errors(state, body, lines=lines, require_binding=True)
    if value_errors: raise scene_value_guard.ValueGateError(value_errors)
    script_integrity.expected_starts(root, state, body)
    records=script_mapping(state,body)
    from image_filenames import image_filename
    used_image_names = set()
    for record in records:
        record['image_filename'] = image_filename(record['start_sentence_30'], used_image_names)
    save_json(root/'output'/'image-filenames.json', records)
    if len(records)!=len(lines) or len(rows)!=len(lines): raise ValueError('bundle: script/prompt count mismatch')
    scene_lines=[format_scene_prompt_line(state, record, row, prompt) for record, row, prompt in zip(records, rows, lines)]
    parts=['STEP 1','']
    for c in assemble.character_prompts(state):
        parts.extend([f"=== {c['id']} ({c['name']}, {c['role']} / 챕터 -) ===",
                      f"=== {c['id']} UPLOAD ===",c['upload'],''])
    parts.extend([f'[대본 1~{len(records)}]',''])
    parts.extend(f"{r['n']}. {r['start_sentence_30']}" for r in records)
    parts.extend(['','===프롬프트===','',f'[영어 프롬프트 1~{len(lines)}]',''])
    parts.extend(scene_lines)
    text='\n'.join(parts)
    errors,counts=style_integrity.validate_flow(text,state['style_lock'],len(records))
    script_errors, script_counts = script_integrity.validate_flow(root, state, body, text)
    errors.extend(script_errors)
    if errors: raise ValueError('; '.join(errors))
    output_path=root/'output'/flow_output_name(state['TITLE'])
    temp=output_path.with_suffix('.txt.tmp')
    temp.write_text(text,encoding='utf-8-sig'); temp.replace(output_path)
    save_json(root/'output'/'script-validation.json', dict(status='PASS', version=VERSION,
        counts=script_counts, scope='First 30 source characters displayed; full original and indices retained'))
    save_json(root/'output'/'style-validation.json',dict(status='PASS',version=VERSION,
        counts=counts,scope='Exact style text and output format, not rendered images'))
    asset_records=assemble.asset_prompts(state)
    save_json(root/'output'/'asset-plan.json',asset_records)
    (root/'output'/'asset-prompts.txt').write_text('\n'.join(
        r['id']+' | '+r['filename']+' | '+r['prompt'] for r in asset_records)+'\n',encoding='utf-8-sig')
    workflow_guard.prepare_question(root,state,body)
    print(workflow_guard.GENERATION_QUESTION)
    return output_path


def bind_selected_style(root, state):
    """Called once by the production assistant after the user's choice.
    Only style fields are synchronized; script, characters and scenes are not edited.
    """
    import recommend
    selection=read_json(root/'STYLE_SELECTION.json')
    styles=read_json(Path(__file__).with_name('STYLE_BANK.json'))['styles']
    style=recommend.resolve_selection(selection,styles,None)
    lock=style_integrity.make_lock(style,selection,state.get('TITLE',''))
    state['STYLE_TAIL']=lock['STYLE_TAIL_FULL']; state['style_lock']=lock
    save_json(root/'state.json',state); save_json(root/'STYLE_LOCK.json',lock)
    (root/'선택화풍_STYLE_TAIL.txt').write_text(lock['STYLE_TAIL_FULL']+'\n',encoding='utf-8-sig')
    return lock


def verify_selected_style_source(root, state):
    import recommend
    selection=read_json(root/'STYLE_SELECTION.json')
    lock=read_json(root/'STYLE_LOCK.json')
    errors=style_integrity.lock_errors(lock,selection,state.get('TITLE'))
    if state.get('style_lock')!=lock:
        errors.append('STYLE_LOCK: state and full-original snapshot differ; bind again')
    try:
        styles=read_json(Path(__file__).with_name('STYLE_BANK.json'))['styles']
        original=recommend.resolve_selection(selection,styles,None)
        if style_integrity.full_text(original)!=lock.get('STYLE_TAIL_FULL'):
            errors.append('STYLE_LOCK: current selection source and saved original differ')
        style_integrity.state_style(state)
    except (ValueError,KeyError,TypeError) as exc:
        errors.append(str(exc))
    return errors


API = """V2.7.2-r1 — Python >=3.9, standard library only, no image generation.
Required inputs: state.json, body.json, bodies/chunk1..N.json, STYLE_SELECTION.json.
AFTER user selection: python gates.py --root WORK --bind-style
This binds the unabridged source to STYLE_LOCK.json and state.STYLE_TAIL.
Each chapter must contain value_gate: primary, three boolean flags, source_evidence,
reason, visualization, prompt_evidence, discomfort_risk, discomfort_reason,
mitigation (required for low risk), review_status APPROVED after actual review.
At least one narrative/explanatory/educational flag; none/low risk only.
After writing and reviewing all chunks: --bind-values --reviewer Claude.
The bind command records hashes, not automatic semantic approval.
Then --final requires current review hashes and actual visible prompt evidence.
--plan / --cast / --chunk N validate source-linked purpose and comfort declarations.
--characters only creates reference portraits, so is exempt from the scene gate.
--swap '12=medium_close_up' edits the shot only after validation.
--style checks a string unchanged; it DOES NOT record user selection or bind a lock.
--final checks original style against current selection AND every output prompt.
Requested output only: STEP 1; one UPLOAD per character; [대본 1~N];
===프롬프트===; [영어 프롬프트 1~N]; preserve @ID, never @ID's.
Body budgets unchanged: A60..80, S45..65, N30..50; SET excluded.
170-word check applies only to non-style material; full style is NEVER truncated.
First bind original TXT: python gates.py --root work --bind-script ORIGINAL.txt
This derives body.json from original text. Never supply an abbreviated start list.
--final compares body.json against the full source; numbered displays are first 30 characters.
Basic/economy preserve full source internally and identical prefix30 display.
The full original line/face/expression/shading/palette appears exactly once at end.
--final writes [TITLE]_flow.txt only AFTER whole-file format/style validation.
Basic/economy have identical style text and validators; economy caches analysis only.
No text validation guarantees generated-image similarity or platform acceptance.
"""

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('.'))
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--api',action='store_true')
    group.add_argument('--bind-style',action='store_true')
    group.add_argument('--bind-values',action='store_true')
    parser.add_argument('--reviewer', help='Actual reviewer of source/scene purpose and discomfort')
    group.add_argument('--bind-script',metavar='ORIGINAL_TXT')
    group.add_argument('--style')
    group.add_argument('--plan',action='store_true')
    group.add_argument('--cast',action='store_true')
    group.add_argument('--characters',action='store_true')
    group.add_argument('--chunk',type=int)
    group.add_argument('--final',action='store_true')
    group.add_argument('--swap')
    args = parser.parse_args()
    errors,verbs,lines = [],Counter(),[]
    try:
        if args.api:
            print(API); return 0
        if args.style is not None:
            if not args.style.strip() or re.search(r'[\r\n{}@]',args.style) or style_banned(args.style):
                raise ValueError('STYLE invalid: single-line resolved text without prohibited phrases required')
            print(args.style); return 0
        root = args.root
        if args.bind_script:
            _, info = script_integrity.bind_source(root, args.bind_script)
            print('BOUND ORIGINAL SCRIPT:', info['source_name'], info['sentence_count'], 'complete units')
            return 0
        if args.bind_values:
            if not args.reviewer: raise ValueError('--bind-values requires --reviewer')
            checked = scene_value_guard.bind_project(root, args.reviewer)
            save_json(root/'scene-value-bind-last-run.json', dict(version=VERSION,status='BOUND',
                scene_count=len(checked['chapters']),scope=scene_value_guard.SCOPE))
            print('BOUND SCENE REVIEWS:',len(checked['chapters'])); return 0
        s = read_json(root/'state.json')
        if args.bind_style:
            lock=bind_selected_style(root,s)
            print('BOUND FULL STYLE:',lock['sha256'],lock['characters'],'characters'); return 0
        body = read_json(root/'body.json')
        script_errors = script_integrity.source_errors(root, body)
        if script_errors: raise ValueError('; '.join(script_errors))
        source_errors=verify_selected_style_source(root,s)
        if source_errors: raise ValueError('; '.join(source_errors))
        if args.characters:
            errors = character_errors(s,body)
            if not errors:
                write_characters(root,s)
        elif args.swap:
            parts = args.swap.split('=')
            if len(parts)!=2 or not parts[0].isdigit():
                raise ValueError('swap syntax: 12=medium_close_up')
            idx,shot = int(parts[0])-1,parts[1]
            if not 0<=idx<len(s['chapters']) or shot not in assemble.SHOTS:
                raise ValueError('invalid swap index/shot')
            s['shots'][idx] = {'shot':shot}
            errors = plan_errors(s,body)+cast_errors(s,body)
            if not errors:
                save_json(root/'state.json',s)
                print('SWAP saved. Update body prefix for this cut, then rerun chunks/final.')
        else:
            errors = plan_errors(s,body)
            errors += scene_value_guard.project_errors(s, body)
            if args.cast or args.chunk is not None or args.final:
                errors += cast_errors(s,body)
            if args.final:
                errors += character_errors(s,body)
            if not errors and (args.chunk is not None or args.final):
                rows = read_rows(root,len(s['chapters']),args.chunk)
                re_errors,verbs,lines = row_errors(s,rows)
                errors += re_errors
                errors += scene_value_guard.project_errors(s, body, rows=rows, require_binding=args.final)
                print('[동사누적] ' + ', '.join(f'{k} x{v}' for k,v in sorted(verbs.items())))
            if args.final and not errors:
                workflow_guard.require_plan(s, body, rows, lines)
                value_errors = scene_value_guard.project_errors(s, body, lines=lines, require_binding=True)
                if value_errors: raise scene_value_guard.ValueGateError(value_errors)
                out = root/'output'; out.mkdir(exist_ok=True)
                write_characters(root,s)
                write_script_mapping(root,s,body)
                records = script_mapping(s,body)
                prompt_lines = [format_scene_prompt_line(s, record, row, line) for record, row, line in zip(records, rows, lines)]
                (out/'prompts.txt').write_text('\n'.join(prompt_lines)+'\n',encoding='utf-8')
                final_txt = write_bundle(root,s,body,rows,lines)
                save_json(out/'cut-plan.json',s['chapters'])
                save_json(out/'scene-value-validation.json',scene_value_guard.report([],len(lines)))
                (out/'style.txt').write_text(s['STYLE_TAIL']+'\n',encoding='utf-8')
                save_json(out/'validation.json',dict(version=VERSION,status='PASS',cuts=len(lines),
                    script_policy='FULL_SOURCE_PRESERVED_DISPLAY_PREFIX30',
                    final_txt=final_txt.name,style_sha256=s['style_lock']['sha256'],style_policy='FULL_VERBATIM',
                    scope='Rebuilt structural and lexical gates only; no semantic/image/policy approval',
                    exemptions={k:s[k] for k in ('ACTION_EXEMPT_REASON','SEQ_EXEMPT_REASONS','TIME_EXEMPT_REASON') if k in s}))
    except (OSError,ValueError,KeyError,TypeError,AttributeError,IndexError) as exc:
        errors.append('INPUT: ' + str(exc))
    if args.bind_values and errors:
        save_json(args.root/'scene-value-bind-last-run.json',dict(status='FAIL',version=VERSION,errors=errors))
    if args.final:
        args.root.mkdir(parents=True,exist_ok=True)
        save_json(args.root/'scene-value-validation-last-run.json',scene_value_guard.report(errors,len(lines),'pipeline'))
        save_json(args.root/'validation-last-run.json',dict(version=VERSION,
                   status='FAIL' if errors else 'PASS',errors=errors))
    if args.characters:
        args.root.mkdir(parents=True,exist_ok=True)
        save_json(args.root/'character-validation-last-run.json',dict(version=VERSION,
                   status='FAIL' if errors else 'PASS',errors=errors))
    if errors:
        print('\n'.join(errors)); print(f'FAIL: {len(errors)} issue(s)'); return 1
    print('PASS: rebuilt checks only; semantic/image/YouTube review remains separate.'); return 0

if __name__ == '__main__':
    if hasattr(sys.stdout,'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    sys.exit(main())
