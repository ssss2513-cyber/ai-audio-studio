"""Installer-only tests; no Claude account calls and no image generation."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

HERE=Path(__file__).parent
RECOVERY=HERE/'실행파일복구_2.7.2수정본.txt'
class RestoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.work=Path(self.tmp.name); self.dest=self.work/'도구 새 폴더'
        self.script=self.work/'대본.txt'; self.script.write_text('옛날, 옛적 어느 마을에 사람이 살았습니다.',encoding='utf-8')
    def run_restore(self,*options):
        return subprocess.run([sys.executable,'-B',str(RECOVERY),'--target',str(self.dest),*options],cwd=self.work,
                              capture_output=True,text=True,encoding='utf-8',timeout=40)
    def test_restore_from_manuscript_only_directory(self):
        raw=self.script.read_bytes()
        r=self.run_restore(); self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        report=json.loads((self.dest/'SETUP_REPORT.json').read_text())
        self.assertEqual(report['status'],'READY'); self.assertEqual(report['checked_runtime_files'],len(json.loads((HERE/'PACKAGE_MANIFEST.json').read_text())['files']))
        self.assertEqual(raw,self.script.read_bytes())
    def test_korean_names_and_api_outside_tools_directory(self):
        self.assertEqual(self.run_restore().returncode,0)
        self.assertTrue((self.dest/'00_모드선택_필독.md').is_file())
        self.assertTrue((self.dest/'대본분석_화풍추천.py').is_file())
        r=subprocess.run([sys.executable,'-B',str(self.dest/'gates.py'),'--api'],cwd=self.work,capture_output=True,text=True,timeout=15)
        self.assertEqual(r.returncode,0,r.stderr)
    def test_no_dummy_unrelated_modules(self):
        self.assertEqual(self.run_restore().returncode,0)
        for name in ['assets.py','events.py','style_contract.py','production_settings.py']:
            self.assertFalse((self.dest/name).exists())
    def test_same_payload_repeat_is_safe(self):
        self.assertEqual(self.run_restore().returncode,0)
        self.assertEqual(self.run_restore().returncode,0)
        self.assertFalse(list(self.dest.glob('_backup_*')))
    def test_conflict_stops_without_touching_any_existing_files(self):
        self.dest.mkdir(); p=self.dest/'gates.py'; p.write_text('ORIGINAL')
        r=self.run_restore(); self.assertNotEqual(r.returncode,0)
        self.assertEqual(p.read_text(),'ORIGINAL'); self.assertFalse((self.dest/'assemble.py').exists())
    def test_explicit_overwrite_backs_up_conflict(self):
        self.dest.mkdir(); p=self.dest/'gates.py'; p.write_text('ORIGINAL')
        r=self.run_restore('--overwrite'); self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(next(self.dest.glob('_backup_*/gates.py')).read_text(),'ORIGINAL')
    def test_tampered_installed_file_reports_changed(self):
        self.assertEqual(self.run_restore().returncode,0)
        p=self.dest/'pools.py'; p.write_text(p.read_text()+'\n#tamper')
        r=subprocess.run([sys.executable,'-B',str(self.dest/'setup_check.py')],capture_output=True,text=True,timeout=15)
        self.assertNotEqual(r.returncode,0); self.assertIn('CHANGED: pools.py',r.stdout)
    def test_missing_real_dependency_reported(self):
        self.assertEqual(self.run_restore().returncode,0)
        (self.dest/'style_integrity.py').unlink()
        r=subprocess.run([sys.executable,'-B',str(self.dest/'setup_check.py')],capture_output=True,text=True,timeout=15)
        self.assertNotEqual(r.returncode,0); self.assertIn('MISSING: style_integrity.py',r.stdout)
    def test_snapshot_and_old_output_not_overwritten(self):
        self.dest.mkdir(); p=self.dest/'SOURCE_SCRIPT.txt'; p.write_bytes(b'KEEP RAW')
        (self.dest/'output').mkdir(); q=self.dest/'output'/'result.txt'; q.write_text('KEEP RESULT')
        self.assertEqual(self.run_restore().returncode,0)
        self.assertEqual(p.read_bytes(),b'KEEP RAW'); self.assertEqual(q.read_text(),'KEEP RESULT')

if __name__=='__main__': unittest.main()
