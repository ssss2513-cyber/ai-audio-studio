@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  if exist "대본.txt" (set "SCRIPT=%~dp0대본.txt") else (
    echo [사용법] 대본 TXT 파일을 이 CMD 파일 위로 드래그하세요.
    echo 또는 같은 폴더에 대본.txt 이름으로 넣으세요.
    pause
    exit /b 1
  )
) else (set "SCRIPT=%~1")
echo.
echo =========================================
echo   야담 이미지 제작 V2.7.1 - 1단계 대본분석
echo =========================================
echo 1. 기본 모드  - 정밀 분석 우선
echo 2. 절약형 모드 - 품질 핵심 유지 + 토큰 절약
echo.
set /p CHOICE=번호를 입력하세요 [1/2]: 
if "%CHOICE%"=="2" (set "MODE=economy") else (set "MODE=basic")
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0대본분석_화풍추천.py" --script "%SCRIPT%" --mode %MODE% --stage analyze --scenes 40 --out "%~dp0output"
) else (
  python "%~dp0대본분석_화풍추천.py" --script "%SCRIPT%" --mode %MODE% --stage analyze --scenes 40 --out "%~dp0output"
)
if errorlevel 1 (
  echo [FAIL] 오류를 확인하세요.
) else (
  echo.
  echo [대본 분석 완료] 화풍은 아직 고정되지 않았습니다.
  echo output\화풍후보_선택대기.txt 를 확인하세요.
  echo 추천/레퍼런스/직접 화풍 중 선택 후 STYLE_SELECTION.json을 완성하세요.
  echo 그 다음 화풍선택후_최종생성.cmd 를 실행하세요.
)
pause
