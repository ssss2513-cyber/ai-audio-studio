#!/usr/bin/env python3
"""Validate Flow character references before image generation.
Checks that every @ID used in scene prompts has a STEP 1 UPLOAD block and that
Flow-unsafe possessive forms like @jeongsim's are absent.
"""
from pathlib import Path
import re, sys

UPLOAD_RE = re.compile(r'^===\s*([A-Za-z][A-Za-z0-9_]*)\s+UPLOAD\s*===\s*$', re.M)
PROMPT_RE = re.compile(r'^(\d+)\.\s+(.*)$', re.M)
AT_RE = re.compile(r'@([A-Za-z][A-Za-z0-9_]*)')
POSSESSIVE_RE = re.compile(r"@([A-Za-z][A-Za-z0-9_]*)['’]s\b")


def validate(text):
    errors=[]
    uploads=UPLOAD_RE.findall(text.split('[대본 1~40]')[0] if '[대본 1~40]' in text else text)
    upload_set=set(uploads)
    if not uploads:
        errors.append('STEP1: no === ID UPLOAD === blocks found')
    if len(uploads)!=len(upload_set):
        errors.append('STEP1: duplicate UPLOAD ID found')
    prompt_text=text.split('[영어 프롬프트 1~40]',1)[-1] if '[영어 프롬프트 1~40]' in text else text
    seen=[]
    for num, body in PROMPT_RE.findall(prompt_text):
        n=int(num); seen.append(n)
        bad=POSSESSIVE_RE.findall(body)
        for bid in bad:
            errors.append(f'SCENE {n}: Flow-unsafe possessive @{bid}\'s; use "the hand of @{bid}" or equivalent')
        ids=set(AT_RE.findall(body))
        for cid in sorted(ids-upload_set):
            errors.append(f'SCENE {n}: @{cid} is not registered in STEP 1 UPLOAD list')
    if seen and seen != list(range(1,max(seen)+1)):
        errors.append('SCENES: prompt numbers are not continuous from 1')
    return errors, uploads


def main():
    if len(sys.argv)!=2:
        print('usage: python flow_character_preflight.py "작품_flow.txt"')
        return 2
    p=Path(sys.argv[1])
    text=p.read_text(encoding='utf-8-sig')
    errors,uploads=validate(text)
    print('등록 캐릭터:', ', '.join(uploads) if uploads else '(없음)')
    if errors:
        print('\n'.join(errors))
        print(f'FAIL: {len(errors)} issue(s)')
        return 1
    print('PASS: 모든 @ID가 STEP 1에 등록되어 있고 @ID 소유격 오류가 없습니다.')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
